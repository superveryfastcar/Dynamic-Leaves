package io.github.superveryfastcar.calendar.core;

import io.github.superveryfastcar.calendar.command.CalendarCommand;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.Level;
import net.neoforged.bus.api.EventPriority;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.neoforge.event.RegisterCommandsEvent;
import net.neoforged.neoforge.event.entity.player.PlayerEvent;
import net.neoforged.neoforge.event.level.LevelEvent;
import net.neoforged.neoforge.event.server.ServerStoppedEvent;
import net.neoforged.neoforge.event.tick.ServerTickEvent;

/**
 * Connects the server's calendar to the game: when it starts, when it
 * ticks, when it stops, and when a player needs to be told about it.
 * Registered on NeoForge's main game bus in
 * {@link io.github.superveryfastcar.calendar.CalendarMod}.
 */
public final class ServerEvents {

    private ServerEvents() {
    }

    /**
     * The overworld has been loaded: start the calendar.
     *
     * <p>The overworld is the first thing a server loads, before the other
     * dimensions and before any chunk is generated. Starting here means the
     * calendar is there for everything that follows, world generation
     * included.</p>
     */
    @SubscribeEvent
    public static void onLevelLoad(LevelEvent.Load event) {
        if (event.getLevel() instanceof ServerLevel level && level.dimension() == Level.OVERWORLD) {
            CalendarAccess.start(level);
        }
    }

    /**
     * The end of a server tick: move the calendar along.
     *
     * <p>Highest priority, so that other mods listening for the end of the
     * tick already see the new date.</p>
     */
    @SubscribeEvent(priority = EventPriority.HIGHEST)
    public static void onServerTick(ServerTickEvent.Post event) {
        ServerCalendarImpl calendar = CalendarAccess.serverOrNull();
        if (calendar != null) {
            calendar.tick();
        }
    }

    /** The server has stopped and saved: let go of its calendar. */
    @SubscribeEvent
    public static void onServerStopped(ServerStoppedEvent event) {
        CalendarAccess.stop(event.getServer());
    }

    /** A player joined: send them the calendar. */
    @SubscribeEvent
    public static void onPlayerLoggedIn(PlayerEvent.PlayerLoggedInEvent event) {
        ServerCalendarImpl calendar = CalendarAccess.serverOrNull();
        if (calendar != null && event.getEntity() instanceof ServerPlayer player) {
            calendar.sendTo(player);
        }
    }

    /** The game collects its commands: add {@code /calendar}. */
    @SubscribeEvent
    public static void onRegisterCommands(RegisterCommandsEvent event) {
        CalendarCommand.register(event.getDispatcher());
    }
}
