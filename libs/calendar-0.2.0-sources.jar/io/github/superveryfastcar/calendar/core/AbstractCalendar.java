package io.github.superveryfastcar.calendar.core;

import io.github.superveryfastcar.calendar.api.Calendar;
import io.github.superveryfastcar.calendar.api.CalendarDate;
import io.github.superveryfastcar.calendar.api.CalendarRules;
import io.github.superveryfastcar.calendar.api.DayMoment;
import io.github.superveryfastcar.calendar.api.MoonPhase;
import io.github.superveryfastcar.calendar.api.SeasonBlend;
import io.github.superveryfastcar.calendar.api.event.CalendarEvent;
import net.neoforged.neoforge.common.NeoForge;

/**
 * What the server's calendar and a client's copy have in common: they hold
 * one {@link CalendarSnapshot}, answer every question of the
 * {@link Calendar} interface from it, and announce changes with the same
 * events in the same order.
 *
 * <p>The subclasses differ only in how they decide what the next snapshot
 * is. The server works it out from the world's clock and its saved state,
 * a client from its copy of the clock and what the server told it.</p>
 */
public abstract class AbstractCalendar implements Calendar {

    /** The moments of a day that come after its midnight, in the order of time. */
    private static final DayMoment[] DAYTIME_MOMENTS = {DayMoment.DAWN, DayMoment.NOON, DayMoment.DUSK};

    /**
     * The current state. "volatile" makes a new snapshot visible to other
     * threads (world generation, rendering) as soon as it is stored.
     */
    protected volatile CalendarSnapshot snapshot;

    protected AbstractCalendar(CalendarSnapshot initial) {
        this.snapshot = initial;
    }

    // ------------------------------------------------------------------
    // Calendar: every answer comes from one read of the snapshot
    // ------------------------------------------------------------------

    @Override
    public CalendarDate date() {
        return snapshot.date();
    }

    @Override
    public CalendarRules rules() {
        return snapshot.rules();
    }

    @Override
    public int tickOfDay() {
        return snapshot.tickOfDay();
    }

    @Override
    public long dayNumber() {
        return snapshot.dayNumber();
    }

    @Override
    public boolean isPaused() {
        return snapshot.paused();
    }

    @Override
    public boolean isSynced() {
        return snapshot.synced();
    }

    // The interface has ready-made versions of the following methods, built
    // from date() and tickOfDay(). They are repeated here so that each one
    // reads the snapshot only once. Otherwise a reader on another thread
    // could, at the exact moment of midnight, combine the old date with the new
    // time of day.

    @Override
    public double seasonProgress() {
        CalendarSnapshot now = snapshot;
        CalendarDate date = now.date();
        return (date.dayOfSeason() - 1 + now.tickOfDay() / (double) CalendarRules.TICKS_PER_DAY) / date.seasonLength();
    }

    @Override
    public double yearProgress() {
        CalendarSnapshot now = snapshot;
        return now.yearDay() / now.rules().yearLength();
    }

    @Override
    public double yearDay() {
        return snapshot.yearDay();
    }

    @Override
    public double summerness() {
        CalendarSnapshot now = snapshot;
        return now.rules().summerness(now.yearDay());
    }

    @Override
    public SeasonBlend blend() {
        CalendarSnapshot now = snapshot;
        return now.rules().blendAt(now.yearDay());
    }

    @Override
    public long epochTick() {
        CalendarSnapshot now = snapshot;
        return now.date().epochDay() * CalendarRules.TICKS_PER_DAY + now.tickOfDay();
    }

    @Override
    public MoonPhase moonPhase() {
        CalendarSnapshot now = snapshot;
        if (now.tickOfDay() < CalendarRules.NOON_TICK && !now.paused()) {
            // Before noon the sky still has the moon of the night that
            // began yesterday evening.
            return now.rules().moonPhaseOn(now.date().epochDay() - 1);
        }
        return now.date().moonPhase();
    }

    // ------------------------------------------------------------------
    // The sun
    // ------------------------------------------------------------------

    @Override
    public int sunriseTick() {
        return snapshot.sunriseTick();
    }

    @Override
    public int sunsetTick() {
        return snapshot.sunsetTick();
    }

    @Override
    public int sunriseTickOn(long epochDay) {
        CalendarSnapshot now = snapshot;
        // Today's value is at hand. Other days are asked for when needed.
        return epochDay == now.date().epochDay() ? now.sunriseTick()
                : SunTimesHolder.sunriseTick(now.rules(), epochDay, now.clientSide());
    }

    @Override
    public int sunsetTickOn(long epochDay) {
        CalendarSnapshot now = snapshot;
        return epochDay == now.date().epochDay() ? now.sunsetTick()
                : SunTimesHolder.sunsetTick(now.rules(), epochDay, now.clientSide());
    }

    @Override
    public boolean isSunUp() {
        CalendarSnapshot now = snapshot;
        return now.tickOfDay() >= now.sunriseTick() && now.tickOfDay() < now.sunsetTick();
    }

    @Override
    public int tickOf(DayMoment moment) {
        return tickOf(snapshot, moment);
    }

    /** Where a moment lies on the day of a snapshot, in ticks since midnight. */
    private static int tickOf(CalendarSnapshot day, DayMoment moment) {
        return switch (moment) {
            case MIDNIGHT -> 0;
            case DAWN -> day.sunriseTick();
            case NOON -> CalendarRules.NOON_TICK;
            case DUSK -> day.sunsetTick();
        };
    }

    @Override
    public long epochDayAt(long gameDayTime) {
        CalendarSnapshot now = snapshot;
        if (now.paused()) {
            // While the date is paused, every day is today.
            return now.date().epochDay();
        }
        return Math.floorDiv(gameDayTime + CalendarRules.GAME_TIME_SHIFT, (long) CalendarRules.TICKS_PER_DAY) + now.dayOffset();
    }

    // ------------------------------------------------------------------
    // The moon for the game itself
    // ------------------------------------------------------------------

    /**
     * The moon phase the game should show for one of its own day times, as
     * the game's phase number (0 = full moon). Used by the patch on the
     * game's moon calculation.
     *
     * <p>The game passes in a day time and not "now" because it sometimes
     * asks about other moments. Turning that day time into a calendar day
     * with the current offset answers such questions correctly too.</p>
     *
     * <p>The moon's day does not start at midnight like the calendar's. It
     * runs from noon to noon, so that the phase changes while the moon is
     * out of sight and a night has one moon from beginning to end. From
     * noon of a calendar day until the next noon, the sky shows that day's
     * moon. See {@link io.github.superveryfastcar.calendar.api.Calendar#moonPhase()}.</p>
     *
     * @param gameDayTime the game's day time (not shifted to the calendar's clock)
     */
    public int moonPhaseAt(long gameDayTime) {
        CalendarSnapshot now = snapshot;
        if (now.paused()) {
            // While the date is paused, every day is today.
            return now.date().moonPhase().ordinal();
        }
        // The game's time of day starts at 06:00, so noon is 6000 ticks in.
        long sinceNoon = gameDayTime - (CalendarRules.NOON_TICK - CalendarRules.GAME_TIME_SHIFT);
        long moonDay = Math.floorDiv(sinceNoon, (long) CalendarRules.TICKS_PER_DAY) + now.dayOffset();
        if (moonDay == now.date().epochDay()) {
            return now.date().moonPhase().ordinal();
        }
        return now.rules().moonPhaseOn(moonDay).ordinal();
    }

    // ------------------------------------------------------------------
    // Events
    // ------------------------------------------------------------------

    /**
     * Sends the events for one step of the clock, in the order of time.
     *
     * <p>The step is described by where the clock stood before and how many
     * ticks it moved forward. From that follows which of the four daily
     * moments were passed. Midnight and noon are fixed. Dawn and dusk are
     * taken from the sun times of the day they belong to, which each
     * snapshot carries. If a midnight was passed, the day change (and
     * season change) is sent right before that midnight's moment.</p>
     *
     * <p>Rules for jumps, as promised in {@link CalendarEvent}: a step that
     * stays in the same day or ends in the next one announces every moment
     * it passed. A step over several days announces only the moments of the
     * day it ended in.</p>
     *
     * @param before   the calendar's state before the step
     * @param after    the state after the step
     * @param advanced how many ticks the clock moved forward, 0 or more.
     *                 0 means "the clock did not move in the ordinary
     *                 sense", for example after a date change by command.
     */
    protected final void fireClockEvents(CalendarSnapshot before, CalendarSnapshot after, long advanced) {
        boolean dateChanged = after.date().epochDay() != before.date().epochDay();
        long start = before.tickOfDay();                    // ticks since the midnight that began the old day
        long end = start + advanced;
        long midnightsPassed = end / CalendarRules.TICKS_PER_DAY;

        // The rest of the old day. Skipped when the step went over several days.
        if (midnightsPassed <= 1) {
            for (DayMoment moment : DAYTIME_MOMENTS) {
                int at = tickOf(before, moment);
                if (at > start && at <= end) {
                    NeoForge.EVENT_BUS.post(new CalendarEvent.MomentReached(this, moment, before.date()));
                }
            }
        }

        // The day the step ended in, if that is another one.
        boolean dayEventSent = false;
        if (midnightsPassed >= 1) {
            dayEventSent = true;
            if (dateChanged) {
                fireDateEvents(before.date(), after.date());
            }
            long endInNewDay = end - midnightsPassed * CalendarRules.TICKS_PER_DAY;
            NeoForge.EVENT_BUS.post(new CalendarEvent.MomentReached(this, DayMoment.MIDNIGHT, after.date()));
            for (DayMoment moment : DAYTIME_MOMENTS) {
                if (tickOf(after, moment) <= endInNewDay) {
                    NeoForge.EVENT_BUS.post(new CalendarEvent.MomentReached(this, moment, after.date()));
                }
            }
        }

        // The date can change without the clock passing a midnight, for
        // example when a command sets it. Then nothing above has announced it yet.
        if (dateChanged && !dayEventSent) {
            fireDateEvents(before.date(), after.date());
        }
    }

    /** Sends the day change and, if the season is a different one, the season change. */
    protected final void fireDateEvents(CalendarDate before, CalendarDate after) {
        NeoForge.EVENT_BUS.post(new CalendarEvent.DayChanged(this, before, after));
        if (before.seasonNumber() != after.seasonNumber()) {
            NeoForge.EVENT_BUS.post(new CalendarEvent.SeasonChanged(this, before, after));
        }
    }
}
