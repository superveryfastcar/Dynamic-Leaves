package io.github.superveryfastcar.calendar.core;

import io.github.superveryfastcar.calendar.api.CalendarRules;

/**
 * Turns the game's clock into a calendar day. The date this clock gives
 * never goes backwards on its own: only a deliberate change of the date
 * (the {@code /calendar} command, or a mod through the API) can do that.
 *
 * <h2>The idea</h2>
 * The game keeps one number for the time, the <em>day time</em>, which grows
 * by one per tick. The game counts a day from 06:00. The calendar counts
 * it from midnight, six hours (6000 ticks) earlier, so it first shifts the
 * number: <em>clock time = day time + 6000</em>. This class only ever sees
 * that shifted clock time. Divided by 24000 it gives a day counter that
 * turns over at midnight, and the calendar's day is that counter plus a
 * saved offset:
 * <pre>
 *     epoch day   = (clock time / 24000) + day offset
 *     time of day = clock time mod 24000        (0 = midnight)
 * </pre>
 * As long as time simply passes, the offset never changes and the calendar
 * follows the game's clock exactly, including every way of moving the clock
 * forward: sleeping, {@code /time add}, a faster day speed.
 *
 * <h2>Why an offset is needed at all</h2>
 * The game's day time is not a reliable calendar by itself.
 * {@code /time set day} resets it to the first day of the world. A calendar
 * that read the day counter directly would jump back to its first day
 * whenever somebody typed that. The offset absorbs such resets (see below),
 * and it is also what the {@code /calendar} command changes, without
 * touching the sun.
 *
 * <h2>What happens when the game's clock is set back</h2>
 * The date never follows the clock backwards.
 * <ul>
 *   <li><b>A set-back</b> is treated as "fast forward to the next time the
 *       clock shows that time of day". Setting 19:00 in the morning stays
 *       on the same day. Setting 07:00 in the evening lands on the next
 *       morning. So the date either stays or moves on by one day.</li>
 *   <li><b>The one exception</b> is a step back of up to a minute of game
 *       time that stays within the same day. That is simply followed: the
 *       time of day goes back, the date is not affected. This is what
 *       keeps a mod that nudges the clock back by a tick or two from being
 *       mistaken for somebody setting the time, which would add a whole
 *       day with every nudge.</li>
 * </ul>
 *
 * <p>In every case the date stays a plain function of the clock time and
 * the offset. That matters because clients calculate with the same two
 * numbers: whatever the server shows, a client can work out too.</p>
 *
 * <h2>Pausing</h2>
 * While the date is paused, the clock still runs through its days, but
 * every midnight pushes the offset back by one day, so the epoch day stays
 * the same.
 *
 * <p>This class knows nothing about Minecraft. It is fed numbers and can be
 * tested on its own. Not safe for use from several threads: the server's
 * calendar calls it from the server thread only.</p>
 */
public final class CalendarClock {

    /**
     * What has to be added to the game's day time to get this clock's time:
     * the six hours between midnight and 06:00, where the game starts its day.
     */
    public static final long GAME_TIME_SHIFT = CalendarRules.GAME_TIME_SHIFT;

    /**
     * A step back of up to this many ticks that stays within the same day
     * is simply followed. Anything else is somebody setting the time.
     */
    public static final int REWIND_TOLERANCE = 1200;

    private static final long DAY = CalendarRules.TICKS_PER_DAY;

    /** The clock time (the game's day time plus {@link #GAME_TIME_SHIFT}) as of the last step. */
    private long dayTime;

    /** See the class description. */
    private long dayOffset;

    /**
     * @param dayTime   the current clock time (see {@link #toClockTime})
     * @param dayOffset the offset to start with
     */
    public CalendarClock(long dayTime, long dayOffset) {
        this.dayTime = dayTime;
        this.dayOffset = dayOffset;
    }

    /** The calendar day right now. */
    public long epochDay() {
        return Math.floorDiv(dayTime, DAY) + dayOffset;
    }

    /** Turns the game's day time into this clock's time, whose days begin at midnight. */
    public static long toClockTime(long gameDayTime) {
        return gameDayTime + GAME_TIME_SHIFT;
    }

    /** The time of day right now in ticks since midnight, 0 to 23999. */
    public int tickOfDay() {
        return (int) Math.floorMod(dayTime, DAY);
    }

    /** The current offset between the clock's day counter and the epoch day. */
    public long dayOffset() {
        return dayOffset;
    }

    /** The clock time this clock currently stands at. */
    public long dayTime() {
        return dayTime;
    }

    /** Makes today the given epoch day. The time of day stays as it is. */
    public void setEpochDay(long epochDay) {
        dayOffset = epochDay - Math.floorDiv(dayTime, DAY);
    }

    /**
     * Shows the clock the current clock time. Call once per tick.
     *
     * @param newDayTime the clock time now (see {@link #toClockTime})
     * @param paused     true while the date must not advance
     * @return how many ticks the clock moved <em>forward</em> because of
     *         this call, in the calendar's understanding. For a normal tick
     *         that is 1. For a set-back it is the distance to the next time
     *         the clock shows that time of day. For a small step back
     *         within the same day it is 0.
     */
    public long observe(long newDayTime, boolean paused) {
        long advanced;
        if (newDayTime >= dayTime) {
            advanced = newDayTime - dayTime;
        } else if (dayTime - newDayTime <= REWIND_TOLERANCE
                && Math.floorDiv(newDayTime, DAY) == Math.floorDiv(dayTime, DAY)) {
            // A small step back that stays within the day: follow it. The
            // date is not affected.
            dayTime = newDayTime;
            return 0;
        } else {
            // Somebody set the time. Go forward to the next time the clock
            // shows that time of day. The date stays or moves on by a day.
            advanced = Math.floorMod(newDayTime - dayTime, DAY);
        }

        long daysForward = paused ? 0 : (tickOfDay() + advanced) / DAY;
        long newEpochDay = epochDay() + daysForward;
        dayTime = newDayTime;
        dayOffset = newEpochDay - Math.floorDiv(newDayTime, DAY);
        return advanced;
    }
}
