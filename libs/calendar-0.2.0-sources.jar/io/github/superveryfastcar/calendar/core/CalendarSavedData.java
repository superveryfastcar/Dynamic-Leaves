package io.github.superveryfastcar.calendar.core;

import io.github.superveryfastcar.calendar.CalendarMod;
import io.github.superveryfastcar.calendar.api.CalendarRules;
import io.github.superveryfastcar.calendar.api.Season;
import javax.annotation.Nullable;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.level.saveddata.SavedData;

/**
 * What Calendar saves with a world: the file {@code data/calendar.dat} in
 * the world folder.
 *
 * <p>It holds four things:</p>
 * <ul>
 *   <li>the day offset, which together with the game's own clock gives the
 *       date (see {@link CalendarClock}),</li>
 *   <li>where the clock stood when it last looked, so that a change made
 *       while the world was closed is noticed,</li>
 *   <li>the rules the date was last calculated with. If the config file has
 *       different season lengths the next time the world is opened, the
 *       date can be carried over to the new rules properly instead of
 *       silently turning into a different date,</li>
 *   <li>the day that counts as day 1 of this world, for
 *       {@link io.github.superveryfastcar.calendar.api.Calendar#dayNumber()}.</li>
 * </ul>
 */
public final class CalendarSavedData extends SavedData {

    /** Name of the saved file, without the ".dat". */
    public static final String FILE_NAME = "calendar";

    /** Tells the game how to create this data for a new world and how to read it from an existing one. */
    public static final SavedData.Factory<CalendarSavedData> FACTORY =
            new SavedData.Factory<>(CalendarSavedData::new, CalendarSavedData::load);

    /** Null until the world's calendar has been set up for the first time. */
    @Nullable
    private CalendarRules rules;

    /** Null until the world's calendar has been set up for the first time. */
    @Nullable
    private CalendarClock clock;

    /** The epoch day that counts as day 1 of this world. Only meaningful while {@link #firstDayKnown} is true. */
    private long firstDay;

    /** False for a file written by a version of Calendar that did not count days yet (before 0.2.0). */
    private boolean firstDayKnown;

    /** A world that has no calendar file yet. */
    public CalendarSavedData() {
    }

    /** True for a world that has never had a calendar. */
    public boolean isNew() {
        return clock == null || rules == null;
    }

    /** The rules the saved date was calculated with. */
    public CalendarRules rules() {
        if (rules == null) {
            throw new IllegalStateException("The calendar has not been set up yet");
        }
        return rules;
    }

    /** The clock. Its current values are what gets written to disk. */
    public CalendarClock clock() {
        if (clock == null) {
            throw new IllegalStateException("The calendar has not been set up yet");
        }
        return clock;
    }

    /** False if the file was written before Calendar counted days. The first day then still has to be chosen. */
    public boolean isFirstDayKnown() {
        return firstDayKnown;
    }

    /** The epoch day that counts as day 1 of this world. */
    public long firstDay() {
        return firstDay;
    }

    /** Sets the epoch day that counts as day 1 of this world. */
    public void setFirstDay(long newFirstDay) {
        this.firstDay = newFirstDay;
        this.firstDayKnown = true;
        setDirty();
    }

    /** Sets up the calendar of a new world, or replaces the rules of an existing one. */
    public void set(CalendarRules newRules, CalendarClock newClock) {
        this.rules = newRules;
        this.clock = newClock;
        setDirty();
    }

    @Override
    public CompoundTag save(CompoundTag tag, HolderLookup.Provider registries) {
        if (rules != null && clock != null) {
            tag.putInt("format", 1);
            tag.putInt("spring_days", rules.seasonLength(Season.SPRING));
            tag.putInt("summer_days", rules.seasonLength(Season.SUMMER));
            tag.putInt("autumn_days", rules.seasonLength(Season.AUTUMN));
            tag.putInt("winter_days", rules.seasonLength(Season.WINTER));
            tag.putBoolean("seasonal_moon", rules.seasonalMoon());
            tag.putLong("day_offset", clock.dayOffset());
            tag.putLong("clock_time", clock.dayTime());
            if (firstDayKnown) {
                tag.putLong("first_day", firstDay);
            }
        }
        return tag;
    }

    /** Reads the file. A file that cannot be understood counts as "no calendar yet" and is replaced. */
    private static CalendarSavedData load(CompoundTag tag, HolderLookup.Provider registries) {
        CalendarSavedData data = new CalendarSavedData();
        if (!tag.contains("day_offset")) {
            return data;
        }
        try {
            data.rules = new CalendarRules(tag.getInt("spring_days"), tag.getInt("summer_days"),
                    tag.getInt("autumn_days"), tag.getInt("winter_days"), tag.getBoolean("seasonal_moon"));
            data.clock = new CalendarClock(tag.getLong("clock_time"), tag.getLong("day_offset"));
            if (tag.contains("first_day")) {
                data.firstDay = tag.getLong("first_day");
                data.firstDayKnown = true;
            }
        } catch (IllegalArgumentException e) {
            CalendarMod.LOGGER.warn("The saved calendar of this world is damaged ({}). Starting a new one.", e.getMessage());
            data.rules = null;
            data.clock = null;
        }
        return data;
    }
}
