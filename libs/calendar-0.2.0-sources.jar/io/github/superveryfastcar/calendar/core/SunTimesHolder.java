package io.github.superveryfastcar.calendar.core;

import io.github.superveryfastcar.calendar.CalendarMod;
import io.github.superveryfastcar.calendar.api.CalendarRules;
import io.github.superveryfastcar.calendar.api.SunTimes;
import java.util.Objects;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Keeps the one {@link SunTimes} that is in use, and a counter that goes up
 * whenever its answers may have changed.
 *
 * <p>Calendars do not ask the sun times on every read. Each snapshot holds
 * the sunrise and sunset of its day, together with the counter's value at
 * the time it asked. When the counter has moved on, the next tick asks
 * again. That keeps reading the calendar free of any outside call.</p>
 */
public final class SunTimesHolder {

    /** The sun times in use. "volatile" so that every thread sees a newly registered one at once. */
    private static volatile SunTimes current = SunTimes.VANILLA;

    /** Goes up with every {@link #register} and {@link #changed}. */
    private static final AtomicInteger VERSION = new AtomicInteger();

    private SunTimesHolder() {
    }

    /** See {@link SunTimes#register(SunTimes)}. */
    public static void register(SunTimes sunTimes) {
        Objects.requireNonNull(sunTimes, "sunTimes");
        SunTimes previous = current;
        if (previous != SunTimes.VANILLA && sunTimes != SunTimes.VANILLA && previous != sunTimes) {
            CalendarMod.LOGGER.warn("A second mod registered sun times with Calendar ({} replaces {}). Only the last one counts.",
                    sunTimes.getClass().getName(), previous.getClass().getName());
        }
        current = sunTimes;
        VERSION.incrementAndGet();
    }

    /** See {@link SunTimes#changed()}. */
    public static void changed() {
        VERSION.incrementAndGet();
    }

    /** The counter's current value. A snapshot made with another value is out of date. */
    static int version() {
        return VERSION.get();
    }

    /** Sunrise on a day, forced into the range the calendar relies on (before noon, after midnight). */
    static int sunriseTick(CalendarRules rules, long epochDay, boolean clientSide) {
        int tick = current.sunriseTick(rules, epochDay, clientSide);
        return Math.max(1, Math.min(CalendarRules.NOON_TICK - 1, tick));
    }

    /** Sunset on a day, forced into the range the calendar relies on (after noon, before midnight). */
    static int sunsetTick(CalendarRules rules, long epochDay, boolean clientSide) {
        int tick = current.sunsetTick(rules, epochDay, clientSide);
        return Math.max(CalendarRules.NOON_TICK + 1, Math.min(CalendarRules.TICKS_PER_DAY - 1, tick));
    }
}
