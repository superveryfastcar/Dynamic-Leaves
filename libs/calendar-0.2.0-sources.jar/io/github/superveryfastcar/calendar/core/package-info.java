/**
 * The inner workings of Calendar: the clock, the saved state and the two
 * calendars (the server's own and each client's copy).
 *
 * <p>Not part of the API. Other mods should only use
 * {@link io.github.superveryfastcar.calendar.api}.</p>
 */
package io.github.superveryfastcar.calendar.core;
