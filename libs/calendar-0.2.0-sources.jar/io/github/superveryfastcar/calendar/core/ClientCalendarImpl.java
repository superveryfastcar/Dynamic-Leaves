package io.github.superveryfastcar.calendar.core;

import io.github.superveryfastcar.calendar.CalendarMod;
import io.github.superveryfastcar.calendar.api.CalendarRules;
import io.github.superveryfastcar.calendar.api.event.CalendarEvent;
import io.github.superveryfastcar.calendar.network.CalendarSyncPayload;
import net.neoforged.neoforge.common.NeoForge;

/**
 * A client's copy of the calendar.
 *
 * <h2>How it stays right without constant messages</h2>
 * The server sends one small message when the player joins: the rules, and
 * the offset between the clock's day counter and the calendar's day (see
 * {@link CalendarClock}). The client already has its own copy of the game's
 * clock, which the game itself keeps in step with the server. So from then
 * on the client works out the date itself, with the server's formula:
 * <pre>
 *     epoch day = ((client's day time + 6000) / 24000) + offset
 * </pre>
 * The server only writes again when the offset changes, which happens when
 * someone changes the date or sets the time back. On a normal day nothing
 * is sent at all.
 *
 * <p>Because date and time of day come from the same number, they always
 * fit together on the client. That matters for everything that is blended
 * smoothly over the year: there is no moment at midnight where the time of
 * day has already started over but the date has not.</p>
 *
 * <h2>Why the client double-checks surprising dates</h2>
 * The formula uses two things that arrive separately: the client's day time
 * (from the game) and the offset (from this mod). When somebody sets the
 * time back, both change at once on the server but may reach the client a
 * moment apart. For that moment the formula gives a wrong date. The same
 * happens right after changing dimension, when the client's new world
 * briefly has no time at all.
 *
 * <p>The client therefore believes a new date at once only in the cases
 * that cannot be such a mix-up:</p>
 * <ul>
 *   <li>its own clock moved forward and nothing else changed (midnight
 *       passed, players slept, {@code /time add}), or</li>
 *   <li>the date is exactly the one the server just named in a message.</li>
 * </ul>
 * <p>Any other date has to stay the same for {@value #SETTLE_TICKS} ticks
 * before it is accepted. That is longer than the second the game takes at
 * most to send the clock, so the short-lived wrong values never get
 * through and no mod sees a date flicker. And since the formula is applied
 * fresh every tick, the client cannot drift: once both numbers are in, the
 * date is right.</p>
 *
 * <h2>When the time is set back</h2>
 * The server counts a set-back as moving forward to the next time the clock
 * shows that time of day (see {@link CalendarClock}), so the date never
 * goes back. The copy treats its own clock the same way and therefore
 * announces the same moments as the server: after {@code /time set day} in
 * the evening, both announce midnight and dawn.
 *
 * <p>Small steps back are different, because the game makes them all the
 * time: it corrects the client's clock about once a second. Steps of up to
 * {@value #JITTER_TOLERANCE} ticks are waited out and announce nothing.
 * The one case where that differs from the server is a set-back of less
 * than ten seconds across midnight: the server announces the moments of
 * the day it counts as passed, the copy does not. The date is right on
 * both sides.</p>
 *
 * <p>This class uses no client-only game classes, so it can be loaded on a
 * dedicated server (where it simply never receives anything). The part that
 * reads the client's clock is in the {@code client} package.</p>
 */
public final class ClientCalendarImpl extends AbstractCalendar {

    /** The one client calendar. A game client is only ever in one world. */
    public static final ClientCalendarImpl INSTANCE = new ClientCalendarImpl();

    /** How many ticks a surprising date must hold before the client believes it. */
    public static final int SETTLE_TICKS = 30;

    /** For how many ticks after a message the date it named is believed at once. */
    public static final int TRUST_TICKS = 100;

    /**
     * The client's clock may fall back by up to this many ticks without the
     * copy following. The game corrects a client's clock about once a
     * second, usually by a tick or two.
     */
    public static final int JITTER_TOLERANCE = 200;

    /** How many ticks the copy waits for its clock to catch up again before it follows a small step back after all. */
    public static final int JITTER_PATIENCE = 100;

    /** How many ticks at most the copy waits for a new level's clock to be set. */
    public static final int NEW_LEVEL_WAIT_TICKS = 100;

    private static final long DAY = CalendarRules.TICKS_PER_DAY;

    // --- what the server said ---

    /** The offset between the clock's day counter and the epoch day. */
    private long dayOffset;

    /** True while the date is paused on the server. */
    private boolean paused;

    /** While paused: the epoch day it is paused on. */
    private long pausedEpochDay;

    /** The epoch day the latest message named, and for how many more ticks that is believed at once. */
    private long namedDay;
    private int trustTicksLeft;

    /** True from a message that changed the offset or the pause until the next tick has dealt with it. */
    private boolean messageSinceLastTick;

    // --- the client's own bookkeeping; only touched on the client's main thread ---

    /** False until the client's clock has been read for the first time (in this level). */
    private boolean hasTime;

    /** The clock time (client's day time plus six hours) as of the last tick that was accepted. */
    private long time;

    /** How many ticks in a row the client's clock has been slightly behind {@link #time}. */
    private int waitedTicks;

    /** What the formula gave on the previous tick. Only meaningful while {@link #hasTime} is true. */
    private long lastCalculated;

    /** A surprising date that is being watched, and for how many ticks it has held. 0 ticks = none. */
    private long doubtedDay;
    private int doubtedTicks;

    /** More than 0 while waiting for a new level's clock to be set: the ticks left to wait. */
    private int newLevelTicksLeft;

    private ClientCalendarImpl() {
        super(CalendarAccess.standInSnapshot(true));
    }

    // ------------------------------------------------------------------
    // Messages from the server
    // ------------------------------------------------------------------

    /**
     * Takes in the server's calendar. Runs on the client's main thread when
     * the message arrives.
     */
    public void accept(CalendarSyncPayload payload) {
        CalendarRules rules;
        try {
            rules = payload.rules();
        } catch (IllegalArgumentException e) {
            CalendarMod.LOGGER.warn("Ignored a calendar message with impossible season lengths: {}", e.getMessage());
            return;
        }
        CalendarSnapshot before = snapshot;
        dayOffset = payload.dayOffset();
        paused = payload.paused();
        pausedEpochDay = payload.epochDay();
        namedDay = payload.epochDay();
        trustTicksLeft = TRUST_TICKS;
        messageSinceLastTick = true;

        if (!before.synced() || !before.rules().equals(rules)) {
            // The first message after joining (or one with different rules):
            // take over the server's date as it is and announce the calendar.
            snapshot = CalendarSnapshot.create(rules, rules.dateOf(payload.epochDay()), before.tickOfDay(),
                    dayOffset, payload.firstDay(), paused, true, true);
            doubtedTicks = 0;
            NeoForge.EVENT_BUS.post(new CalendarEvent.Loaded(this));
            return;
        }

        // An update while playing. If the client's clock agrees with the
        // date the server names, show it at once (the usual case, for
        // example after /calendar set). If not, the clock is about to
        // change too. Keep the date for now and let tick() sort it out.
        boolean agrees = !hasTime || dayFor(time) == payload.epochDay();
        long day = agrees ? payload.epochDay() : before.date().epochDay();
        CalendarSnapshot after = before.at(day, before.tickOfDay(), dayOffset, paused).withFirstDay(payload.firstDay());
        snapshot = after;
        if (agrees) {
            doubtedTicks = 0;
        }
        if (after.date() != before.date()) {
            fireDateEvents(before.date(), after.date());
        }
    }

    // ------------------------------------------------------------------
    // Every client tick
    // ------------------------------------------------------------------

    /**
     * Moves the copy along with the client's clock. Called at the end of
     * every client tick while the player is in a world.
     *
     * @param clientDayTime the day time of the client's level, as the game counts it
     */
    public void tick(long clientDayTime) {
        CalendarSnapshot before = snapshot;
        if (!before.synced()) {
            return; // nothing from the server yet (or the server does not have this mod)
        }
        if (newLevelTicksLeft > 0) {
            // A new level starts with its clock at zero until the server's
            // time arrives. Wait for that (but not forever: the time might
            // really be zero).
            if (clientDayTime == 0 && --newLevelTicksLeft > 0) {
                return;
            }
            newLevelTicksLeft = 0;
            hasTime = false;
        }
        long now = CalendarClock.toClockTime(clientDayTime);

        // Step 1: follow the client's clock. Small steps back are common
        // here: the game corrects the client's clock every second, and on a
        // slow server the client is usually a little ahead. The copy waits
        // those out and carries on when the clock has caught up, so that a
        // correction right at midnight does not show yesterday again for a
        // few ticks. If the clock does not catch up, the step back was real
        // and the copy follows. It also follows at once when the step back
        // comes together with a message: then somebody set the time.
        long advanced = 0;
        boolean movedForward = false;
        if (!hasTime) {
            hasTime = true;
            time = now;
            waitedTicks = 0;
            lastCalculated = dayFor(time);
        } else if (now >= time) {
            long step = now - time;
            // More than a day at once is a jump, not the clock passing by:
            // no moments are announced for it.
            advanced = step <= DAY ? step : 0;
            movedForward = true;
            time = now;
            waitedTicks = 0;
        } else if (!messageSinceLastTick && time - now <= JITTER_TOLERANCE && waitedTicks < JITTER_PATIENCE) {
            waitedTicks++;
        } else {
            // A real step back: the time was set to an earlier one. The
            // server counts that as moving forward to the next time the
            // clock shows that time of day (see CalendarClock), and so does
            // the copy, so that both announce the same moments. Only small
            // steps announce nothing: they are either a correction of the
            // client's clock after all, or what the server follows silently
            // too.
            long back = time - now;
            boolean sameDay = Math.floorDiv(now, DAY) == Math.floorDiv(time, DAY);
            boolean small = back <= JITTER_TOLERANCE || (back <= CalendarClock.REWIND_TOLERANCE && sameDay);
            advanced = small ? 0 : Math.floorMod(now - time, DAY);
            time = now;
            waitedTicks = 0;
        }

        // Step 2: work out the date and decide whether to believe it.
        long calculated = dayFor(time);
        long shown = before.date().epochDay();
        if (waitedTicks > 0 && calculated != shown && dayFor(now) == shown) {
            // The copy is waiting out a small step back, and the clock as it
            // really stands gives the date that is shown. Then there is
            // nothing to decide. Waiting is there to keep a date, never to
            // bring a new one: without this, a clock set back a few seconds
            // across midnight would make the copy announce the next day
            // while it is still looking at the time from before.
            calculated = shown;
        }
        long day = shown;
        if (calculated == shown) {
            doubtedTicks = 0;
        } else if (trustTicksLeft > 0 && calculated == namedDay) {
            day = calculated; // the server just named this date
            doubtedTicks = 0;
        } else if (!messageSinceLastTick && movedForward && lastCalculated == shown && calculated > shown) {
            day = calculated; // the client's own clock moved on: midnight, sleeping, /time add
            doubtedTicks = 0;
        } else if (doubtedTicks > 0 && doubtedDay == calculated) {
            if (++doubtedTicks > SETTLE_TICKS) {
                day = calculated; // it held, so it is real
                doubtedTicks = 0;
            }
        } else {
            doubtedDay = calculated;
            doubtedTicks = 1;
        }
        lastCalculated = calculated;
        messageSinceLastTick = false;
        if (trustTicksLeft > 0) {
            trustTicksLeft--;
        }

        CalendarSnapshot after = before.at(day, (int) Math.floorMod(time, DAY), dayOffset, paused);
        snapshot = after;
        fireClockEvents(before, after, advanced);
    }

    /** The epoch day the formula gives for a clock time. */
    private long dayFor(long clockTime) {
        return paused ? pausedEpochDay : Math.floorDiv(clockTime, DAY) + dayOffset;
    }

    // ------------------------------------------------------------------
    // Entering and leaving worlds
    // ------------------------------------------------------------------

    /**
     * The client has a new level object: the player joined, changed
     * dimension or respawned. A new level starts with its clock at zero and
     * gets the real time from the server a moment later. Until then the
     * clock is ignored and the date stays as it is.
     */
    public void levelChanged() {
        newLevelTicksLeft = NEW_LEVEL_WAIT_TICKS;
        hasTime = false;
        doubtedTicks = 0;
    }

    /** The player left the world. Back to the stand-in until a server sends its calendar again. */
    public void reset() {
        snapshot = CalendarAccess.standInSnapshot(true);
        dayOffset = 0;
        paused = false;
        hasTime = false;
        waitedTicks = 0;
        doubtedTicks = 0;
        newLevelTicksLeft = 0;
        trustTicksLeft = 0;
        messageSinceLastTick = false;
    }

    @Override
    public boolean isClientSide() {
        return true;
    }
}
