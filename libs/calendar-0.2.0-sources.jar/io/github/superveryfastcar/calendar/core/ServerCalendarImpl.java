package io.github.superveryfastcar.calendar.core;

import io.github.superveryfastcar.calendar.CalendarConfig;
import io.github.superveryfastcar.calendar.CalendarGameRules;
import io.github.superveryfastcar.calendar.CalendarMod;
import io.github.superveryfastcar.calendar.api.CalendarDate;
import io.github.superveryfastcar.calendar.api.CalendarRules;
import io.github.superveryfastcar.calendar.api.Season;
import io.github.superveryfastcar.calendar.api.ServerCalendar;
import io.github.superveryfastcar.calendar.api.event.CalendarEvent;
import io.github.superveryfastcar.calendar.network.CalendarSyncPayload;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.neoforge.common.NeoForge;
import net.neoforged.neoforge.network.PacketDistributor;

/**
 * The server's calendar, the one that decides what day it is.
 *
 * <p>Its whole job per tick is small: show the world's current day time to
 * the {@link CalendarClock}, store the result as the new snapshot, tell the
 * clients if something changed that they cannot work out themselves, and
 * send the events. All of that happens at the end of the server tick, on
 * the server thread.</p>
 *
 * <p>There is one of these per running server. It is created when the
 * overworld has been loaded and dropped when the server has stopped. See
 * {@link CalendarAccess}.</p>
 */
public final class ServerCalendarImpl extends AbstractCalendar implements ServerCalendar {

    /** Dates further than this many days from the start of the calendar are refused. About 17 billion years. */
    private static final long MAX_EPOCH_DAY = 1_000_000_000_000L;

    private final MinecraftServer server;

    /** The overworld. Its clock is the clock of every dimension. */
    private final ServerLevel overworld;

    /** The saved state. Holds the clock and the rules. */
    private final CalendarSavedData data;

    private ServerCalendarImpl(ServerLevel overworld, CalendarSavedData data, CalendarSnapshot initial) {
        super(initial);
        this.server = overworld.getServer();
        this.overworld = overworld;
        this.data = data;
    }

    // ------------------------------------------------------------------
    // Starting up
    // ------------------------------------------------------------------

    /**
     * Creates the calendar for a server whose overworld has just been
     * loaded. Reads the saved state, or sets up a new calendar if the world
     * has none.
     */
    public static ServerCalendarImpl load(ServerLevel overworld) {
        CalendarSavedData data = overworld.getDataStorage().computeIfAbsent(CalendarSavedData.FACTORY, CalendarSavedData.FILE_NAME);
        CalendarRules configured = CalendarConfig.rules();
        long clockTime = CalendarClock.toClockTime(overworld.getDayTime());
        boolean paused = CalendarGameRules.isPaused(overworld);

        if (data.isNew()) {
            // A world without a calendar: a new world, or an existing world
            // that gets this mod for the first time. Either way today
            // becomes the configured starting date, however old the world is.
            long startDay = CalendarConfig.startEpochDay(configured);
            long offset = startDay - Math.floorDiv(clockTime, (long) CalendarRules.TICKS_PER_DAY);
            data.set(configured, new CalendarClock(clockTime, offset));
            // Today is day 1 of this world's count of days.
            data.setFirstDay(startDay);
            CalendarMod.LOGGER.info("Started this world's calendar on {}.", configured.dateOf(startDay));
        } else {
            // The game's clock may have been changed while the world was
            // closed. Let the clock handle that like any other change.
            long offsetBefore = data.clock().dayOffset();
            data.clock().observe(clockTime, paused);
            if (data.clock().dayOffset() != offsetBefore) {
                data.setDirty();
            }
            if (!data.isFirstDayKnown()) {
                // Saved by a version that did not count days yet. Count
                // from the configured starting date, which is the day this
                // world's calendar began on unless the date was set by
                // hand since. If the date is now before that, count from today.
                data.setFirstDay(Math.min(CalendarConfig.startEpochDay(data.rules()), data.clock().epochDay()));
            }
            if (!data.rules().equals(configured)) {
                carryOver(data, configured);
            }
        }

        CalendarClock clock = data.clock();
        CalendarRules rules = data.rules();
        CalendarSnapshot initial = CalendarSnapshot.create(rules, rules.dateOf(clock.epochDay()), clock.tickOfDay(),
                clock.dayOffset(), data.firstDay(), paused, true, false);
        return new ServerCalendarImpl(overworld, data, initial);
    }

    /**
     * The config's season lengths differ from the ones the saved date was
     * calculated with. Keeps the date under the new rules, and the number
     * of days the world has counted so far. (Public for the tests.)
     */
    public static void carryOver(CalendarSavedData data, CalendarRules newRules) {
        CalendarClock clock = data.clock();
        CalendarDate old = data.rules().dateOf(clock.epochDay());
        long daysCounted = clock.epochDay() - data.firstDay();
        clock.setEpochDay(carriedOverEpochDay(data.rules(), newRules, clock.epochDay()));
        data.set(newRules, clock);
        data.setFirstDay(clock.epochDay() - daysCounted);
        CalendarMod.LOGGER.info("The calendar's rules changed in the config. The date was carried over: {} is now {}.",
                old, newRules.dateOf(clock.epochDay()));
    }

    /**
     * Finds the day under new rules that is "the same date" as a day under
     * old rules: the same year, the same season and the same day of the
     * season. If the season became shorter than that day number, the result
     * is the season's last day.
     *
     * @param oldRules the rules the epoch day was counted with
     * @param newRules the rules to count with from now on
     * @param epochDay the day under the old rules
     * @return the matching epoch day under the new rules
     */
    public static long carriedOverEpochDay(CalendarRules oldRules, CalendarRules newRules, long epochDay) {
        CalendarDate old = oldRules.dateOf(epochDay);
        int day = Math.min(old.dayOfSeason(), newRules.seasonLength(old.season()));
        return newRules.epochDayOf(old.year(), old.season(), day);
    }

    // ------------------------------------------------------------------
    // Every tick
    // ------------------------------------------------------------------

    /** Moves the calendar along with the world's clock. Called at the end of every server tick. */
    public void tick() {
        CalendarClock clock = data.clock();
        CalendarSnapshot before = snapshot;
        boolean paused = CalendarGameRules.isPaused(overworld);

        long advanced = clock.observe(CalendarClock.toClockTime(overworld.getDayTime()), paused);
        CalendarSnapshot after = before.at(clock.epochDay(), clock.tickOfDay(), clock.dayOffset(), paused);
        snapshot = after;

        // Clients follow the date on their own as long as the offset and the
        // pause stay the same. Only a change of those has to be sent.
        if (after.dayOffset() != before.dayOffset() || after.paused() != before.paused()) {
            data.setDirty();
            sendToAll();
        } else if (after.date() != before.date()) {
            // Nothing a client needs, but worth saving: it refreshes "where
            // the clock stood when it last looked" on disk once a day.
            data.setDirty();
        }
        fireClockEvents(before, after, advanced);
    }

    // ------------------------------------------------------------------
    // ServerCalendar: changing the date
    // ------------------------------------------------------------------

    @Override
    public void setDate(int year, Season season, int dayOfSeason) {
        setEpochDay(rules().epochDayOf(year, season, dayOfSeason));
    }

    @Override
    public void addDays(long days) {
        setEpochDay(Math.addExact(date().epochDay(), days));
    }

    @Override
    public void setEpochDay(long epochDay) {
        if (!server.isSameThread()) {
            throw new IllegalStateException("The calendar can only be changed on the server thread");
        }
        if (epochDay > MAX_EPOCH_DAY || epochDay < -MAX_EPOCH_DAY) {
            throw new IllegalArgumentException("That date is too far from the start of the calendar");
        }
        CalendarClock clock = data.clock();
        CalendarSnapshot before = snapshot;
        if (epochDay == before.date().epochDay()) {
            return;
        }
        clock.setEpochDay(epochDay);
        // Setting the date by hand renames today. It does not change how
        // many days the world has seen, so day 1 moves along with the date.
        data.setFirstDay(data.firstDay() + (epochDay - before.date().epochDay()));
        CalendarSnapshot after = before.at(clock.epochDay(), before.tickOfDay(), clock.dayOffset(), before.paused())
                .withFirstDay(data.firstDay());
        snapshot = after;
        data.setDirty();
        sendToAll();
        // The clock itself did not move, so no moments are announced.
        fireDateEvents(before.date(), after.date());
    }

    @Override
    public boolean isClientSide() {
        return false;
    }

    // ------------------------------------------------------------------
    // Telling the clients
    // ------------------------------------------------------------------

    /** Sends the calendar to one player. Done when they join. */
    public void sendTo(ServerPlayer player) {
        // A player without this mod has no use for the message and is
        // simply left out. See CalendarNetwork.
        if (player.connection.hasChannel(CalendarSyncPayload.TYPE)) {
            PacketDistributor.sendToPlayer(player, CalendarSyncPayload.of(snapshot));
        }
    }

    /**
     * Sends the calendar to every player. Done whenever the offset or the
     * pause changed.
     *
     * <p>The game's own time message goes out first. A client works out the
     * date from its copy of the game's clock and the offset together. When
     * the offset changed because the clock was set back, a client must not
     * be left with the new offset and the old clock (the game would only
     * send the clock up to a second later).</p>
     */
    private void sendToAll() {
        server.forceTimeSynchronization();
        CalendarSyncPayload payload = CalendarSyncPayload.of(snapshot);
        for (ServerPlayer player : server.getPlayerList().getPlayers()) {
            if (player.connection.hasChannel(CalendarSyncPayload.TYPE)) {
                PacketDistributor.sendToPlayer(player, payload);
            }
        }
    }

    // ------------------------------------------------------------------
    // For CalendarAccess
    // ------------------------------------------------------------------

    /** True if the calling code runs on this server's own thread. */
    boolean isOnServerThread() {
        return server.isSameThread();
    }

    /** The server this calendar belongs to. */
    MinecraftServer server() {
        return server;
    }

    /** Announces that the calendar is ready. Called once, right after it has been made reachable. */
    void announceLoaded() {
        NeoForge.EVENT_BUS.post(new CalendarEvent.Loaded(this));
    }
}
