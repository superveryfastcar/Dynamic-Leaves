package io.github.superveryfastcar.calendar.core;

import io.github.superveryfastcar.calendar.api.CalendarDate;
import io.github.superveryfastcar.calendar.api.CalendarRules;

/**
 * Everything a calendar knows at one moment, frozen into one object that is
 * never modified.
 *
 * <p>A calendar keeps exactly one of these at a time and swaps it for a new
 * one at the end of each tick. Whoever reads the calendar picks up the
 * current snapshot and reads from that, so a reader always sees values that
 * belong together (never today's time of day with yesterday's date), no
 * matter which thread it runs on, and without any locking.</p>
 *
 * @param rules           season lengths and the moon setting
 * @param date            today's date
 * @param tickOfDay       the time of day on the calendar's clock: ticks
 *                        since midnight, 0 to 23999
 * @param dayOffset       the saved offset between the game's day counter
 *                        and the epoch day, see {@link CalendarClock}. Only
 *                        needed here to answer "which day would another day
 *                        time fall on".
 * @param firstDay        the epoch day that counts as day 1 of this world,
 *                        see {@link io.github.superveryfastcar.calendar.api.Calendar#dayNumber()}
 * @param paused          true while the date does not advance (game rule)
 * @param synced          true if this is the world's real calendar, false
 *                        for the stand-in used before a client has heard
 *                        from the server
 * @param clientSide      true if this belongs to a client's copy
 * @param sunriseTick     when the sun rises today, ticks since midnight
 * @param sunsetTick      when the sun sets today, ticks since midnight
 * @param sunTimesVersion the value of {@link SunTimesHolder#version()} when
 *                        the two sun times were asked for. If the holder
 *                        has moved on, they are asked for again.
 */
public record CalendarSnapshot(CalendarRules rules, CalendarDate date, int tickOfDay, long dayOffset, long firstDay,
                               boolean paused, boolean synced, boolean clientSide,
                               int sunriseTick, int sunsetTick, int sunTimesVersion) {

    /** A fresh snapshot. Asks the sun times for the date. */
    static CalendarSnapshot create(CalendarRules rules, CalendarDate date, int tickOfDay, long dayOffset, long firstDay,
                                   boolean paused, boolean synced, boolean clientSide) {
        // The version is read first. If the sun times change while they are
        // being asked, the version no longer matches and the next tick asks again.
        int version = SunTimesHolder.version();
        return new CalendarSnapshot(rules, date, tickOfDay, dayOffset, firstDay, paused, synced, clientSide,
                SunTimesHolder.sunriseTick(rules, date.epochDay(), clientSide),
                SunTimesHolder.sunsetTick(rules, date.epochDay(), clientSide),
                version);
    }

    /**
     * The same snapshot at a different date and time of day. Keeps the old
     * date object and the old sun times if the day is the same and the sun
     * times have not been changed in the meantime.
     */
    CalendarSnapshot at(long epochDay, int newTickOfDay, long newDayOffset, boolean newPaused) {
        if (epochDay == date.epochDay() && sunTimesVersion == SunTimesHolder.version()) {
            return new CalendarSnapshot(rules, date, newTickOfDay, newDayOffset, firstDay, newPaused, synced, clientSide,
                    sunriseTick, sunsetTick, sunTimesVersion);
        }
        CalendarDate newDate = (epochDay == date.epochDay()) ? date : rules.dateOf(epochDay);
        return create(rules, newDate, newTickOfDay, newDayOffset, firstDay, newPaused, synced, clientSide);
    }

    /** The same snapshot with another day counting as day 1. */
    CalendarSnapshot withFirstDay(long newFirstDay) {
        return newFirstDay == firstDay ? this
                : new CalendarSnapshot(rules, date, tickOfDay, dayOffset, newFirstDay, paused, synced, clientSide,
                        sunriseTick, sunsetTick, sunTimesVersion);
    }

    /** Today's number in the world's count of days, see {@link io.github.superveryfastcar.calendar.api.Calendar#dayNumber()}. */
    long dayNumber() {
        return date.epochDay() - firstDay + 1;
    }

    /** The current moment as days since the start of the year, with the time of day as the fraction. */
    double yearDay() {
        return date.dayOfYear() - 1 + tickOfDay / (double) CalendarRules.TICKS_PER_DAY;
    }
}
