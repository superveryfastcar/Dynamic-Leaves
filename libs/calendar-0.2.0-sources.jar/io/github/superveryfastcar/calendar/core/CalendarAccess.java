package io.github.superveryfastcar.calendar.core;

import io.github.superveryfastcar.calendar.CalendarConfig;
import io.github.superveryfastcar.calendar.api.Calendar;
import io.github.superveryfastcar.calendar.api.CalendarRules;
import io.github.superveryfastcar.calendar.api.ServerCalendar;
import javax.annotation.Nullable;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.LevelReader;

/**
 * Finds the right calendar for whoever asks. This is what
 * {@code Calendar.of(...)} calls.
 *
 * <p>A running program can hold up to two calendars: the server's own, and
 * a client's copy. A dedicated server has only the first, a client that
 * joined someone else's world only the second, and a single-player game
 * both (it runs a server and a client at the same time).</p>
 */
public final class CalendarAccess {

    /** The calendar of the running server, or null if no server is running in this program. */
    @Nullable
    private static volatile ServerCalendarImpl server;

    private CalendarAccess() {
    }

    // ------------------------------------------------------------------
    // Lookups
    // ------------------------------------------------------------------

    /** See {@link Calendar#of(LevelReader)}. */
    public static Calendar of(LevelReader level) {
        if (level.isClientSide()) {
            return ClientCalendarImpl.INSTANCE;
        }
        ServerCalendarImpl running = server;
        return running != null ? running : new StandIn();
    }

    /** See {@link Calendar#of(MinecraftServer)}. */
    public static ServerCalendar of(MinecraftServer minecraftServer) {
        ServerCalendarImpl running = server;
        if (running == null || running.server() != minecraftServer) {
            throw new IllegalStateException("The calendar is not running yet. It starts when the overworld has been loaded.");
        }
        return running;
    }

    /** The server's calendar, or null if none is running. For this mod's own event handlers. */
    @Nullable
    public static ServerCalendarImpl serverOrNull() {
        return server;
    }

    /**
     * The calendar for the thread that asks, or null if none is known. See
     * {@link Calendar#ofCurrentThread()}.
     *
     * <p>The game asks about the sun and the moon from the server thread
     * (mob spawning, difficulty, sleeping) and from the client (drawing the
     * sky). In a single-player game both calendars exist, and each side
     * gets its own.</p>
     */
    @Nullable
    private static AbstractCalendar currentThreadOrNull() {
        ServerCalendarImpl running = server;
        if (running != null && running.isOnServerThread()) {
            return running;
        }
        ClientCalendarImpl client = ClientCalendarImpl.INSTANCE;
        if (client.isSynced()) {
            return client;
        }
        return running;
    }

    /** See {@link Calendar#ofCurrentThread()}. */
    public static Calendar ofCurrentThread() {
        AbstractCalendar calendar = currentThreadOrNull();
        return calendar != null ? calendar : new StandIn();
    }

    /**
     * The moon phase the game should show for one of its day times, as the
     * game's phase number, or -1 to leave the game's own calculation alone
     * (when no calendar is known).
     */
    public static int moonPhase(long dayTime) {
        AbstractCalendar calendar = currentThreadOrNull();
        return calendar != null ? calendar.moonPhaseAt(dayTime) : -1;
    }

    // ------------------------------------------------------------------
    // Server start and stop
    // ------------------------------------------------------------------

    /** Starts the calendar of a server whose overworld has just been loaded. */
    public static void start(ServerLevel overworld) {
        ServerCalendarImpl calendar = ServerCalendarImpl.load(overworld);
        server = calendar;
        calendar.announceLoaded();
    }

    /** Drops the calendar of a server that has stopped. Its state has been saved with the world. */
    public static void stop(MinecraftServer minecraftServer) {
        ServerCalendarImpl running = server;
        if (running != null && running.server() == minecraftServer) {
            server = null;
        }
    }

    // ------------------------------------------------------------------
    // The stand-in
    // ------------------------------------------------------------------

    /**
     * What a calendar shows while the real one is not known: the starting
     * date from this computer's config, at 06:00 (when a new world starts),
     * marked as not synced.
     *
     * @param clientSide true for the stand-in of a client's copy
     */
    static CalendarSnapshot standInSnapshot(boolean clientSide) {
        CalendarRules rules = CalendarConfig.rules();
        long startDay = CalendarConfig.startEpochDay(rules);
        return CalendarSnapshot.create(rules, rules.dateOf(startDay),
                CalendarRules.GAME_TIME_SHIFT, 0, startDay, false, false, clientSide);
    }

    /**
     * The calendar handed out for a server-side level while no server
     * calendar is running. That only happens during start-up and shutdown.
     */
    private static final class StandIn extends AbstractCalendar {

        StandIn() {
            super(standInSnapshot(false));
        }

        @Override
        public boolean isClientSide() {
            return false;
        }
    }
}
