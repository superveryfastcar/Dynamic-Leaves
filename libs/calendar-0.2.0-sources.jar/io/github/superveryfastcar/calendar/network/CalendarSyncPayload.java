package io.github.superveryfastcar.calendar.network;

import io.github.superveryfastcar.calendar.CalendarMod;
import io.github.superveryfastcar.calendar.api.CalendarRules;
import io.github.superveryfastcar.calendar.api.Season;
import io.github.superveryfastcar.calendar.core.CalendarSnapshot;
import io.netty.buffer.ByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;

/**
 * The one message Calendar sends from the server to a client.
 *
 * <p>It carries what a client cannot work out on its own: the rules, and
 * how the game's day counter relates to the calendar's day. With these the
 * client calculates the date from its own copy of the game's clock (see
 * {@link io.github.superveryfastcar.calendar.core.ClientCalendarImpl}).</p>
 *
 * <p>It is sent when a player joins, and again whenever the offset or the
 * pause changes: after {@code /calendar set}, after the time was set back,
 * when the game rule is switched, and once a day (at midnight) while the
 * date is paused.
 * On an ordinary day it is not sent at all. It is 34 bytes long.</p>
 *
 * @param springDays   days of spring
 * @param summerDays   days of summer
 * @param autumnDays   days of autumn
 * @param winterDays   days of winter
 * @param seasonalMoon whether the moon follows the seasons
 * @param paused       whether the date is paused
 * @param dayOffset    what to add to the clock's day counter to get the
 *                     epoch day. The clock's day counter is the game's day
 *                     time plus 6000 (so that days begin at midnight),
 *                     divided by 24000.
 * @param epochDay     the server's epoch day when the message was sent. The
 *                     client shows it right after joining and while paused.
 * @param firstDay     the epoch day that counts as day 1 of the world, see
 *                     {@link io.github.superveryfastcar.calendar.api.Calendar#dayNumber()}
 */
public record CalendarSyncPayload(int springDays, int summerDays, int autumnDays, int winterDays,
                                  boolean seasonalMoon, boolean paused, long dayOffset, long epochDay, long firstDay)
        implements CustomPacketPayload {

    /** The unique name of this message on the network: {@code calendar:sync}. */
    public static final Type<CalendarSyncPayload> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath(CalendarMod.MOD_ID, "sync"));

    /**
     * How the message is written to and read from the network: four short
     * numbers for the season lengths, two yes/no values, three long numbers.
     */
    public static final StreamCodec<ByteBuf, CalendarSyncPayload> STREAM_CODEC = StreamCodec.of(
            (buffer, payload) -> {
                buffer.writeShort(payload.springDays);
                buffer.writeShort(payload.summerDays);
                buffer.writeShort(payload.autumnDays);
                buffer.writeShort(payload.winterDays);
                buffer.writeBoolean(payload.seasonalMoon);
                buffer.writeBoolean(payload.paused);
                buffer.writeLong(payload.dayOffset);
                buffer.writeLong(payload.epochDay);
                buffer.writeLong(payload.firstDay);
            },
            buffer -> new CalendarSyncPayload(
                    buffer.readShort(), buffer.readShort(), buffer.readShort(), buffer.readShort(),
                    buffer.readBoolean(), buffer.readBoolean(), buffer.readLong(), buffer.readLong(), buffer.readLong()));

    /** The message that describes a calendar's current state. */
    public static CalendarSyncPayload of(CalendarSnapshot snapshot) {
        CalendarRules rules = snapshot.rules();
        return new CalendarSyncPayload(
                rules.seasonLength(Season.SPRING), rules.seasonLength(Season.SUMMER),
                rules.seasonLength(Season.AUTUMN), rules.seasonLength(Season.WINTER),
                rules.seasonalMoon(), snapshot.paused(), snapshot.dayOffset(), snapshot.date().epochDay(),
                snapshot.firstDay());
    }

    /**
     * The rules this message describes.
     *
     * @throws IllegalArgumentException if a season length is outside the allowed range
     */
    public CalendarRules rules() {
        return new CalendarRules(springDays, summerDays, autumnDays, winterDays, seasonalMoon);
    }

    @Override
    public Type<CalendarSyncPayload> type() {
        return TYPE;
    }
}
