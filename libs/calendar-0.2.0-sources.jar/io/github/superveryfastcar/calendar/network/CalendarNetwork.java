package io.github.superveryfastcar.calendar.network;

import io.github.superveryfastcar.calendar.core.ClientCalendarImpl;
import net.neoforged.neoforge.network.event.RegisterPayloadHandlersEvent;
import net.neoforged.neoforge.network.registration.PayloadRegistrar;

/**
 * Registers Calendar's network message with NeoForge.
 */
public final class CalendarNetwork {

    /**
     * Version of Calendar's network format. Raise it whenever
     * {@link CalendarSyncPayload} changes shape.
     */
    private static final String PROTOCOL_VERSION = "2";

    private CalendarNetwork() {
    }

    /**
     * Called once during game start-up.
     *
     * <p>The message is registered as <em>optional</em>. A player without
     * Calendar can still join a world that has it (and the other way
     * round). Their client then has no calendar, which
     * {@link io.github.superveryfastcar.calendar.api.Calendar#isSynced()}
     * reports.</p>
     */
    public static void register(RegisterPayloadHandlersEvent event) {
        PayloadRegistrar registrar = event.registrar(PROTOCOL_VERSION).optional();
        registrar.playToClient(
                CalendarSyncPayload.TYPE,
                CalendarSyncPayload.STREAM_CODEC,
                // Runs on the client's main thread when the message arrives.
                // ClientCalendarImpl uses no client-only game classes, so
                // referring to it here is safe on a dedicated server.
                (payload, context) -> ClientCalendarImpl.INSTANCE.accept(payload));
    }
}
