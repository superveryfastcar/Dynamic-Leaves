package io.github.superveryfastcar.calendar.client;

import io.github.superveryfastcar.calendar.CalendarMod;
import io.github.superveryfastcar.calendar.core.ClientCalendarImpl;
import javax.annotation.Nullable;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.EventPriority;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ClientPlayerNetworkEvent;
import net.neoforged.neoforge.client.event.ClientTickEvent;

/**
 * Connects the client's copy of the calendar to the game client: it shows
 * the copy the client's clock once per tick and tells it when the player
 * enters or leaves a world.
 *
 * <p>This class and {@link CalendarClient} are the only ones in Calendar
 * that use client-only game classes. NeoForge loads them on game clients
 * only ({@code Dist.CLIENT}).</p>
 */
@EventBusSubscriber(modid = CalendarMod.MOD_ID, value = Dist.CLIENT)
public final class ClientEvents {

    /** The level seen on the previous tick, to notice when the client gets a new one. */
    @Nullable
    private static ClientLevel lastLevel;

    private ClientEvents() {
    }

    /**
     * The end of a client tick: move the copy along.
     *
     * <p>Highest priority, so that other mods listening for the end of the
     * tick already see the new date.</p>
     */
    @SubscribeEvent(priority = EventPriority.HIGHEST)
    public static void onClientTick(ClientTickEvent.Post event) {
        ClientLevel level = Minecraft.getInstance().level;
        if (level == null) {
            lastLevel = null;
            return;
        }
        if (level != lastLevel) {
            // Joined, changed dimension or respawned: a new level object
            // whose clock is not set yet.
            lastLevel = level;
            ClientCalendarImpl.INSTANCE.levelChanged();
        }
        ClientCalendarImpl.INSTANCE.tick(level.getDayTime());
    }

    /**
     * The player is joining a world. Start from a clean stand-in, in case
     * anything is left over from the previous world. The server's calendar
     * arrives right after this.
     */
    @SubscribeEvent
    public static void onLoggingIn(ClientPlayerNetworkEvent.LoggingIn event) {
        if (!ClientCalendarImpl.INSTANCE.isSynced()) {
            ClientCalendarImpl.INSTANCE.reset();
        }
    }

    /** The player left the world: forget its calendar. */
    @SubscribeEvent
    public static void onLoggingOut(ClientPlayerNetworkEvent.LoggingOut event) {
        lastLevel = null;
        ClientCalendarImpl.INSTANCE.reset();
    }
}
