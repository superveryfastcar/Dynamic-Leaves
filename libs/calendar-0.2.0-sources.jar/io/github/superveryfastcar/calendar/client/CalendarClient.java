package io.github.superveryfastcar.calendar.client;

import io.github.superveryfastcar.calendar.CalendarMod;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.fml.ModContainer;
import net.neoforged.fml.common.Mod;
import net.neoforged.neoforge.client.gui.ConfigurationScreen;
import net.neoforged.neoforge.client.gui.IConfigScreenFactory;

/**
 * Client-side entry point of Calendar. NeoForge only loads this class in
 * the game client, never on a dedicated server ({@code dist = Dist.CLIENT}).
 *
 * <p>All it does is add the settings screen. The client's copy of the
 * calendar is connected to the game in {@link ClientEvents}.</p>
 */
@Mod(value = CalendarMod.MOD_ID, dist = Dist.CLIENT)
public final class CalendarClient {

    public CalendarClient(ModContainer container) {
        // Adds a "Config" button for Calendar in the game's Mods screen,
        // using NeoForge's built-in settings screen. The labels come from
        // the language file (calendar.configuration.*).
        container.registerExtensionPoint(IConfigScreenFactory.class, ConfigurationScreen::new);
    }
}
