package io.github.superveryfastcar.calendar.loot;

import com.mojang.datafixers.util.Either;
import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import io.github.superveryfastcar.calendar.api.Calendar;
import io.github.superveryfastcar.calendar.api.CalendarDate;
import io.github.superveryfastcar.calendar.api.MoonPhase;
import io.github.superveryfastcar.calendar.api.Season;
import io.github.superveryfastcar.calendar.api.SeasonPhase;
import java.util.List;
import java.util.Optional;
import net.minecraft.advancements.critereon.MinMaxBounds;
import net.minecraft.world.level.storage.loot.LootContext;
import net.minecraft.world.level.storage.loot.predicates.LootItemCondition;
import net.minecraft.world.level.storage.loot.predicates.LootItemConditionType;

/**
 * The date as a condition for data packs: {@code calendar:date}.
 *
 * <p>This makes the calendar usable without writing any code, everywhere
 * the game accepts a "predicate": in loot tables (seasonal fishing catches
 * and mob drops), in advancements, and in commands with
 * {@code /execute if predicate}. KubeJS scripts can use it the same way.</p>
 *
 * <h2>Format</h2>
 * Every field is optional. A field that is left out accepts everything.
 * The condition passes when all given fields match. The date changes at
 * midnight. The moon is the one in the sky, which stays the same all night.
 * <pre>{@code
 * {
 *   "condition": "calendar:date",
 *   "season": ["autumn", "winter"],      // one name or a list
 *   "phase": "late",                     // "early", "mid", "late"; one or a list
 *   "moon": "full_moon",                 // tonight's moon; one name or a list, see MoonPhase
 *   "day": { "min": 3, "max": 10 },      // day of the season; a single number works too
 *   "year": { "min": 2 }                 // the year; a single number works too
 * }
 * }</pre>
 * Example for a command block: {@code /execute if predicate {condition:"calendar:date",season:"winter"} run say Brr}
 *
 * @param seasons    the seasons that match, empty for any
 * @param phases     the parts of a season that match, empty for any
 * @param moonPhases the moon phases that match, empty for any
 * @param day        the days of the season that match
 * @param year       the years that match
 */
public record DateCondition(Optional<List<Season>> seasons, Optional<List<SeasonPhase>> phases,
                            Optional<List<MoonPhase>> moonPhases, MinMaxBounds.Ints day, MinMaxBounds.Ints year)
        implements LootItemCondition {

    /** How the condition is read from and written to a data file. See the class description for the format. */
    public static final MapCodec<DateCondition> CODEC = RecordCodecBuilder.mapCodec(instance -> instance.group(
            oneOrMore(Season.CODEC).optionalFieldOf("season").forGetter(DateCondition::seasons),
            oneOrMore(SeasonPhase.CODEC).optionalFieldOf("phase").forGetter(DateCondition::phases),
            oneOrMore(MoonPhase.CODEC).optionalFieldOf("moon").forGetter(DateCondition::moonPhases),
            MinMaxBounds.Ints.CODEC.optionalFieldOf("day", MinMaxBounds.Ints.ANY).forGetter(DateCondition::day),
            MinMaxBounds.Ints.CODEC.optionalFieldOf("year", MinMaxBounds.Ints.ANY).forGetter(DateCondition::year)
    ).apply(instance, DateCondition::new));

    /** A condition that matches any day of the given seasons. For mods that build loot tables in code. */
    public static DateCondition inSeasons(Season... seasons) {
        return new DateCondition(Optional.of(List.of(seasons)), Optional.empty(), Optional.empty(),
                MinMaxBounds.Ints.ANY, MinMaxBounds.Ints.ANY);
    }

    @Override
    public LootItemConditionType getType() {
        return CalendarLoot.DATE.get();
    }

    /** True if the calendar of the world the loot is rolled in matches right now. */
    @Override
    public boolean test(LootContext context) {
        return matches(Calendar.of(context.getLevel()));
    }

    /**
     * True if a calendar matches every field of this condition right now.
     *
     * <p>Season, phase, day and year are checked against today's date. The
     * moon is checked against the moon that is in the sky. It changes at
     * noon, so between midnight and noon it still belongs to yesterday's
     * date. "Fishing under a full moon" therefore works all night long (and
     * on the morning after, until noon).</p>
     */
    public boolean matches(Calendar calendar) {
        CalendarDate date = calendar.date();
        if (seasons.isPresent() && !seasons.get().contains(date.season())) {
            return false;
        }
        if (phases.isPresent() && !phases.get().contains(date.seasonPhase())) {
            return false;
        }
        if (moonPhases.isPresent() && !moonPhases.get().contains(calendar.moonPhase())) {
            return false;
        }
        return day.matches(date.dayOfSeason()) && year.matches(date.year());
    }

    /**
     * A list that may be written as a single value when it has one entry:
     * {@code "autumn"} means the same as {@code ["autumn"]}.
     */
    private static <T> Codec<List<T>> oneOrMore(Codec<T> element) {
        return Codec.either(element, element.listOf()).xmap(
                either -> either.map(List::of, list -> list),
                list -> list.size() == 1 ? Either.left(list.get(0)) : Either.right(list));
    }
}
