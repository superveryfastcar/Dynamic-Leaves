package io.github.superveryfastcar.calendar.loot;

import io.github.superveryfastcar.calendar.CalendarMod;
import net.minecraft.core.registries.Registries;
import net.minecraft.world.level.storage.loot.predicates.LootItemConditionType;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

/**
 * Registers Calendar's data-pack condition, {@code calendar:date}, with the
 * game. See {@link DateCondition} for what it does.
 */
public final class CalendarLoot {

    /** Collects what Calendar adds to the game's list of condition types. Hooked up in {@link CalendarMod}. */
    public static final DeferredRegister<LootItemConditionType> CONDITION_TYPES =
            DeferredRegister.create(Registries.LOOT_CONDITION_TYPE, CalendarMod.MOD_ID);

    /** The condition type {@code calendar:date}. */
    public static final DeferredHolder<LootItemConditionType, LootItemConditionType> DATE =
            CONDITION_TYPES.register("date", () -> new LootItemConditionType(DateCondition.CODEC));

    private CalendarLoot() {
    }
}
