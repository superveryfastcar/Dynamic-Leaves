package io.github.superveryfastcar.calendar.mixin;

import io.github.superveryfastcar.calendar.core.CalendarAccess;
import net.minecraft.world.level.dimension.DimensionType;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Calendar's only patch to the game: the moon phase comes from the calendar.
 *
 * <p>The game works out the moon phase in one single place, from the day
 * time alone (a new phase every day, eight days per cycle). Everything else
 * asks that place: the sky renderer, slime spawning, how strong mobs get,
 * cats, and other mods. Replacing the answer there makes the calendar's
 * moon the real moon everywhere at once, on the server and on the client,
 * without touching any of those users.</p>
 *
 * <p>If no calendar is known (a client on a server without this mod), the
 * game's own calculation is left alone.</p>
 */
@Mixin(DimensionType.class)
public abstract class DimensionTypeMixin {

    /**
     * Runs at the start of the game's moon calculation and, if a calendar is
     * known, answers in its place.
     *
     * @param dayTime the game's day time the phase is asked for
     * @param result  lets this method set the answer and skip the original calculation
     */
    @Inject(method = "moonPhase", at = @At("HEAD"), cancellable = true)
    private void calendar$moonPhaseFromCalendar(long dayTime, CallbackInfoReturnable<Integer> result) {
        int phase = CalendarAccess.moonPhase(dayTime);
        if (phase >= 0) {
            result.setReturnValue(phase);
        }
    }
}
