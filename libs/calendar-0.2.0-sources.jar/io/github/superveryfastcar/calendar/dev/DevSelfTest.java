package io.github.superveryfastcar.calendar.dev;

import io.github.superveryfastcar.calendar.CalendarMod;
import io.github.superveryfastcar.calendar.api.Calendar;
import io.github.superveryfastcar.calendar.api.event.CalendarEvent;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.client.Screenshot;
import net.minecraft.client.gui.screens.AccessibilityOnboardingScreen;
import net.minecraft.client.gui.screens.TitleScreen;
import net.minecraft.client.server.IntegratedServer;
import net.minecraft.core.registries.Registries;
import net.minecraft.world.Difficulty;
import net.minecraft.world.level.GameRules;
import net.minecraft.world.level.GameType;
import net.minecraft.world.level.LevelSettings;
import net.minecraft.world.level.WorldDataConfiguration;
import net.minecraft.world.level.levelgen.WorldOptions;
import net.minecraft.world.level.levelgen.presets.WorldPresets;
import net.minecraft.world.level.storage.LevelStorageSource;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ClientTickEvent;

/**
 * Development aid: checks Calendar in a real game client with nobody at
 * the keyboard, for example on a build machine that has no screen.
 *
 * <pre>./gradlew runClient -Pcalendar.selfTest=true</pre>
 *
 * <p>The automatic tests (the {@code gametest} package) run on a server
 * without any client. This fills the gap: it shows that the mod loads in a
 * real client, that the server's calendar really arrives there, that the
 * client's copy follows it through date changes, a real midnight, sunrise
 * and noon, the time being set back, and a pause, and that the moon in the
 * sky is the calendar's moon.</p>
 *
 * <p>It does nothing unless the system property
 * {@code calendar.dev.selfTest} is {@code true} (the Gradle flag above sets
 * it), and the whole {@code dev} package is left out of the released jar.</p>
 *
 * <h2>What it does</h2>
 * <ol>
 *   <li>Gets the game to the title screen, creates a fresh flat creative
 *       world and enters it.</li>
 *   <li>Works through {@link #STEPS}: each step runs a few commands on the
 *       world's server, waits, and then compares what the client shows
 *       with what the server says. For the moon steps it also saves a
 *       screenshot of the night sky straight above into the game's
 *       {@code screenshots} folder.</li>
 *   <li>Writes one line per check into the log, and at the end a line that
 *       starts with {@code [Calendar self test] RESULT:}. Then it closes
 *       the game.</li>
 * </ol>
 */
@EventBusSubscriber(modid = CalendarMod.MOD_ID, value = Dist.CLIENT)
public final class DevSelfTest {

    /** True when the self test was asked for on the command line. */
    private static final boolean ENABLED = Boolean.getBoolean("calendar.dev.selfTest");

    /** Name of the throwaway world. It is deleted and created again on every run. */
    private static final String WORLD_NAME = "calendar-self-test";

    /** Client ticks to wait after entering the world before the first step, so everything has loaded. */
    private static final int SETTLE_TICKS = 100;

    /** Give up and close the game this long after entering the world, whatever happened. */
    private static final long GIVE_UP_NANOS = 300_000_000_000L;

    /**
     * One step of the test.
     *
     * @param name         what the step is about, for the log
     * @param commands     commands to run on the server first (without the slash)
     * @param waitTicks    client ticks to wait after the commands
     * @param expectedDate the date both sides must show afterwards
     * @param expectedMoon the moon phase number the client's sky must have
     *                     afterwards (0 = full, 4 = new), or -1 to skip
     * @param screenshot   file name for a screenshot of the sky, or null for none
     */
    private record Step(String name, List<String> commands, int waitTicks, String expectedDate, int expectedMoon,
                        String screenshot) {
    }

    // The commands use the game's own day time, which is six hours behind
    // the calendar's clock: "time set 18000" is midnight, "time set 0" is
    // 06:00, "time set 6000" is noon. A fresh world starts on Autumn 1 at 06:00.
    private static final List<Step> STEPS = List.of(
            // 23:30, so that the moon stands almost straight overhead for the screenshots.
            new Step("joined: the starting date has arrived", List.of("weather clear", "time set 17500"), 40,
                    "Autumn 1, Year 1", 4, null),
            new Step("date set to the middle of summer: full moon", List.of("calendar set summer 8"), 40,
                    "Summer 8, Year 1", 0, "calendar-1-full-moon.png"),
            new Step("date set to the first day of summer: new moon", List.of("calendar set summer 1"), 40,
                    "Summer 1, Year 1", 4, "calendar-2-new-moon.png"),
            new Step("date set to day 5: first quarter", List.of("calendar set summer 5"), 40,
                    "Summer 5, Year 1", 6, "calendar-3-first-quarter.png"),
            // The night keeps its moon: the date changes at midnight, the moon at noon.
            new Step("a real midnight passes: next date, same moon", List.of("time set 17950"), 160,
                    "Summer 6, Year 1", 6, null),
            new Step("a real sunrise passes: same date, still the same moon", List.of("time set 23950"), 120,
                    "Summer 6, Year 1", 6, null),
            // The game's 5950 is just before noon. The game counts this as
            // setting the time back (its day counter starts over), the
            // calendar as later on the same day.
            new Step("a real noon passes: same date, the next moon, out of sight", List.of("time set 5950"), 120,
                    "Summer 6, Year 1", 7, null),
            new Step("time set to an evening hour: same date", List.of("time set 13000"), 60,
                    "Summer 6, Year 1", 7, null),
            new Step("time set back to a morning hour: the next day, never the day before", List.of("time set 1000"), 60,
                    "Summer 7, Year 1", 7, null),
            new Step("date paused while a midnight passes", List.of("gamerule doCalendarCycle false", "time set 17950"), 120,
                    "Summer 7, Year 1", 7, null),
            // The hardest case for the client: a few seconds after midnight
            // the clock is set back to just before it. The date must stay,
            // and then change once when midnight passes again.
            new Step("running again, time set back a few seconds across midnight, then midnight passes",
                    List.of("gamerule doCalendarCycle true", "time set 17950"), 120,
                    "Summer 8, Year 1", 7, null));

    /** Every date the client's copy changed to, in order. Filled by {@link #onClientDayChanged}. */
    private static final List<String> CLIENT_DATES = new ArrayList<>();

    /** The dates the client must have gone through for the steps above: no more, no less. */
    private static final List<String> EXPECTED_CLIENT_DATES = List.of(
            "Summer 8, Year 1", "Summer 1, Year 1", "Summer 5, Year 1", "Summer 6, Year 1", "Summer 7, Year 1",
            "Summer 8, Year 1");

    private static boolean worldRequested;
    private static long enteredWorldNanos;
    private static int ticksInWorld;
    private static int stepIndex = -1;
    private static int ticksLeftInStep;
    private static int checks;
    private static final List<String> FAILURES = new ArrayList<>();
    private static boolean finished;

    private DevSelfTest() {
    }

    /** Remembers every date change of the client's copy. */
    @SubscribeEvent
    public static void onClientDayChanged(CalendarEvent.DayChanged event) {
        if (ENABLED && event.isClientSide()) {
            CLIENT_DATES.add(event.getCurrent().toString());
            CalendarMod.LOGGER.info("[Calendar self test] The client's date changed: {} -> {}", event.getPrevious(), event.getCurrent());
        }
    }

    @SubscribeEvent
    public static void onClientTick(ClientTickEvent.Post event) {
        if (!ENABLED || finished) {
            return;
        }
        Minecraft minecraft = Minecraft.getInstance();
        long now = System.nanoTime();

        // Nobody is at the keyboard, and on a build machine the window never
        // has the focus. Without this the game would open its pause menu,
        // which stops a single-player world. (Changed in memory only.)
        minecraft.options.pauseOnLostFocus = false;

        // A first start shows an accessibility screen before the title screen.
        if (!worldRequested && minecraft.screen instanceof AccessibilityOnboardingScreen) {
            minecraft.options.onboardAccessibility = false;
            minecraft.setScreen(new TitleScreen());
            return;
        }

        // From the title screen, create and enter a flat test world.
        if (!worldRequested && minecraft.screen instanceof TitleScreen) {
            worldRequested = true;
            deleteOldTestWorld(minecraft);
            CalendarMod.LOGGER.info("[Calendar self test] Creating a flat test world.");
            LevelSettings settings = new LevelSettings(WORLD_NAME, GameType.CREATIVE, false,
                    Difficulty.PEACEFUL, true, new GameRules(), WorldDataConfiguration.DEFAULT);
            minecraft.createWorldOpenFlows().createFreshLevel(
                    WORLD_NAME, settings, new WorldOptions(0L, false, false),
                    registries -> registries.registryOrThrow(Registries.WORLD_PRESET)
                            .getHolderOrThrow(WorldPresets.FLAT).value().createWorldDimensions(),
                    minecraft.screen);
            return;
        }
        IntegratedServer server = minecraft.getSingleplayerServer();
        if (minecraft.player == null || minecraft.level == null || server == null) {
            return;
        }
        if (enteredWorldNanos == 0) {
            enteredWorldNanos = now;
        }
        if (now - enteredWorldNanos > GIVE_UP_NANOS) {
            FAILURES.add("gave up after five minutes");
            finish(minecraft);
            return;
        }

        // Look straight up, without the hotbar in the way: around midnight
        // the moon stands overhead.
        minecraft.options.hideGui = true;
        minecraft.player.setXRot(-90.0F);

        if (++ticksInWorld < SETTLE_TICKS) {
            return;
        }
        if (stepIndex >= 0 && --ticksLeftInStep > 0) {
            return;
        }

        // The waiting time of the current step is over: check it.
        if (stepIndex >= 0) {
            checkStep(minecraft, server, STEPS.get(stepIndex));
        }
        // Start the next step, or finish.
        stepIndex++;
        if (stepIndex >= STEPS.size()) {
            checks++;
            if (!CLIENT_DATES.equals(EXPECTED_CLIENT_DATES)) {
                FAILURES.add("the client went through the dates " + CLIENT_DATES + ", expected " + EXPECTED_CLIENT_DATES);
            }
            finish(minecraft);
            return;
        }
        Step step = STEPS.get(stepIndex);
        ticksLeftInStep = step.waitTicks();
        CalendarMod.LOGGER.info("[Calendar self test] Step {}: {}", stepIndex + 1, step.name());
        server.execute(() -> {
            for (String command : step.commands()) {
                server.getCommands().performPrefixedCommand(server.createCommandSourceStack().withSuppressedOutput(), command);
            }
        });
    }

    /** Compares what the client shows with what the server says and with what the step expects. */
    private static void checkStep(Minecraft minecraft, IntegratedServer server, Step step) {
        Calendar onClient = Calendar.of(minecraft.level);
        Calendar onServer = Calendar.of(server);
        String clientDate = onClient.date().toString();
        String serverDate = onServer.date().toString();
        int skyMoon = minecraft.level.getMoonPhase();

        expect(step, "the client's copy has heard from the server", onClient.isSynced() && onClient.isClientSide());
        expect(step, "server date is " + step.expectedDate() + " (it is " + serverDate + ")", step.expectedDate().equals(serverDate));
        expect(step, "client date is " + step.expectedDate() + " (it is " + clientDate + ")", step.expectedDate().equals(clientDate));
        expect(step, "client and server agree on being paused", onClient.isPaused() == onServer.isPaused());
        expect(step, "client and server agree on the day number (" + onServer.dayNumber() + ")",
                onClient.dayNumber() == onServer.dayNumber());
        if (step.expectedMoon() >= 0) {
            expect(step, "the client's sky shows moon phase " + step.expectedMoon() + " (it shows " + skyMoon + ")",
                    skyMoon == step.expectedMoon());
            expect(step, "the client's calendar names the same moon as its sky", onClient.moonPhase().ordinal() == skyMoon);
        }
        if (step.screenshot() != null) {
            Screenshot.grab(minecraft.gameDirectory, step.screenshot(), minecraft.getMainRenderTarget(), message -> { });
            CalendarMod.LOGGER.info("[Calendar self test] Saved screenshot {}", step.screenshot());
        }
    }

    private static void expect(Step step, String what, boolean holds) {
        checks++;
        if (holds) {
            CalendarMod.LOGGER.info("[Calendar self test] ok: {}", what);
        } else {
            CalendarMod.LOGGER.error("[Calendar self test] WRONG in step \"{}\": {}", step.name(), what);
            FAILURES.add(step.name() + ": " + what);
        }
    }

    /** Writes the result line and closes the game. */
    private static void finish(Minecraft minecraft) {
        finished = true;
        if (FAILURES.isEmpty()) {
            CalendarMod.LOGGER.info("[Calendar self test] RESULT: all {} checks passed. The client went through: {}", checks, CLIENT_DATES);
        } else {
            CalendarMod.LOGGER.error("[Calendar self test] RESULT: {} of {} checks FAILED: {}", FAILURES.size(), checks, FAILURES);
        }
        minecraft.stop();
    }

    /** Deletes the world of an earlier self test, so every run starts from the same state. */
    private static void deleteOldTestWorld(Minecraft minecraft) {
        LevelStorageSource saves = minecraft.getLevelSource();
        if (!saves.levelExists(WORLD_NAME)) {
            return;
        }
        try (LevelStorageSource.LevelStorageAccess access = saves.createAccess(WORLD_NAME)) {
            access.deleteLevel();
        } catch (IOException e) {
            CalendarMod.LOGGER.warn("[Calendar self test] Could not delete the old test world.", e);
        }
    }
}
