package io.github.superveryfastcar.calendar.api;

import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;

/**
 * One day of the calendar: a season, a day within it and a year, together
 * with everything that follows from them (moon phase, part of the season,
 * days left).
 *
 * <p>A date cannot be modified. It is safe to keep, to compare and to use
 * from any thread. Asking the world's {@link Calendar} for the current date
 * hands out the same object for the whole day, so doing that often costs
 * nothing.</p>
 *
 * <p>Dates are ordered by time: {@link #compareTo} and
 * {@link #daysUntil(CalendarDate)} work as expected. To store a date (in a
 * block entity, a player's data, a saved file), store its
 * {@link #epochDay()}, a single number, and turn it back with
 * {@link CalendarRules#dateOf(long)}.</p>
 */
public final class CalendarDate implements Comparable<CalendarDate> {

    private final CalendarRules rules;
    private final long epochDay;
    private final int year;
    private final Season season;
    private final int dayOfSeason;
    private final int dayOfYear;

    /** Dates are made by {@link CalendarRules#dateOf(long)}, which does the arithmetic. */
    CalendarDate(CalendarRules rules, long epochDay, int year, Season season, int dayOfSeason, int dayOfYear) {
        this.rules = rules;
        this.epochDay = epochDay;
        this.year = year;
        this.season = season;
        this.dayOfSeason = dayOfSeason;
        this.dayOfYear = dayOfYear;
    }

    // ------------------------------------------------------------------
    // What day it is
    // ------------------------------------------------------------------

    /** The rules this date was calculated with. */
    public CalendarRules rules() {
        return rules;
    }

    /**
     * The day as one ever-growing number: 0 is the first day of spring in
     * year 1, 1 the day after, and so on. This is the best form for storing
     * a date and for arithmetic with dates.
     */
    public long epochDay() {
        return epochDay;
    }

    /** The year. A calendar starts in year 1, and every year begins with spring. */
    public int year() {
        return year;
    }

    /** The season. */
    public Season season() {
        return season;
    }

    /** The day within the season, starting at 1. */
    public int dayOfSeason() {
        return dayOfSeason;
    }

    /** The day within the year, starting at 1 on the first day of spring. */
    public int dayOfYear() {
        return dayOfYear;
    }

    /** How many days this date's season has. */
    public int seasonLength() {
        return rules.seasonLength(season);
    }

    /** How many days a year has. */
    public int yearLength() {
        return rules.yearLength();
    }

    // ------------------------------------------------------------------
    // What follows from it
    // ------------------------------------------------------------------

    /** Whether this day is in the early, middle or late third of its season. */
    public SeasonPhase seasonPhase() {
        return SeasonPhase.of(dayOfSeason, seasonLength());
    }

    /**
     * The moon phase that belongs to this day: the moon of the night that
     * begins on this day's evening and ends the next morning. See
     * {@link CalendarRules#moonPhaseOn}. For the moon that is in the sky
     * right now, ask {@link Calendar#moonPhase()}.
     */
    public MoonPhase moonPhase() {
        return rules.moonPhaseOn(epochDay);
    }

    /** True on the first day of a season. */
    public boolean isFirstDayOfSeason() {
        return dayOfSeason == 1;
    }

    /** True on the last day of a season. */
    public boolean isLastDayOfSeason() {
        return dayOfSeason == seasonLength();
    }

    /**
     * How many days of this season come after this one. 0 on the last day
     * of the season. A crop can use this to tell whether it would still
     * ripen in time.
     */
    public int daysLeftInSeason() {
        return seasonLength() - dayOfSeason;
    }

    /**
     * How many days it is until the next season begins: 1 on the last day of
     * a season, the season's full length on its first day.
     */
    public int daysUntilNextSeason() {
        return daysLeftInSeason() + 1;
    }

    /**
     * How many days it is until the given season begins the next time.
     * Always at least 1: on the first day of autumn, the next start of
     * autumn is a whole year away.
     */
    public int daysUntilStartOf(Season target) {
        int days = rules.firstDayOfYear(target) - dayOfYear;
        return days > 0 ? days : days + yearLength();
    }

    /**
     * A number that grows by one every time a new season begins: this
     * date's season counted from the start of the calendar. Two dates are in
     * the very same season (not just in "an autumn", but in the same autumn
     * of the same year) exactly when this number is equal.
     */
    public long seasonNumber() {
        return (year - 1L) * 4 + season.ordinal();
    }

    // ------------------------------------------------------------------
    // Arithmetic
    // ------------------------------------------------------------------

    /**
     * The date a number of days after this one, or before it if the number is negative.
     *
     * @return this same object if {@code days} is 0
     */
    public CalendarDate plusDays(long days) {
        return days == 0 ? this : rules.dateOf(epochDay + days);
    }

    /**
     * How many days lie between this date and another one. Positive if the
     * other date is later, negative if it is earlier.
     */
    public long daysUntil(CalendarDate other) {
        return other.epochDay - epochDay;
    }

    /** True if this date is later than the other one. */
    public boolean isAfter(CalendarDate other) {
        return epochDay > other.epochDay;
    }

    /** True if this date is earlier than the other one. */
    public boolean isBefore(CalendarDate other) {
        return epochDay < other.epochDay;
    }

    /** Earlier dates come first. */
    @Override
    public int compareTo(CalendarDate other) {
        return Long.compare(epochDay, other.epochDay);
    }

    // ------------------------------------------------------------------
    // Showing it
    // ------------------------------------------------------------------

    /**
     * The date for showing to players, translated on their client:
     * "Autumn 3, Year 1". The language key is {@code calendar.date}, with
     * the season's name, the day and the year as its arguments.
     */
    public MutableComponent displayName() {
        return Component.translatable("calendar.date", season.displayName(), dayOfSeason, year);
    }

    /** The date in plain English for logs and debugging, for example {@code Autumn 3, Year 1}. */
    @Override
    public String toString() {
        String name = season.getSerializedName();
        return Character.toUpperCase(name.charAt(0)) + name.substring(1) + " " + dayOfSeason + ", Year " + year;
    }

    /** Two dates are equal when they are the same day under the same rules. */
    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        return other instanceof CalendarDate that && epochDay == that.epochDay && rules.equals(that.rules);
    }

    @Override
    public int hashCode() {
        return Long.hashCode(epochDay) * 31 + rules.hashCode();
    }
}
