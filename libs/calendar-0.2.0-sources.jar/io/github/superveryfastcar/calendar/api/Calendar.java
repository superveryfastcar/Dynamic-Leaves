package io.github.superveryfastcar.calendar.api;

import io.github.superveryfastcar.calendar.core.CalendarAccess;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.level.LevelReader;

/**
 * The calendar of a world: what day it is, and where in the day, the season
 * and the year the world currently stands.
 *
 * <h2>Getting it</h2>
 * <pre>{@code
 * Calendar calendar = Calendar.of(level);      // works on the server and on the client
 * CalendarDate today = calendar.date();
 * if (today.season() == Season.WINTER) { ... }
 * }</pre>
 * A world has one calendar. Every dimension shows the same date, because the
 * game itself runs every dimension on the overworld's clock.
 *
 * <h2>Reading is always cheap and always safe</h2>
 * Every method here only reads a small ready-made record. Nothing is looked
 * up, loaded or created (except {@link #blend()}, which creates one tiny
 * object). It is fine to call these methods many times per tick, per block
 * or per rendered frame, and from any thread, including world generation.
 *
 * <h2>The day and its clock</h2>
 * A calendar day runs from midnight to midnight on a 24-hour clock, with
 * 1000 game ticks per hour. {@link #tickOfDay()} counts from midnight, so
 * 6000 is 06:00 and 18000 is 18:00. The game's own time of day (the number
 * {@code /time set} takes) counts from 06:00 instead. Calendar does the
 * conversion for you. A new world starts at 06:00, so its first calendar
 * day begins there.
 *
 * <h2>Sunrise and sunset</h2>
 * In the unmodded game the sun rises at 06:00 and sets at 18:00 every day.
 * A mod can move them through the year (see {@link SunTimes}). Whether one
 * does or not, {@link #sunriseTick()}, {@link #sunsetTick()} and
 * {@link #isSunUp()} tell you how it is today.
 *
 * <h2>When the date changes</h2>
 * At midnight. The calendar moves forward at the end of a game tick, never
 * in the middle of one. Whenever {@link #date()} starts returning a new day, the matching
 * {@link io.github.superveryfastcar.calendar.api.event.CalendarEvent.DayChanged}
 * event has just been sent. A mod that recalculates something on that event
 * can therefore never be caught with stale values.
 *
 * <h2>Server and client</h2>
 * The server owns the calendar. Each client keeps a copy that the server
 * sets up when the player joins and corrects whenever the date is changed
 * by hand. In between, the client works out the date from its own copy of
 * the world's clock, so nothing has to be sent every second. Client code
 * reads the calendar exactly like server code. Changing the date is only
 * possible on the server, through {@link ServerCalendar}.
 */
public interface Calendar {

    /**
     * The calendar of the world a level belongs to.
     *
     * <p>Accepts everything that is or wraps a level, on both sides: a
     * server level, the client's level, a world-generation region. Never
     * returns null. If no calendar is running at all (this happens only
     * while the game is still starting or already shutting down), the
     * result is a stand-in that shows the configured starting date and
     * reports {@link #isSynced()} as false.</p>
     */
    static Calendar of(LevelReader level) {
        return CalendarAccess.of(level);
    }

    /**
     * The server's calendar, with the methods to change the date.
     *
     * @throws IllegalStateException if the server's world is not loaded yet
     */
    static ServerCalendar of(MinecraftServer server) {
        return CalendarAccess.of(server);
    }

    /**
     * The calendar for code that has no level at hand, picked by the thread
     * that asks: on the server thread the server's calendar, anywhere else
     * the client's copy if it has one, otherwise whatever is running.
     *
     * <p>This is meant for the rare places where the game itself gives no
     * level, such as a patch on the game's sun or moon calculation. If you
     * have a level, use {@link #of(LevelReader)}. Never returns null (see
     * there for the stand-in).</p>
     */
    static Calendar ofCurrentThread() {
        return CalendarAccess.ofCurrentThread();
    }

    // ------------------------------------------------------------------
    // The date
    // ------------------------------------------------------------------

    /** Today's date. The same object is handed out all day, so calling this often costs nothing. */
    CalendarDate date();

    /** The rules this calendar runs on: season lengths and the moon setting. */
    CalendarRules rules();

    /**
     * Today's number in this world's own count of days: 1 on the day the
     * world's calendar started, 2 on the day after, and so on. This is the
     * number for "Day 45".
     *
     * <p>The count goes up whenever the calendar moves on to a later day by
     * itself: as time passes, when players sleep, and when the clock is
     * moved with {@code /time}. It does <em>not</em> change when the date
     * is set by hand ({@code /calendar set}, {@link ServerCalendar#setDate},
     * {@link ServerCalendar#addDays}): that changes what today is called,
     * not how many days the world has seen. While the date is paused, the
     * count stands still with it.</p>
     *
     * <p>A world that already had a calendar before Calendar counted days
     * (before version 0.2.0) counts from the starting date in its config.</p>
     */
    long dayNumber();

    /** Today's season. Short for {@code date().season()}. */
    default Season season() {
        return date().season();
    }

    /**
     * The moon that is in the sky right now. In the afternoon, while it is
     * still below the horizon, this is already the moon of the coming night.
     *
     * <p>The moon does not change at midnight with the date. It changes at
     * noon, when it is on the far side of the world and nobody can see it.
     * A night therefore has one moon from beginning to end. From noon on
     * this is today's moon ({@code date().moonPhase()}), before noon it is
     * still the moon of the night that just ended
     * ({@code date().plusDays(-1).moonPhase()}). This is exactly what the
     * game draws in the sky. For "tonight's moon" at any time of day, use
     * {@code date().moonPhase()}.</p>
     */
    default MoonPhase moonPhase() {
        CalendarDate today = date();
        boolean beforeNoon = tickOfDay() < CalendarRules.NOON_TICK;
        return (beforeNoon && !isPaused()) ? today.plusDays(-1).moonPhase() : today.moonPhase();
    }

    // ------------------------------------------------------------------
    // The time within the day, the season and the year
    // ------------------------------------------------------------------

    /**
     * The time of day on the calendar's clock: game ticks since midnight,
     * from 0 to 23999. 0 is midnight, 6000 is 06:00, 12000 noon and 18000
     * is 18:00. An hour has 1000 ticks.
     */
    int tickOfDay();

    /** The hour on the 24-hour clock, from 0 to 23. */
    default int hour() {
        return tickOfDay() / CalendarRules.TICKS_PER_HOUR;
    }

    /** The minute within the hour, from 0 to 59. (A minute lasts a little under 17 ticks.) */
    default int minute() {
        return tickOfDay() % CalendarRules.TICKS_PER_HOUR * 60 / CalendarRules.TICKS_PER_HOUR;
    }

    /** How much of the current day has passed, from 0 (midnight) to just under 1 (the next midnight). */
    default double dayProgress() {
        return tickOfDay() / (double) CalendarRules.TICKS_PER_DAY;
    }

    /** How much of the current season has passed, from 0 to just under 1. Changes every tick. */
    default double seasonProgress() {
        CalendarDate date = date();
        return (date.dayOfSeason() - 1 + dayProgress()) / date.seasonLength();
    }

    /** How much of the current year has passed, from 0 to just under 1. Changes every tick. */
    default double yearProgress() {
        return yearDay() / rules().yearLength();
    }

    /**
     * The current moment as days since the start of the year, with the time
     * of day as the fraction: 0.0 at midnight when the first day of spring
     * begins, 0.5 at noon of that day. This is the input for
     * {@link CalendarRules#summerness(double)} and
     * {@link CalendarRules#blendAt(double)} when you want to shift them in time.
     */
    default double yearDay() {
        return date().dayOfYear() - 1 + dayProgress();
    }

    /**
     * A smooth wave over the year, right now: +1 in the middle of summer,
     * -1 in the middle of winter, 0 in the middle of spring and of autumn.
     * Changes a tiny bit every tick. See {@link CalendarRules#summerness(double)}.
     */
    default double summerness() {
        return rules().summerness(yearDay());
    }

    /**
     * The current moment as a mix of two neighbouring seasons, for values
     * that should glide from season to season. See {@link SeasonBlend}.
     */
    default SeasonBlend blend() {
        return rules().blendAt(yearDay());
    }

    // ------------------------------------------------------------------
    // The sun
    // ------------------------------------------------------------------

    /**
     * When the sun rises today, on the calendar's clock: ticks since
     * midnight. 6000 (06:00) unless a mod moves the sun, see {@link SunTimes}.
     * Fixed for the whole day. A new value applies from midnight.
     */
    int sunriseTick();

    /**
     * When the sun sets today, on the calendar's clock: ticks since
     * midnight. 18000 (18:00) unless a mod moves the sun, see {@link SunTimes}.
     * Fixed for the whole day. A new value applies from midnight.
     */
    int sunsetTick();

    /** When the sun rises on another day. See {@link #sunriseTick()}. */
    int sunriseTickOn(long epochDay);

    /** When the sun sets on another day. See {@link #sunsetTick()}. */
    int sunsetTickOn(long epochDay);

    /**
     * True from sunrise to sunset: {@code sunriseTick() <= tickOfDay() < sunsetTick()}.
     *
     * <p>This goes by the clock alone. The game's own idea of "day"
     * ({@code level.isDay()}) also looks at the weather, and switches a
     * little before sunrise and after sunset, while the sky is still
     * bright.</p>
     */
    default boolean isSunUp() {
        int tick = tickOfDay();
        return tick >= sunriseTick() && tick < sunsetTick();
    }

    /**
     * Where one of the four daily moments lies today, on the calendar's
     * clock: 0 for midnight, {@link #sunriseTick()} for dawn, 12000 for
     * noon, {@link #sunsetTick()} for dusk.
     */
    default int tickOf(DayMoment moment) {
        return switch (moment) {
            case MIDNIGHT -> 0;
            case DAWN -> sunriseTick();
            case NOON -> CalendarRules.NOON_TICK;
            case DUSK -> sunsetTick();
        };
    }

    /**
     * The calendar day one of the game's day times falls on, the way the
     * calendar counts right now.
     *
     * <p>For code that is handed a day time instead of "now", for example a
     * patch on a game method that takes one. While the date is paused,
     * every day time falls on today.</p>
     *
     * @param gameDayTime a day time as the game counts it ({@code level.getDayTime()})
     * @return the epoch day, see {@link CalendarDate#epochDay()}
     */
    long epochDayAt(long gameDayTime);

    // ------------------------------------------------------------------
    // Counters for measuring how much time has passed
    // ------------------------------------------------------------------

    /**
     * The current moment as one number: game ticks since the midnight that
     * began epoch day 0. Store it to remember "when" and subtract two of
     * them to get a duration in ticks ({@link CalendarRules#TICKS_PER_DAY}
     * per day).
     *
     * <p>Unlike the game's own day time, this number follows the calendar:
     * it does not fall back to zero when someone types {@code /time set}.</p>
     *
     * <p>To count whole days instead (how many midnights have passed, which
     * is what crops and other once-a-day things need), use
     * {@code date().epochDay()} and see {@link CalendarRules#daysInSeasons}.</p>
     */
    default long epochTick() {
        return date().epochDay() * CalendarRules.TICKS_PER_DAY + tickOfDay();
    }

    // ------------------------------------------------------------------
    // State
    // ------------------------------------------------------------------

    /**
     * True while the date is paused by the game rule
     * {@code doCalendarCycle = false}. The sun and the moon keep moving, but
     * every midnight starts the same date again. Mods that advance things once
     * per day may want to stop while this is true.
     */
    boolean isPaused();

    /** True for a client's copy of the calendar, false for the server's own. */
    boolean isClientSide();

    /**
     * True once this calendar shows the real date. Always true on a running
     * server. On a client it becomes true when the server's calendar has
     * arrived shortly after joining, and stays false on a server that does
     * not have this mod. While false, the calendar shows the starting date
     * from this computer's own config.
     */
    boolean isSynced();
}
