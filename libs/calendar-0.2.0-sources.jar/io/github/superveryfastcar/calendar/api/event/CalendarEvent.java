package io.github.superveryfastcar.calendar.api.event;

import io.github.superveryfastcar.calendar.api.Calendar;
import io.github.superveryfastcar.calendar.api.CalendarDate;
import io.github.superveryfastcar.calendar.api.DayMoment;
import io.github.superveryfastcar.calendar.api.Season;
import net.neoforged.bus.api.Event;

/**
 * The events Calendar sends when the date moves. They arrive on NeoForge's
 * main game bus ({@code NeoForge.EVENT_BUS}).
 *
 * <pre>{@code
 * @SubscribeEvent
 * public static void onNewDay(CalendarEvent.DayChanged event) {
 *     if (event.isClientSide()) return;          // see "Both sides" below
 *     ...
 * }
 * }</pre>
 *
 * Listen for one of the four events inside this class. {@code CalendarEvent}
 * itself is only their common base and cannot be listened for (NeoForge
 * does not allow that for base classes).
 *
 * <h2>When they are sent</h2>
 * At the end of the game tick in which the clock passed the point in
 * question. The calendar is updated first, so inside a listener
 * {@link #getCalendar()} already shows the new state. Within one tick the
 * order is always the order of time. At midnight that is: the day change,
 * then the season change if there is one, then the {@code MIDNIGHT} moment
 * of the new day.
 *
 * <h2>Both sides</h2>
 * The server sends these events for its calendar, and every client sends
 * them for its own copy, so client-only code (colors, sounds, the screen)
 * can react without any networking of its own. In a single-player game both
 * live in the same program and you receive both, on different threads.
 * Check {@link #isClientSide()} and ignore the side you do not mean.
 *
 * <h2>Time jumps</h2>
 * Days can pass without being played: players sleep, an admin types
 * {@code /time add} or {@code /calendar set}. Calendar does not replay the
 * skipped days one by one. It sends <em>one</em> {@link DayChanged} that
 * says how many days went by. If your mod must do something for every
 * single day, use that number, or better, the counter described at
 * {@link io.github.superveryfastcar.calendar.api.CalendarRules#daysInSeasons},
 * which also covers chunks that were not loaded at the time.
 *
 * <p>None of these events can be cancelled.</p>
 */
public abstract class CalendarEvent extends Event {

    private final Calendar calendar;

    protected CalendarEvent(Calendar calendar) {
        this.calendar = calendar;
    }

    /** The calendar this event is about, already showing the new state. */
    public Calendar getCalendar() {
        return calendar;
    }

    /** True if this event comes from a client's copy of the calendar, false if it comes from the server. */
    public boolean isClientSide() {
        return calendar.isClientSide();
    }

    /**
     * The calendar has just become available or was replaced as a whole.
     *
     * <p>On the server: once, when the world has been loaded. On a client:
     * when the server's calendar arrives after joining a world. This is the
     * moment to set up everything that depends on the date. No
     * {@link DayChanged} is sent for this first date, because there is no
     * previous day to compare with.</p>
     */
    public static final class Loaded extends CalendarEvent {

        public Loaded(Calendar calendar) {
            super(calendar);
        }
    }

    /**
     * The date has changed. Normally that means midnight has passed.
     *
     * <p>After sleeping through a night, {@link #daysPassed()} is 1 as at
     * any other midnight. After a larger jump it is larger, and after an
     * admin moved the date back it is negative.</p>
     */
    public static final class DayChanged extends CalendarEvent {

        private final CalendarDate previous;
        private final CalendarDate current;

        public DayChanged(Calendar calendar, CalendarDate previous, CalendarDate current) {
            super(calendar);
            this.previous = previous;
            this.current = current;
        }

        /** The date before the change. */
        public CalendarDate getPrevious() {
            return previous;
        }

        /** The date now. The same as {@code getCalendar().date()}. */
        public CalendarDate getCurrent() {
            return current;
        }

        /** How many days the date moved: 1 at a normal midnight, more after a jump, negative after a set-back. */
        public long daysPassed() {
            return current.epochDay() - previous.epochDay();
        }
    }

    /**
     * A different season has begun. Sent right after the {@link DayChanged}
     * of the same moment.
     *
     * <p>"Different" means a different season of a different or the same
     * year. A jump of exactly one year, from one autumn into the next,
     * also sends this event, even though {@link #getPreviousSeason()} and
     * {@link #getSeason()} are then equal.</p>
     */
    public static final class SeasonChanged extends CalendarEvent {

        private final CalendarDate previous;
        private final CalendarDate current;

        public SeasonChanged(Calendar calendar, CalendarDate previous, CalendarDate current) {
            super(calendar);
            this.previous = previous;
            this.current = current;
        }

        /** The date before the change. */
        public CalendarDate getPrevious() {
            return previous;
        }

        /** The date now. */
        public CalendarDate getCurrent() {
            return current;
        }

        /** The season before the change. */
        public Season getPreviousSeason() {
            return previous.season();
        }

        /** The season now. */
        public Season getSeason() {
            return current.season();
        }
    }

    /**
     * The clock has passed midnight, dawn, noon or dusk. Dawn and dusk
     * are the real sunrise and sunset of the day: 06:00 and 18:00, unless a
     * mod moves the sun (see
     * {@link io.github.superveryfastcar.calendar.api.SunTimes}).
     *
     * <p>Moments are announced in the order of time, and a moment is never
     * skipped silently: if the clock jumps over one (sleeping,
     * {@code /time set}), it is still announced, as long as the jump stays
     * within the same day or lands in the next one. After a jump over
     * several days only the moments of the day the clock landed in are
     * announced.</p>
     *
     * <p>Moments belong to the clock, not to the date. They keep coming
     * while the date is paused, and changing the date with
     * {@code /calendar set} announces none. One side effect when a mod
     * moves the sun: if the date is set by command to a day with a very
     * different sunrise or sunset, that day's dawn or dusk can be announced
     * twice, or not at all.</p>
     */
    public static final class MomentReached extends CalendarEvent {

        private final DayMoment moment;
        private final CalendarDate date;

        public MomentReached(Calendar calendar, DayMoment moment, CalendarDate date) {
            super(calendar);
            this.moment = moment;
            this.date = date;
        }

        /** Which moment was reached. */
        public DayMoment getMoment() {
            return moment;
        }

        /**
         * The date the moment belongs to. For {@code MIDNIGHT} this is the
         * day that is just beginning. It can differ from
         * {@code getCalendar().date()} when the clock jumped past a moment
         * and past the following midnight in the same tick, for example
         * past dusk when players sleep.
         */
        public CalendarDate getDate() {
            return date;
        }
    }
}
