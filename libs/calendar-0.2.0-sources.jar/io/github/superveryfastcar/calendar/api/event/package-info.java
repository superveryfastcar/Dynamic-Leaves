/**
 * The events Calendar sends. See
 * {@link io.github.superveryfastcar.calendar.api.event.CalendarEvent}.
 */
package io.github.superveryfastcar.calendar.api.event;
