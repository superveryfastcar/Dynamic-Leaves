package io.github.superveryfastcar.calendar.api;

import java.util.Set;

/**
 * The fixed rules of a world's calendar: how many days each season has and
 * how the moon behaves. From these rules alone, any day number can be turned
 * into a date and back.
 *
 * <p>Rules never change while a world is running. They come from the config
 * file of whoever hosts the world and are sent to every player who joins, so
 * both sides always calculate with the same numbers. An object of this class
 * cannot be modified, which makes it safe to keep and to use from any
 * thread.</p>
 *
 * <h2>How days are counted</h2>
 * A calendar day runs from midnight to midnight, like a 24-hour clock.
 * Calendar numbers days with one ever-growing number, the <em>epoch day</em>.
 * Epoch day 0 is the first day of spring in year 1. Every date is just
 * another way to write an epoch day, which is why comparing dates, counting
 * days between them and adding days are all simple arithmetic.
 *
 * <p>Seasons may have different lengths. Nothing in Calendar assumes that
 * they are equal.</p>
 */
public final class CalendarRules {

    /** Length of a day in game ticks. The game's own day has the same length. */
    public static final int TICKS_PER_DAY = 24000;

    /** Length of an hour on the calendar's 24-hour clock, in game ticks. */
    public static final int TICKS_PER_HOUR = 1000;

    /**
     * How far the calendar's clock is ahead of the game's own time of day,
     * in ticks: six hours. The game starts counting a day at 06:00, the
     * calendar at midnight, so
     * {@code calendar tick = (game time of day + 6000) mod 24000}.
     * See {@link #clockTickOf(long)}.
     */
    public static final int GAME_TIME_SHIFT = 6000;

    /** Noon on the calendar's clock, in ticks since midnight: 12:00. The sun is at its highest. */
    public static final int NOON_TICK = 12000;

    /** Sunrise when no mod moves the sun, in ticks since midnight: 06:00. For today's real sunrise see {@link Calendar#sunriseTick()}. */
    public static final int DEFAULT_SUNRISE_TICK = 6000;

    /** Sunset when no mod moves the sun, in ticks since midnight: 18:00. For today's real sunset see {@link Calendar#sunsetTick()}. */
    public static final int DEFAULT_SUNSET_TICK = 18000;

    /** The shortest season the rules accept, in days. */
    public static final int MIN_SEASON_DAYS = 1;

    /** The longest season the rules accept, in days. */
    public static final int MAX_SEASON_DAYS = 1000;

    /** The rules a world gets when nobody changed the config: four 14-day seasons and a moon that follows them. */
    public static final CalendarRules DEFAULT = new CalendarRules(14, 14, 14, 14, true);

    /** Days per season, indexed by {@link Season#ordinal()}. */
    private final int[] seasonDays;

    /** On which day of the year each season begins, counted from 0, indexed by {@link Season#ordinal()}. */
    private final int[] seasonStart;

    /** Days per year: the four season lengths added up. */
    private final int yearDays;

    /** Whether the moon follows the seasons. See {@link #moonPhaseOn}. */
    private final boolean seasonalMoon;

    /**
     * Creates a set of rules.
     *
     * @param springDays   days of spring, {@value #MIN_SEASON_DAYS} to {@value #MAX_SEASON_DAYS}
     * @param summerDays   days of summer, same limits
     * @param autumnDays   days of autumn, same limits
     * @param winterDays   days of winter, same limits
     * @param seasonalMoon true if the moon follows the seasons, false for
     *                     the game's usual eight-day cycle
     * @throws IllegalArgumentException if a season length is outside the limits
     */
    public CalendarRules(int springDays, int summerDays, int autumnDays, int winterDays, boolean seasonalMoon) {
        this.seasonDays = new int[] {springDays, summerDays, autumnDays, winterDays};
        this.seasonStart = new int[4];
        int total = 0;
        for (int i = 0; i < 4; i++) {
            int days = seasonDays[i];
            if (days < MIN_SEASON_DAYS || days > MAX_SEASON_DAYS) {
                throw new IllegalArgumentException("A season must have " + MIN_SEASON_DAYS + " to "
                        + MAX_SEASON_DAYS + " days, but " + Season.byIndex(i).getSerializedName() + " has " + days);
            }
            seasonStart[i] = total;
            total += days;
        }
        this.yearDays = total;
        this.seasonalMoon = seasonalMoon;
    }

    // ------------------------------------------------------------------
    // The plain numbers
    // ------------------------------------------------------------------

    /**
     * Turns one of the game's day times into the time of day on the
     * calendar's clock.
     *
     * @param gameDayTime a day time as the game counts it ({@code level.getDayTime()}), any size
     * @return ticks since midnight, 0 to 23999
     */
    public static int clockTickOf(long gameDayTime) {
        return (int) Math.floorMod(gameDayTime + GAME_TIME_SHIFT, (long) TICKS_PER_DAY);
    }

    /** How many days the given season has. */
    public int seasonLength(Season season) {
        return seasonDays[season.ordinal()];
    }

    /** How many days a year has: the four season lengths added up. */
    public int yearLength() {
        return yearDays;
    }

    /**
     * On which day of the year the given season begins, counted from 1.
     * Spring always begins on day 1.
     */
    public int firstDayOfYear(Season season) {
        return seasonStart[season.ordinal()] + 1;
    }

    /**
     * Whether the moon follows the seasons (true) or runs through the game's
     * usual eight-day cycle (false). See {@link #moonPhaseOn}.
     */
    public boolean seasonalMoon() {
        return seasonalMoon;
    }

    // ------------------------------------------------------------------
    // Dates
    // ------------------------------------------------------------------

    /**
     * Turns an epoch day into a date.
     *
     * @param epochDay the day number; 0 is the first day of spring in year 1.
     *                 Negative numbers are days before that and give year 0,
     *                 -1 and so on.
     */
    public CalendarDate dateOf(long epochDay) {
        long yearFromZero = Math.floorDiv(epochDay, (long) yearDays);
        int dayOfYearFromZero = (int) Math.floorMod(epochDay, (long) yearDays);
        Season season = seasonOnDayOfYear(dayOfYearFromZero);
        int year = (int) Math.max(Integer.MIN_VALUE, Math.min(Integer.MAX_VALUE, yearFromZero + 1));
        return new CalendarDate(this, epochDay, year, season,
                dayOfYearFromZero - seasonStart[season.ordinal()] + 1, dayOfYearFromZero + 1);
    }

    /**
     * Turns a date into its epoch day. The opposite of {@link #dateOf}.
     *
     * @param year        the year; the first year is 1
     * @param season      the season
     * @param dayOfSeason the day within the season, starting at 1
     * @throws IllegalArgumentException if the season does not have that day
     */
    public long epochDayOf(int year, Season season, int dayOfSeason) {
        int length = seasonLength(season);
        if (dayOfSeason < 1 || dayOfSeason > length) {
            throw new IllegalArgumentException(season.getSerializedName() + " has days 1 to " + length
                    + ", there is no day " + dayOfSeason);
        }
        return (year - 1L) * yearDays + seasonStart[season.ordinal()] + (dayOfSeason - 1);
    }

    /** The season a day belongs to. Shorter than {@code dateOf(epochDay).season()} and creates no object. */
    public Season seasonOn(long epochDay) {
        return seasonOnDayOfYear((int) Math.floorMod(epochDay, (long) yearDays));
    }

    /** The season of a day of the year counted from 0. */
    private Season seasonOnDayOfYear(int dayOfYearFromZero) {
        // Three comparisons at most. A loop over four fixed entries is as
        // fast as anything cleverer and easier to read.
        for (int i = 3; i > 0; i--) {
            if (dayOfYearFromZero >= seasonStart[i]) {
                return Season.byIndex(i);
            }
        }
        return Season.SPRING;
    }

    // ------------------------------------------------------------------
    // The moon
    // ------------------------------------------------------------------

    /**
     * The moon phase that belongs to a given day: the moon of the night
     * that begins on that day's evening.
     *
     * <p>A night spans two dates, because the date changes at midnight. The
     * moon does not change in the middle of a night. It changes at noon,
     * while it is out of sight, so a night keeps the phase of the day it
     * began on. "The full moon of day 8" is the night from day 8 to day 9.
     * For the moon that is in the sky at this very moment, ask
     * {@link Calendar#moonPhase()}.</p>
     *
     * <h4>When the moon follows the seasons ({@link #seasonalMoon()} is true)</h4>
     * Every season is one trip of the moon from new to full and back:
     * <ul>
     *   <li>The first day of a season has a new moon. Its night is the
     *       darkest of the season.</li>
     *   <li>The day in the middle has the full moon. It is the only full
     *       moon of the season. (In a 14-day season that is day 8.)</li>
     *   <li>Between them the moon grows through its three waxing phases,
     *       and after the full moon it shrinks through its three waning
     *       phases, each lasting as equally long as the season's length
     *       allows. In a 14-day season each of these phases lasts two
     *       days.</li>
     * </ul>
     * A season of fewer than eight days cannot show all eight phases and
     * skips some of the in-between ones. A one-day season only ever has a
     * new moon.
     *
     * <h4>When it does not</h4>
     * The moon runs through the game's usual eight-day cycle, one phase per
     * day, counted on calendar days (epoch day 0 has a full moon).
     *
     * <p>In both cases the moon is a pure function of the date. Changing the
     * date changes the moon with it, and a paused calendar has a paused
     * moon.</p>
     */
    public MoonPhase moonPhaseOn(long epochDay) {
        if (!seasonalMoon) {
            return MoonPhase.byIndex((int) Math.floorMod(epochDay, 8L));
        }
        int dayOfYearFromZero = (int) Math.floorMod(epochDay, (long) yearDays);
        int season = seasonOnDayOfYear(dayOfYearFromZero).ordinal();
        return seasonalMoonPhase(dayOfYearFromZero - seasonStart[season], seasonDays[season]);
    }

    /**
     * The seasonal moon rule itself. See {@link #moonPhaseOn} for the rule in words.
     *
     * @param day    the day within the season, counted from 0
     * @param length the season's length in days
     */
    private static MoonPhase seasonalMoonPhase(int day, int length) {
        if (day == 0) {
            return MoonPhase.NEW_MOON;
        }
        int fullMoonDay = length / 2;
        if (day == fullMoonDay) {
            return MoonPhase.FULL_MOON;
        }
        if (day < fullMoonDay) {
            // Growing: spread the three waxing phases (game numbers 5, 6, 7)
            // evenly over the days between the new and the full moon.
            int daysBetween = fullMoonDay - 1;
            int step = (int) ((day - 1) * 3L / daysBetween);
            return MoonPhase.byIndex(5 + Math.min(2, step));
        }
        // Shrinking: spread the three waning phases (game numbers 1, 2, 3)
        // evenly over the days after the full moon.
        int daysAfter = length - 1 - fullMoonDay;
        int step = (int) ((day - fullMoonDay - 1) * 3L / daysAfter);
        return MoonPhase.byIndex(1 + Math.min(2, step));
    }

    // ------------------------------------------------------------------
    // Counting days
    // ------------------------------------------------------------------

    /**
     * Counts the days in a span that fall into any of the given seasons.
     *
     * <p>This is what a crop needs to catch up after its chunk was unloaded,
     * after players slept or after an admin moved the date: "how many
     * growing days have ended since I last looked?". Store the epoch day
     * when you look, and next time pass the stored day and today:</p>
     * <pre>{@code
     * long today = calendar.date().epochDay();
     * long grown = calendar.rules().daysInSeasons(lastLooked, today, Set.of(Season.SPRING, Season.SUMMER));
     * lastLooked = today;
     * }</pre>
     * <p>Because the date changes at midnight, this counts one day for every
     * midnight that has passed, as long as the day that ended was in one of
     * the seasons. The answer takes the same tiny amount of work for a span
     * of two days or two thousand years.</p>
     *
     * @param fromEpochDay the first day of the span (counted)
     * @param toEpochDay   the day after the last day of the span (not counted)
     * @param seasons      the seasons that count
     * @return the number of counted days, 0 if the span is empty or backwards
     */
    public long daysInSeasons(long fromEpochDay, long toEpochDay, Set<Season> seasons) {
        if (toEpochDay <= fromEpochDay || seasons.isEmpty()) {
            return 0;
        }
        int mask = 0;
        for (Season season : seasons) {
            mask |= 1 << season.ordinal();
        }
        return countedDaysBefore(toEpochDay, mask) - countedDaysBefore(fromEpochDay, mask);
    }

    /** Like {@link #daysInSeasons(long, long, Set)} for a single season. */
    public long daysInSeason(long fromEpochDay, long toEpochDay, Season season) {
        if (toEpochDay <= fromEpochDay) {
            return 0;
        }
        int mask = 1 << season.ordinal();
        return countedDaysBefore(toEpochDay, mask) - countedDaysBefore(fromEpochDay, mask);
    }

    /**
     * How many days from epoch day 0 up to (not including) {@code epochDay}
     * fall into the seasons of the mask. For negative days the result is
     * negative. Only differences of two results are meaningful, and those
     * are correct for any pair of days.
     *
     * @param mask one bit per season, bit number = {@link Season#ordinal()}
     */
    private long countedDaysBefore(long epochDay, int mask) {
        long wholeYears = Math.floorDiv(epochDay, (long) yearDays);
        int daysIntoYear = (int) Math.floorMod(epochDay, (long) yearDays);
        long perYear = 0;
        long inPartialYear = 0;
        for (int i = 0; i < 4; i++) {
            if ((mask & (1 << i)) != 0) {
                perYear += seasonDays[i];
                // How many of this season's days lie before "daysIntoYear".
                inPartialYear += Math.max(0, Math.min(seasonDays[i], daysIntoYear - seasonStart[i]));
            }
        }
        return wholeYears * perYear + inPartialYear;
    }

    // ------------------------------------------------------------------
    // Smooth values over the year
    // ------------------------------------------------------------------

    /**
     * A smooth wave over the year: +1 in the middle of summer, -1 in the
     * middle of winter, 0 in the middle of spring and of autumn.
     *
     * <p>Meant for everything that swings between a summer and a winter
     * extreme: day length, temperature, how far north the sun stands.
     * Multiply it with your own strength and add it to your base value.
     * To make something lag behind the sun (the hottest days come after
     * midsummer), ask for an earlier moment:
     * {@code summerness(calendar.yearDay() - 3)}.</p>
     *
     * <p>With seasons of equal length this is an ordinary sine wave. With
     * unequal seasons the wave is stretched so that every season still
     * covers exactly a quarter of it: it peaks in the middle of summer and
     * of winter and crosses zero in the middle of spring and of autumn.</p>
     *
     * @param yearDay a moment in the year in days counted from 0, with
     *                fractions for the time of day (0.5 = noon of the first
     *                day). Values outside the year wrap around.
     * @return a value from -1 to +1
     * @see Calendar#summerness() for the value at the current moment
     */
    public double summerness(double yearDay) {
        return Math.sin(midSeasonPosition(yearDay) * (Math.PI / 2.0));
    }

    /**
     * Where a moment lies between the middles of two neighbouring seasons.
     *
     * <p>Meant for values that are defined once per season and should glide
     * from one to the next: leaf colors, fog, ambient sounds. Each season
     * shows its own value in pure form in its middle. From there the result
     * moves steadily toward the next season's value, and at the border of
     * two seasons it is always an even mix of both, even when the two
     * seasons have different lengths.</p>
     *
     * @param yearDay a moment in the year in days counted from 0, as in {@link #summerness}
     * @see Calendar#blend() for the blend at the current moment
     */
    public SeasonBlend blendAt(double yearDay) {
        double position = midSeasonPosition(yearDay);
        int whole = (int) position;
        Season from = Season.byIndex(whole);
        return new SeasonBlend(from, from.next(), position - whole);
    }

    /**
     * Places a moment of the year on a scale where the middle of spring is
     * 0, the middle of summer 1, the middle of autumn 2 and the middle of
     * winter 3. The result runs from 0 up to (not including) 4.
     *
     * <p>Every season covers exactly one unit of this scale, from half a
     * unit before its middle to half a unit after, whatever its length in
     * days. So the border between two seasons is always exactly half-way
     * between their two middles.</p>
     */
    private double midSeasonPosition(double yearDay) {
        double day = yearDay % yearDays;
        if (day < 0) {
            day += yearDays;
        }
        int season = seasonOnDayOfYear((int) day).ordinal();
        double throughSeason = (day - seasonStart[season]) / seasonDays[season];
        double position = season + throughSeason - 0.5;
        // The first half of spring comes before the middle of spring and
        // belongs to the stretch that started in the middle of winter.
        return position < 0 ? position + 4.0 : position;
    }

    // ------------------------------------------------------------------
    // Plumbing
    // ------------------------------------------------------------------

    /** Two sets of rules are equal when all season lengths and the moon setting match. */
    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof CalendarRules that)) {
            return false;
        }
        return seasonalMoon == that.seasonalMoon
                && seasonDays[0] == that.seasonDays[0] && seasonDays[1] == that.seasonDays[1]
                && seasonDays[2] == that.seasonDays[2] && seasonDays[3] == that.seasonDays[3];
    }

    @Override
    public int hashCode() {
        int hash = seasonalMoon ? 1 : 0;
        for (int days : seasonDays) {
            hash = hash * 1009 + days;
        }
        return hash;
    }

    @Override
    public String toString() {
        return "CalendarRules[spring=" + seasonDays[0] + ", summer=" + seasonDays[1] + ", autumn=" + seasonDays[2]
                + ", winter=" + seasonDays[3] + ", seasonalMoon=" + seasonalMoon + "]";
    }
}
