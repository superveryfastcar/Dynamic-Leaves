package io.github.superveryfastcar.calendar.api;

/**
 * A moment of the year described as a mix of two neighbouring seasons.
 *
 * <p>Each season is "pure" in its middle. Between two middles the mix moves
 * steadily from the earlier season to the later one. This gives mods a
 * simple way to let anything glide through the year without visible steps:
 * define one value per season and call {@link #mix}.</p>
 *
 * <pre>{@code
 * // Fog gets thicker toward winter, changing a little every tick.
 * double fog = Calendar.of(level).blend().mix(0.2, 0.0, 0.5, 1.0);
 *
 * // Two colors, mixed with the game's own helper.
 * SeasonBlend blend = Calendar.of(level).blend();
 * int color = FastColor.ARGB32.lerp((float) blend.progress(), colorOf(blend.from()), colorOf(blend.to()));
 * }</pre>
 *
 * @param from     the season whose middle was passed last
 * @param to       the season whose middle comes next
 * @param progress how far the moment is on the way from {@code from} to
 *                 {@code to}: 0 in the middle of {@code from}, 0.5 at the
 *                 border of the two seasons, just under 1 right before the
 *                 middle of {@code to}
 * @see Calendar#blend()
 * @see CalendarRules#blendAt(double)
 */
public record SeasonBlend(Season from, Season to, double progress) {

    /**
     * Mixes four per-season values according to this blend.
     *
     * @param spring the value in the middle of spring
     * @param summer the value in the middle of summer
     * @param autumn the value in the middle of autumn
     * @param winter the value in the middle of winter
     * @return the value for this moment
     */
    public double mix(double spring, double summer, double autumn, double winter) {
        double start = pick(from, spring, summer, autumn, winter);
        double end = pick(to, spring, summer, autumn, winter);
        return start + (end - start) * progress;
    }

    /**
     * How strongly a season is present in this blend, from 0 (not at all)
     * to 1 (pure). The weights of all four seasons always add up to 1.
     */
    public double weight(Season season) {
        if (season == from) {
            return 1.0 - progress;
        }
        return season == to ? progress : 0.0;
    }

    /** The season that currently has the larger share of the mix. */
    public Season dominant() {
        return progress < 0.5 ? from : to;
    }

    private static double pick(Season season, double spring, double summer, double autumn, double winter) {
        return switch (season) {
            case SPRING -> spring;
            case SUMMER -> summer;
            case AUTUMN -> autumn;
            case WINTER -> winter;
        };
    }
}
