package io.github.superveryfastcar.calendar.api;

import com.mojang.serialization.Codec;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.util.StringRepresentable;

/**
 * Which third of a season a day falls in: early, mid or late.
 *
 * <p>This is a convenience for rules like "only in late autumn". It is worked
 * out from the day and the season's length, so it adapts to any season
 * length. With the default 14-day seasons, days 1 to 5 are early, 6 to 10
 * are mid and 11 to 14 are late.</p>
 *
 * <p>For anything that should change gradually (colors, temperature, day
 * length), do not step through these three values. Use
 * {@link Calendar#blend()} or {@link Calendar#summerness()} instead, which
 * change smoothly every tick.</p>
 */
public enum SeasonPhase implements StringRepresentable {
    EARLY("early"),
    MID("mid"),
    LATE("late");

    /** Reads and writes a phase as its lower-case name ({@code "late"}), for data files. */
    public static final Codec<SeasonPhase> CODEC = StringRepresentable.fromEnum(SeasonPhase::values);

    private static final SeasonPhase[] VALUES = values();

    private final String serializedName;

    SeasonPhase(String serializedName) {
        this.serializedName = serializedName;
    }

    /** The lower-case name used in data files, for example {@code "late"}. */
    @Override
    public String getSerializedName() {
        return serializedName;
    }

    /**
     * The phase together with a season for showing to players, translated on
     * their client ("Late Autumn"). The language key is
     * {@code calendar.phase.<name>}, with the season's name as its argument.
     */
    public MutableComponent displayName(Season season) {
        return Component.translatable("calendar.phase." + serializedName, season.displayName());
    }

    /**
     * Works out the phase of a day.
     *
     * @param dayOfSeason  the day within the season, starting at 1
     * @param seasonLength how many days the season has
     */
    public static SeasonPhase of(int dayOfSeason, int seasonLength) {
        // Three equal parts by position. The long cast avoids overflow for
        // absurdly long seasons.
        int third = (int) ((dayOfSeason - 1) * 3L / seasonLength);
        return VALUES[Math.max(0, Math.min(2, third))];
    }
}
