package io.github.superveryfastcar.calendar.api;

import io.github.superveryfastcar.calendar.core.SunTimesHolder;

/**
 * Says when the sun rises and sets on each day.
 *
 * <p>Calendar itself does not move the sun. Out of the box the sun rises at
 * 06:00 and sets at 18:00 every day, as in the unmodded game. A mod that
 * makes days longer and shorter (in our family that is Daylight) registers
 * one of these, and from then on everything in Calendar that speaks of
 * sunrise and sunset uses its answers:</p>
 * <ul>
 *   <li>{@link Calendar#sunriseTick()}, {@link Calendar#sunsetTick()} and
 *       {@link Calendar#isSunUp()},</li>
 *   <li>the moments {@link DayMoment#DAWN} and {@link DayMoment#DUSK}, which
 *       are announced when the sun really rises and sets.</li>
 * </ul>
 * <p>So other mods never need to know which mod moves the sun, or whether
 * one does. They ask the calendar.</p>
 *
 * <h2>Rules for an implementation</h2>
 * <ul>
 *   <li>Times are on the calendar's clock: ticks since midnight, 1000 per
 *       hour. Sunrise must lie before noon (1 to 11999) and sunset after
 *       noon (12001 to 23999). Calendar forces answers into those ranges.</li>
 *   <li>The answer for a day must not depend on the time of day. Sun times
 *       are fixed per calendar day and change at midnight, when the sun is
 *       at its lowest and nobody can see a jump.</li>
 *   <li>The server and every client must give the same answer for the same
 *       day, or they disagree about when it is day. If the answer depends
 *       on a setting, the mod has to send that setting to its clients.</li>
 *   <li>The methods are called from the server thread and from the client's
 *       main thread, about once a day each, and now and then for other
 *       days. They must be safe to call from any thread.</li>
 *   <li>When the answers change (a setting was changed, the server's
 *       setting arrived on a client), call {@link #changed()}.</li>
 * </ul>
 */
public interface SunTimes {

    /**
     * When the sun rises on a day.
     *
     * @param rules      the calendar's rules (season lengths), to work out where in the year the day lies
     * @param epochDay   the day, see {@link CalendarDate#epochDay()}
     * @param clientSide true if a client's copy of the calendar asks, false
     *                   if the server's calendar asks. In a single-player
     *                   game both ask. A mod whose setting comes from the
     *                   server uses this to pick the right copy of it.
     * @return ticks since midnight, 1 to 11999
     */
    int sunriseTick(CalendarRules rules, long epochDay, boolean clientSide);

    /**
     * When the sun sets on a day.
     *
     * @param rules      the calendar's rules
     * @param epochDay   the day
     * @param clientSide true if a client's copy of the calendar asks
     * @return ticks since midnight, 12001 to 23999
     */
    int sunsetTick(CalendarRules rules, long epochDay, boolean clientSide);

    /** The unmodded game's sun: up at 06:00, down at 18:00, every day. Used while no mod has registered anything else. */
    SunTimes VANILLA = new SunTimes() {
        @Override
        public int sunriseTick(CalendarRules rules, long epochDay, boolean clientSide) {
            return CalendarRules.DEFAULT_SUNRISE_TICK;
        }

        @Override
        public int sunsetTick(CalendarRules rules, long epochDay, boolean clientSide) {
            return CalendarRules.DEFAULT_SUNSET_TICK;
        }
    };

    /**
     * Makes Calendar use the given sun times from now on. Call it once
     * while your mod starts, on the server and on the client alike.
     *
     * <p>There is only one sun, so there is only one of these at a time. A
     * second call replaces the first (and is noted in the log, because two
     * mods moving the sun is probably a mistake in the modpack).</p>
     */
    static void register(SunTimes sunTimes) {
        SunTimesHolder.register(sunTimes);
    }

    /**
     * Tells Calendar that the registered sun times now give different
     * answers. Every calendar asks again within one tick. Safe to call from
     * any thread, and cheap.
     */
    static void changed() {
        SunTimesHolder.changed();
    }
}
