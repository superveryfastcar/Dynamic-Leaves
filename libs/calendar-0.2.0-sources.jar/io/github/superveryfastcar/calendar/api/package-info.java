/**
 * The public API of Calendar. Everything another mod needs is in this
 * package and in {@link io.github.superveryfastcar.calendar.api.event}.
 *
 * <p>Start at {@link io.github.superveryfastcar.calendar.api.Calendar}:
 * {@code Calendar.of(level)} gives you the world's calendar on either side.
 * The README in the repository has worked examples for the common jobs.</p>
 *
 * <p>The other packages of this mod are its inner workings. They may change
 * between versions without notice, so please do not call them from another
 * mod.</p>
 */
package io.github.superveryfastcar.calendar.api;
