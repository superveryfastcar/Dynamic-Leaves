package io.github.superveryfastcar.calendar.api;

import com.mojang.serialization.Codec;
import net.minecraft.util.StringRepresentable;

/**
 * Four moments of every day. Calendar announces each one with a
 * {@link io.github.superveryfastcar.calendar.api.event.CalendarEvent.MomentReached}
 * event when the clock passes it.
 *
 * <p>A calendar day runs from midnight to midnight, like a 24-hour clock.
 * {@link #MIDNIGHT} is therefore the first moment of a day, the very moment
 * the date changes, and {@link #DUSK} the last.</p>
 *
 * <p>Midnight and noon are fixed points of the clock. Dawn and dusk are the
 * real sunrise and sunset. Without a mod that moves the sun these are 06:00
 * and 18:00. With one (see {@link SunTimes}) they move through the year.
 * {@link Calendar#tickOf(DayMoment)} says where each moment lies today.</p>
 */
public enum DayMoment implements StringRepresentable {
    /** 00:00, the start of a calendar day. The date changes at this moment. */
    MIDNIGHT("midnight"),
    /** The sun rises: {@link Calendar#sunriseTick()}. 06:00 unless a mod moves the sun. */
    DAWN("dawn"),
    /** 12:00, the sun is at its highest. */
    NOON("noon"),
    /** The sun sets: {@link Calendar#sunsetTick()}. 18:00 unless a mod moves the sun. */
    DUSK("dusk");

    /** Reads and writes a moment as its lower-case name ({@code "midnight"}), for data files. */
    public static final Codec<DayMoment> CODEC = StringRepresentable.fromEnum(DayMoment::values);

    private final String serializedName;

    DayMoment(String serializedName) {
        this.serializedName = serializedName;
    }

    /** The lower-case name used in data files, for example {@code "midnight"}. */
    @Override
    public String getSerializedName() {
        return serializedName;
    }
}
