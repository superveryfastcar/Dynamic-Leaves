package io.github.superveryfastcar.calendar.api;

import com.mojang.serialization.Codec;
import java.util.Locale;
import javax.annotation.Nullable;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.util.StringRepresentable;

/**
 * The four seasons, in the order they follow each other. A calendar year
 * begins with {@link #SPRING} and ends with {@link #WINTER}.
 *
 * <p>How many days each season lasts is not fixed here. It is part of the
 * world's {@link CalendarRules}, and each season can have its own length.</p>
 */
public enum Season implements StringRepresentable {
    SPRING("spring"),
    SUMMER("summer"),
    AUTUMN("autumn"),
    WINTER("winter");

    /**
     * Reads and writes a season as its lower-case name ({@code "autumn"}).
     * For use in data files: loot conditions, recipes, configs of other mods.
     */
    public static final Codec<Season> CODEC = StringRepresentable.fromEnum(Season::values);

    /** Cached copy of {@link #values()}, which would otherwise allocate a new array on every call. */
    private static final Season[] VALUES = values();

    private final String serializedName;

    Season(String serializedName) {
        this.serializedName = serializedName;
    }

    /** The lower-case name used in data files and commands, for example {@code "autumn"}. */
    @Override
    public String getSerializedName() {
        return serializedName;
    }

    /** The season after this one. Winter is followed by spring. */
    public Season next() {
        return VALUES[(ordinal() + 1) & 3];
    }

    /** The season before this one. Spring is preceded by winter. */
    public Season previous() {
        return VALUES[(ordinal() + 3) & 3];
    }

    /** The season half a year away: summer for winter, spring for autumn and the other way round. */
    public Season opposite() {
        return VALUES[(ordinal() + 2) & 3];
    }

    /**
     * The season's name for showing to players, translated on their client
     * ("Autumn"). The language key is {@code calendar.season.<name>}.
     */
    public MutableComponent displayName() {
        return Component.translatable("calendar.season." + serializedName);
    }

    /**
     * The season at a position in the year's order: 0 is spring, 3 is winter.
     * Positions outside 0..3 wrap around, so 4 is spring again and -1 is winter.
     */
    public static Season byIndex(int index) {
        return VALUES[index & 3];
    }

    /**
     * Finds a season by its lower-case name ({@code "autumn"}). Upper and
     * lower case are treated the same.
     *
     * @return the season, or null if there is no season with that name
     */
    @Nullable
    public static Season byName(String name) {
        String wanted = name.toLowerCase(Locale.ROOT);
        for (Season season : VALUES) {
            if (season.serializedName.equals(wanted)) {
                return season;
            }
        }
        return null;
    }
}
