package io.github.superveryfastcar.calendar.api;

import com.mojang.serialization.Codec;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.util.StringRepresentable;

/**
 * The eight phases of the moon, in the order the game shows them: starting
 * at the full moon, shrinking to the new moon and growing back.
 *
 * <p>The order matches the game's own numbering (0 = full moon, 4 = new
 * moon), so {@link #ordinal()} is the number vanilla code and resource packs
 * use for the phase.</p>
 *
 * <p>Calendar ties the moon to the date. See {@link CalendarRules#moonPhaseOn}
 * for the rule.</p>
 */
public enum MoonPhase implements StringRepresentable {
    FULL_MOON("full_moon", 1.0F),
    WANING_GIBBOUS("waning_gibbous", 0.75F),
    LAST_QUARTER("last_quarter", 0.5F),
    WANING_CRESCENT("waning_crescent", 0.25F),
    NEW_MOON("new_moon", 0.0F),
    WAXING_CRESCENT("waxing_crescent", 0.25F),
    FIRST_QUARTER("first_quarter", 0.5F),
    WAXING_GIBBOUS("waxing_gibbous", 0.75F);

    /** Reads and writes a phase as its lower-case name ({@code "full_moon"}), for data files. */
    public static final Codec<MoonPhase> CODEC = StringRepresentable.fromEnum(MoonPhase::values);

    private static final MoonPhase[] VALUES = values();

    private final String serializedName;
    private final float brightness;

    MoonPhase(String serializedName, float brightness) {
        this.serializedName = serializedName;
        this.brightness = brightness;
    }

    /** The lower-case name used in data files, for example {@code "full_moon"}. */
    @Override
    public String getSerializedName() {
        return serializedName;
    }

    /**
     * How much of the moon is lit, from 0 (new moon) to 1 (full moon). These
     * are the same numbers the game uses for slime spawning and for how
     * strong mobs get.
     */
    public float brightness() {
        return brightness;
    }

    /** True while the moon is growing: the three phases after the new moon. */
    public boolean isWaxing() {
        return ordinal() > 4;
    }

    /** True while the moon is shrinking: the three phases after the full moon. */
    public boolean isWaning() {
        return ordinal() > 0 && ordinal() < 4;
    }

    /**
     * The phase's name for showing to players, translated on their client
     * ("Full Moon"). The language key is {@code calendar.moon.<name>}.
     */
    public MutableComponent displayName() {
        return Component.translatable("calendar.moon." + serializedName);
    }

    /**
     * The phase for one of the game's phase numbers (0 = full moon,
     * 4 = new moon). Numbers outside 0..7 wrap around.
     */
    public static MoonPhase byIndex(int index) {
        return VALUES[index & 7];
    }
}
