package io.github.superveryfastcar.calendar.api;

/**
 * The server's calendar: everything {@link Calendar} offers, plus the means
 * to change the date. Get it with {@code Calendar.of(server)}.
 *
 * <p>Changing the date does not touch the time of day, the sun or the
 * weather. It only changes which day it is. All players are told at once,
 * and the usual events are sent
 * ({@link io.github.superveryfastcar.calendar.api.event.CalendarEvent.DayChanged}
 * and, if it applies,
 * {@link io.github.superveryfastcar.calendar.api.event.CalendarEvent.SeasonChanged}),
 * so every mod follows along as it would at a normal midnight.</p>
 *
 * <p>These methods must be called on the server thread, like most things
 * that change the world.</p>
 */
public interface ServerCalendar extends Calendar {

    /**
     * Sets the date.
     *
     * @param year        the year; the first year is 1
     * @param season      the season
     * @param dayOfSeason the day within the season, starting at 1
     * @throws IllegalArgumentException if the season does not have that day
     * @throws IllegalStateException    if called from another thread than the server's
     */
    void setDate(int year, Season season, int dayOfSeason);

    /**
     * Sets the date by its epoch day. See {@link CalendarDate#epochDay()}.
     *
     * @throws IllegalStateException if called from another thread than the server's
     */
    void setEpochDay(long epochDay);

    /**
     * Moves the date forward by a number of days, or back if the number is negative.
     *
     * @throws IllegalStateException if called from another thread than the server's
     */
    void addDays(long days);
}
