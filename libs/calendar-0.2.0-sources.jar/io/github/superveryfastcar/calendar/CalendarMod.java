package io.github.superveryfastcar.calendar;

import com.mojang.logging.LogUtils;
import io.github.superveryfastcar.calendar.core.ServerEvents;
import io.github.superveryfastcar.calendar.loot.CalendarLoot;
import io.github.superveryfastcar.calendar.network.CalendarNetwork;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.ModContainer;
import net.neoforged.fml.common.Mod;
import net.neoforged.fml.config.ModConfig;
import net.neoforged.fml.event.lifecycle.FMLCommonSetupEvent;
import net.neoforged.neoforge.common.NeoForge;
import org.slf4j.Logger;

/**
 * Entry point of the Calendar mod.
 *
 * <h2>What the mod does</h2>
 * Calendar gives the world a date: a season, a day of the season, a year and
 * a moon phase. That is all it does. It changes nothing in the world except
 * the moon, which it ties to the date. It is a library: other mods (Daylight
 * for the length of the day, Seasons for what the seasons do to the world,
 * and anything that should depend on the time of year) read the date from
 * it and listen for its events, instead of each keeping a calendar of its own.
 *
 * <h2>How it does it</h2>
 * The date is the game's own day counter plus one saved number, an offset.
 * So the calendar follows the game's clock by itself, however fast it runs
 * and however it is moved forward, and only the offset has to be saved and
 * sent to players. See
 * {@link io.github.superveryfastcar.calendar.core.CalendarClock}.
 *
 * <h2>Where things live</h2>
 * <ul>
 *   <li>{@code api} package: everything other mods use. Start at
 *       {@link io.github.superveryfastcar.calendar.api.Calendar}.</li>
 *   <li>{@code core} package: the clock, the saved state, the server's
 *       calendar and a client's copy of it.</li>
 *   <li>{@code network} package: the one small message the server sends to
 *       clients.</li>
 *   <li>{@code client} package: reads the client's clock for the copy.</li>
 *   <li>{@code command} package: the {@code /calendar} command.</li>
 *   <li>{@code loot} package: the date as a condition for data packs.</li>
 *   <li>{@code mixin} package: the one small patch to vanilla code (the moon).</li>
 * </ul>
 *
 * <p>Serene Seasons by Glitchfiend was studied as a reference for what a
 * seasons calendar has to handle. No code was copied from it. The review is
 * in {@code docs/serene-seasons-review.md}.</p>
 */
@Mod(CalendarMod.MOD_ID)
public final class CalendarMod {

    /** The mod id. Must match gradle.properties and neoforge.mods.toml. */
    public static final String MOD_ID = "calendar";

    /** Shared logger. Messages show up in the game log prefixed with the mod name. */
    public static final Logger LOGGER = LogUtils.getLogger();

    /**
     * Called once by NeoForge when the game starts, on both the client and a
     * dedicated server.
     *
     * @param modBus    the event bus for this mod's start-up events
     *                  (registering network messages and so on)
     * @param container this mod's container, used to register the config file
     */
    public CalendarMod(IEventBus modBus, ModContainer container) {
        // The rules of the calendar. Read by whoever hosts the world.
        container.registerConfig(ModConfig.Type.COMMON, CalendarConfig.SPEC);

        // Things that are registered on the mod bus during start-up: the
        // network message and the data-pack condition.
        modBus.addListener(CalendarNetwork::register);
        CalendarLoot.CONDITION_TYPES.register(modBus);

        // The game rule. The game's list of rules is not built for several
        // mods adding to it at the same moment, and mods start up side by
        // side. "enqueueWork" runs this on the main thread, one mod after
        // the other.
        modBus.addListener((FMLCommonSetupEvent event) -> event.enqueueWork(CalendarGameRules::register));

        // Gameplay events (world loaded, server ticks, players joining,
        // commands) arrive on NeoForge's main game bus. The client's side is
        // registered by its own annotation, see the client package.
        NeoForge.EVENT_BUS.register(ServerEvents.class);
    }
}
