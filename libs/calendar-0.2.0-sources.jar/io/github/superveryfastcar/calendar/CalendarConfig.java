package io.github.superveryfastcar.calendar;

import io.github.superveryfastcar.calendar.api.CalendarRules;
import io.github.superveryfastcar.calendar.api.Season;
import net.neoforged.neoforge.common.ModConfigSpec;

/**
 * The settings of Calendar, stored in {@code config/calendar-common.toml}.
 *
 * <p>They are read by whoever hosts the world (the single player, the LAN
 * host or the dedicated server) each time a world is opened. Players who
 * join get the host's values sent to them, so their own file does not
 * matter while they are on someone else's world.</p>
 *
 * <p>Every value has a comment that ends up in the config file itself, so
 * the file is self-explanatory.</p>
 */
public final class CalendarConfig {

    /** The finished description of the config file, handed to NeoForge in {@link CalendarMod}. */
    public static final ModConfigSpec SPEC;

    /** Days of spring. */
    public static final ModConfigSpec.IntValue SPRING_DAYS;

    /** Days of summer. */
    public static final ModConfigSpec.IntValue SUMMER_DAYS;

    /** Days of autumn. */
    public static final ModConfigSpec.IntValue AUTUMN_DAYS;

    /** Days of winter. */
    public static final ModConfigSpec.IntValue WINTER_DAYS;

    /** The season a world's calendar starts in. */
    public static final ModConfigSpec.EnumValue<Season> START_SEASON;

    /** The day of that season a world's calendar starts on. */
    public static final ModConfigSpec.IntValue START_DAY;

    /** Whether the moon follows the seasons. */
    public static final ModConfigSpec.BooleanValue MOON_FOLLOWS_SEASONS;

    static {
        ModConfigSpec.Builder b = new ModConfigSpec.Builder();

        b.comment("Calendar: gives the world a date (season, day, year) and ties the moon to it.",
                  "These settings are read when a world is opened. Changing them needs the world to be reopened.")
         .push("seasons");

        String lengthNote = "If you change this for an existing world, the date is kept: the same year, season and day of the season.";
        SPRING_DAYS = b.comment("How many days spring lasts.", lengthNote)
                .defineInRange("springDays", 14, CalendarRules.MIN_SEASON_DAYS, CalendarRules.MAX_SEASON_DAYS);
        SUMMER_DAYS = b.comment("How many days summer lasts.", lengthNote)
                .defineInRange("summerDays", 14, CalendarRules.MIN_SEASON_DAYS, CalendarRules.MAX_SEASON_DAYS);
        AUTUMN_DAYS = b.comment("How many days autumn lasts.", lengthNote)
                .defineInRange("autumnDays", 14, CalendarRules.MIN_SEASON_DAYS, CalendarRules.MAX_SEASON_DAYS);
        WINTER_DAYS = b.comment("How many days winter lasts.", lengthNote)
                .defineInRange("winterDays", 14, CalendarRules.MIN_SEASON_DAYS, CalendarRules.MAX_SEASON_DAYS);
        b.pop();

        b.comment("The date a world's calendar begins on. Only used once per world:",
                  "when a new world is created, or when an existing world is opened with Calendar for the first time.",
                  "The year always starts at 1. A calendar year runs from spring to winter.",
                  "A calendar day runs from midnight to midnight. A new world starts at 06:00.")
         .push("start");
        START_SEASON = b.comment("The season the calendar starts in.")
                .defineEnum("startSeason", Season.AUTUMN);
        START_DAY = b.comment("The day of that season the calendar starts on.",
                        "If the season is shorter than this, its last day is used.")
                .defineInRange("startDay", 1, 1, CalendarRules.MAX_SEASON_DAYS);
        b.pop();

        b.push("moon");
        MOON_FOLLOWS_SEASONS = b.comment(
                        "true: every season is one trip of the moon. The first day of a season has a new moon",
                        "(the darkest night) and the day in the middle has the season's only full moon.",
                        "The moon changes at noon, out of sight, so a night has one moon from beginning to end.",
                        "false: the moon changes phase every day in the game's usual eight-day cycle.",
                        "Either way the moon belongs to the date: /calendar set changes the moon with it.")
                .define("moonFollowsSeasons", true);
        b.pop();

        SPEC = b.build();
    }

    private CalendarConfig() {
    }

    /**
     * The rules described by the config file. Before the file has been
     * loaded (very early during game start) this gives the defaults.
     */
    public static CalendarRules rules() {
        if (!SPEC.isLoaded()) {
            return CalendarRules.DEFAULT;
        }
        return new CalendarRules(SPRING_DAYS.get(), SUMMER_DAYS.get(), AUTUMN_DAYS.get(), WINTER_DAYS.get(),
                MOON_FOLLOWS_SEASONS.get());
    }

    /**
     * The epoch day a new calendar starts on under the given rules: the
     * configured season and day in year 1.
     */
    public static long startEpochDay(CalendarRules rules) {
        Season season = SPEC.isLoaded() ? START_SEASON.get() : Season.AUTUMN;
        int day = SPEC.isLoaded() ? START_DAY.get() : 1;
        return rules.epochDayOf(1, season, Math.min(day, rules.seasonLength(season)));
    }
}
