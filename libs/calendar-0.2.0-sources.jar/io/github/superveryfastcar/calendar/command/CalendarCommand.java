package io.github.superveryfastcar.calendar.command;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.mojang.brigadier.exceptions.SimpleCommandExceptionType;
import io.github.superveryfastcar.calendar.api.Calendar;
import io.github.superveryfastcar.calendar.api.CalendarDate;
import io.github.superveryfastcar.calendar.api.MoonPhase;
import io.github.superveryfastcar.calendar.api.Season;
import io.github.superveryfastcar.calendar.api.ServerCalendar;
import java.util.Locale;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;

/**
 * The {@code /calendar} command.
 *
 * <ul>
 *   <li>{@code /calendar}: tells the time, the date, the moon and when the
 *       next season begins. Usable by every player.</li>
 *   <li>{@code /calendar set <season> [day] [year]}: sets the date. Without
 *       a day it is the season's first day, without a year the current
 *       year. Needs operator rights (cheats).</li>
 *   <li>{@code /calendar add <days>}: moves the date forward, or back with a
 *       negative number. Needs operator rights (cheats).</li>
 * </ul>
 *
 * <p>Setting the date changes only the date. The time of day, the sun and
 * the weather stay as they are.</p>
 *
 * <p>The seasons are ordinary command words ({@code spring}, {@code summer},
 * {@code autumn}, {@code winter}) and not a custom kind of argument. A
 * custom argument kind would have to be known to every client, and a player
 * without Calendar could then not join. Plain words work for everyone.</p>
 *
 * <p>The replies are plain English and not taken from the language file,
 * so they also read correctly for a player who joined without Calendar.</p>
 */
public final class CalendarCommand {

    /** The largest year (and, negated, the smallest) the command accepts. */
    private static final int MAX_YEAR = 1_000_000;

    /** The largest number of days {@code /calendar add} accepts in one go, forward or back. */
    private static final int MAX_ADD_DAYS = 100_000_000;

    private CalendarCommand() {
    }

    /** Adds {@code /calendar} to the game's command list. */
    public static void register(CommandDispatcher<CommandSourceStack> dispatcher) {
        LiteralArgumentBuilder<CommandSourceStack> set = Commands.literal("set")
                .requires(source -> source.hasPermission(2));
        for (Season season : Season.values()) {
            set.then(Commands.literal(season.getSerializedName())
                    .executes(context -> setDate(context, season, 1, null))
                    .then(Commands.argument("day", IntegerArgumentType.integer(1))
                            .executes(context -> setDate(context, season,
                                    IntegerArgumentType.getInteger(context, "day"), null))
                            .then(Commands.argument("year", IntegerArgumentType.integer(-MAX_YEAR, MAX_YEAR))
                                    .executes(context -> setDate(context, season,
                                            IntegerArgumentType.getInteger(context, "day"),
                                            IntegerArgumentType.getInteger(context, "year"))))));
        }

        dispatcher.register(Commands.literal("calendar")
                .executes(CalendarCommand::show)
                .then(set)
                .then(Commands.literal("add")
                        .requires(source -> source.hasPermission(2))
                        .then(Commands.argument("days", IntegerArgumentType.integer(-MAX_ADD_DAYS, MAX_ADD_DAYS))
                                .executes(CalendarCommand::addDays))));
    }

    /** {@code /calendar}: reports the date. */
    private static int show(CommandContext<CommandSourceStack> context) {
        CommandSourceStack source = context.getSource();
        Calendar calendar = Calendar.of(source.getServer());
        String paused = calendar.isPaused() ? " The date is paused (game rule doCalendarCycle)." : "";
        source.sendSuccess(() -> Component.literal(describe(calendar) + paused), false);
        return 1;
    }

    /** {@code /calendar set ...}: sets the date. */
    private static int setDate(CommandContext<CommandSourceStack> context, Season season, int day, Integer yearOrNull)
            throws CommandSyntaxException {
        CommandSourceStack source = context.getSource();
        ServerCalendar calendar = Calendar.of(source.getServer());
        int length = calendar.rules().seasonLength(season);
        if (day > length) {
            throw failure(capitalized(season.getSerializedName()) + " has only " + length + " days.");
        }
        int year = yearOrNull != null ? yearOrNull : calendar.date().year();
        calendar.setDate(year, season, day);
        source.sendSuccess(() -> Component.literal("Set the date. " + describe(calendar)), true);
        return 1;
    }

    /** {@code /calendar add <days>}: moves the date. */
    private static int addDays(CommandContext<CommandSourceStack> context) throws CommandSyntaxException {
        CommandSourceStack source = context.getSource();
        ServerCalendar calendar = Calendar.of(source.getServer());
        int days = IntegerArgumentType.getInteger(context, "days");
        try {
            calendar.addDays(days);
        } catch (IllegalArgumentException | ArithmeticException e) {
            throw failure("That date is too far from the start of the calendar.");
        }
        source.sendSuccess(() -> Component.literal("Moved the date by " + days + (Math.abs(days) == 1 ? " day. " : " days. ")
                + describe(calendar)), true);
        return 1;
    }

    /**
     * The calendar's state in a few English sentences, for example: "It is
     * 14:30 on Autumn 3, Year 1 (day 31 of 56). Moon tonight: waxing
     * crescent. Winter begins in 12 days. This is day 3 of this world."
     */
    private static String describe(Calendar calendar) {
        CalendarDate date = calendar.date();
        int toNext = date.daysUntilNextSeason();
        boolean night = !calendar.isSunUp();
        return "It is " + String.format(Locale.ROOT, "%02d:%02d", calendar.hour(), calendar.minute()) + " on " + date
                + " (day " + date.dayOfYear() + " of " + date.yearLength() + "). "
                // At night: the moon that is in the sky. By day: the moon of the coming night.
                + (night ? "Moon: " + moonName(calendar.moonPhase()) : "Moon tonight: " + moonName(date.moonPhase())) + ". "
                + capitalized(date.season().next().getSerializedName()) + " begins "
                + (toNext == 1 ? "tomorrow." : "in " + toNext + " days.")
                + " This is day " + calendar.dayNumber() + " of this world.";
    }

    /** A moon phase in lower-case English words, for example "waxing crescent". */
    private static String moonName(MoonPhase phase) {
        return phase.getSerializedName().replace('_', ' ');
    }

    /**
     * A command failure with a message. Thrown instead of merely printing
     * the message, so that the game counts the command as failed (which
     * matters to command blocks and {@code /execute store success}).
     */
    private static CommandSyntaxException failure(String message) {
        return new SimpleCommandExceptionType(Component.literal(message)).create();
    }

    private static String capitalized(String word) {
        return word.substring(0, 1).toUpperCase(Locale.ROOT) + word.substring(1);
    }
}
