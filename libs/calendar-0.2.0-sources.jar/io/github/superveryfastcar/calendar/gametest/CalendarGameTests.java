package io.github.superveryfastcar.calendar.gametest;

import com.google.gson.JsonParser;
import com.mojang.authlib.GameProfile;
import com.mojang.serialization.JsonOps;
import io.github.superveryfastcar.calendar.CalendarGameRules;
import io.github.superveryfastcar.calendar.CalendarMod;
import io.github.superveryfastcar.calendar.api.Calendar;
import io.github.superveryfastcar.calendar.api.CalendarDate;
import io.github.superveryfastcar.calendar.api.CalendarRules;
import io.github.superveryfastcar.calendar.api.DayMoment;
import io.github.superveryfastcar.calendar.api.MoonPhase;
import io.github.superveryfastcar.calendar.api.Season;
import io.github.superveryfastcar.calendar.api.SeasonBlend;
import io.github.superveryfastcar.calendar.api.SeasonPhase;
import io.github.superveryfastcar.calendar.api.ServerCalendar;
import io.github.superveryfastcar.calendar.api.SunTimes;
import io.github.superveryfastcar.calendar.api.event.CalendarEvent;
import io.github.superveryfastcar.calendar.core.CalendarAccess;
import io.github.superveryfastcar.calendar.core.CalendarClock;
import io.github.superveryfastcar.calendar.core.CalendarSavedData;
import io.github.superveryfastcar.calendar.core.ClientCalendarImpl;
import io.github.superveryfastcar.calendar.core.ServerCalendarImpl;
import io.github.superveryfastcar.calendar.loot.CalendarLoot;
import io.github.superveryfastcar.calendar.loot.DateCondition;
import io.github.superveryfastcar.calendar.network.CalendarSyncPayload;
import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;
import io.netty.channel.embedded.EmbeddedChannel;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.EnumSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicReference;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.gametest.framework.GameTest;
import net.minecraft.gametest.framework.GameTestAssertException;
import net.minecraft.gametest.framework.GameTestHelper;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.Connection;
import net.minecraft.network.protocol.PacketFlow;
import net.minecraft.network.protocol.common.ClientboundCustomPayloadPacket;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.network.CommonListenerCookie;
import net.minecraft.world.level.GameRules;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.dimension.DimensionType;
import net.minecraft.world.level.storage.loot.LootContext;
import net.minecraft.world.level.storage.loot.LootParams;
import net.minecraft.world.level.storage.loot.parameters.LootContextParamSets;
import net.neoforged.neoforge.common.NeoForge;
import net.neoforged.neoforge.gametest.GameTestHolder;
import net.neoforged.neoforge.gametest.PrefixGameTestTemplate;
import net.neoforged.neoforge.network.registration.NetworkRegistry;

/**
 * Automatic tests for Calendar. They run inside a real (headless) Minecraft
 * server with {@code ./gradlew runGameTestServer}, which exits with an error
 * if any test fails.
 *
 * <h2>What is tested</h2>
 * <ol>
 *   <li><b>The arithmetic</b> ({@code datesMoonsAndCounters},
 *       {@code clockRules}): dates, the moon rule, day counting and the
 *       smooth curves, for equal and unequal seasons, checked against
 *       slow-but-obviously-right calculations.</li>
 *   <li><b>The running calendar</b> (the tests in the middle): the real
 *       server calendar following the real world clock, through midnights,
 *       sleeping, {@code /time set}, {@code /calendar set}, the pause rule,
 *       saving, the moon the game sees, sunrise and sunset moved by another
 *       mod, and the data-pack condition. Each
 *       test compares the exact list of events that were sent, in order.</li>
 *   <li><b>The client's copy</b> ({@code clientCopy...}): the real code a
 *       game client runs, fed with the real messages the server sent to a
 *       stand-in player, under deliberately bad conditions (late clock,
 *       messages in either order, a changed dimension).</li>
 * </ol>
 *
 * <h2>How the running tests control time</h2>
 * Most of them switch the daylight cycle off and move the world's clock by
 * hand, which is exactly what sleeping and {@code /time} do. That makes
 * every step exact. One test ({@code midnightByItself}) lets the clock run
 * on its own across a midnight to prove that ordinary ticking works too.
 *
 * <h2>Clock times</h2>
 * The tests write times as the calendar's clock counts them, with days
 * that begin at midnight: {@code BASE + 19_000} is 19:00 on the clock's
 * day 100. The game itself counts from 06:00, six hours later.
 * {@link #gameTime} converts where a time is handed to the game.
 *
 * <h2>Why every test has its own batch</h2>
 * Tests in the same batch run at the same time in the same world. These
 * tests change the time and the date of the whole world, so they must run
 * one after another. Giving each its own batch does that.
 *
 * <p>These classes are left out of the released jar (see {@code build.gradle}).</p>
 */
@GameTestHolder(CalendarMod.MOD_ID)
@PrefixGameTestTemplate(false)
public final class CalendarGameTests {

    private static final long DAY = CalendarRules.TICKS_PER_DAY;

    /**
     * Midnight at the start of the clock's day 100, as a clock time. Far
     * away from the world's first day, so that from here {@code /time set}
     * is a big step back, as it is in a real world.
     */
    private static final long BASE = 100 * DAY;

    /** Unequal seasons for the arithmetic tests: 10, 20, 5 and 7 days, a 42-day year. */
    private static final CalendarRules UNEQUAL = new CalendarRules(10, 20, 5, 7, true);

    /** Every event the server's calendar sent since the list was last cleared, as text. */
    private static final List<String> SERVER_EVENTS = new ArrayList<>();

    /** The same for the client's copy. */
    private static final List<String> CLIENT_EVENTS = new ArrayList<>();

    static {
        NeoForge.EVENT_BUS.addListener(CalendarEvent.Loaded.class, CalendarGameTests::onLoaded);
        NeoForge.EVENT_BUS.addListener(CalendarEvent.DayChanged.class, CalendarGameTests::onDayChanged);
        NeoForge.EVENT_BUS.addListener(CalendarEvent.SeasonChanged.class, CalendarGameTests::onSeasonChanged);
        NeoForge.EVENT_BUS.addListener(CalendarEvent.MomentReached.class, CalendarGameTests::onMoment);
    }

    private CalendarGameTests() {
    }

    // ------------------------------------------------------------------
    // Recording events
    // ------------------------------------------------------------------

    private static void record(CalendarEvent event, String text) {
        (event.isClientSide() ? CLIENT_EVENTS : SERVER_EVENTS).add(text);
    }

    private static void onLoaded(CalendarEvent.Loaded event) {
        record(event, "loaded " + event.getCalendar().date());
    }

    private static void onDayChanged(CalendarEvent.DayChanged event) {
        // Inside a listener the calendar must already show the new date.
        String stale = event.getCalendar().date().equals(event.getCurrent()) ? "" : " STALE CALENDAR";
        record(event, "day " + event.getPrevious() + " -> " + event.getCurrent() + " (" + event.daysPassed() + ")" + stale);
    }

    private static void onSeasonChanged(CalendarEvent.SeasonChanged event) {
        record(event, "season " + event.getPreviousSeason().getSerializedName() + " -> " + event.getSeason().getSerializedName());
    }

    private static void onMoment(CalendarEvent.MomentReached event) {
        record(event, event.getMoment().getSerializedName() + " of " + event.getDate());
    }

    // ------------------------------------------------------------------
    // Small helpers
    // ------------------------------------------------------------------

    /** Turns a clock time (days begin at midnight) into the game's day time (days begin at 06:00). */
    private static long gameTime(long clockTime) {
        return clockTime - CalendarClock.GAME_TIME_SHIFT;
    }

    /** Fails the test with a message unless the condition holds. */
    private static void check(boolean condition, String message) {
        if (!condition) {
            throw new GameTestAssertException(message);
        }
    }

    /** Fails the test unless two values are equal. */
    private static void checkEquals(Object expected, Object actual, String what) {
        if (!expected.equals(actual)) {
            throw new GameTestAssertException(what + ": expected <" + expected + "> but got <" + actual + ">");
        }
    }

    /** Fails the test unless two numbers are equal within a tiny tolerance. */
    private static void checkClose(double expected, double actual, String what) {
        if (Math.abs(expected - actual) > 1.0e-9) {
            throw new GameTestAssertException(what + ": expected " + expected + " but got " + actual);
        }
    }

    /** Fails the test unless the recorded events are exactly the expected ones, in order. Clears the list. */
    private static void expectEvents(List<String> recorded, String... expected) {
        List<String> actual = List.copyOf(recorded);
        recorded.clear();
        checkEquals(List.of(expected), actual, "events");
    }

    /**
     * Sets up the world for one running test and puts it back afterwards.
     */
    private static final class Scene {
        final GameTestHelper helper;
        final ServerLevel level;
        final MinecraftServer server;
        final ServerCalendar calendar;
        final List<ServerPlayer> players = new ArrayList<>();

        /**
         * @param clockTime     the clock time to start from (see {@link #gameTime})
         * @param daylightCycle whether the world's clock runs by itself
         */
        Scene(GameTestHelper helper, long clockTime, boolean daylightCycle, int year, Season season, int day) {
            this.helper = helper;
            this.level = helper.getLevel();
            this.server = level.getServer();
            this.calendar = Calendar.of(server);
            level.getGameRules().getRule(GameRules.RULE_DAYLIGHT).set(daylightCycle, server);
            level.getGameRules().getRule(CalendarGameRules.doCalendarCycle()).set(true, server);
            level.setDayTime(gameTime(clockTime));
            syncCalendarNow();
            calendar.setDate(year, season, day);
            SERVER_EVENTS.clear();
        }

        /** Lets the calendar look at the world's clock right now instead of at the end of the tick. */
        void syncCalendarNow() {
            ServerCalendarImpl impl = CalendarAccess.serverOrNull();
            check(impl != null, "the server's calendar is not running");
            impl.tick();
        }

        /** Moves the world's clock, like sleeping or /time does, and lets the calendar notice. */
        void setClock(long clockTime) {
            level.setDayTime(gameTime(clockTime));
            syncCalendarNow();
        }

        /**
         * Runs a command as the server console.
         *
         * @return true if the game counts the command as successful. A
         *         command that could not be read, or that failed, gives false.
         */
        boolean command(String command) {
            boolean[] succeeded = {false};
            server.getCommands().performPrefixedCommand(
                    server.createCommandSourceStack().withSuppressedOutput()
                            .withCallback((success, value) -> succeeded[0] = success),
                    command);
            return succeeded[0];
        }

        void expectDate(String expected) {
            checkEquals(expected, calendar.date().toString(), "date");
        }

        /**
         * Creates a stand-in player. To the server this is a real, connected
         * player with a modded client, added through the same method a
         * joining player goes through. Its network connection leads into a
         * queue the test can read (see {@link #sentTo}).
         */
        ServerPlayer addPlayer() {
            GameProfile profile = new GameProfile(UUID.randomUUID(), "calendar-test-" + (players.size() + 1));
            CommonListenerCookie cookie = CommonListenerCookie.createInitial(profile, false);
            ServerPlayer player = new ServerPlayer(server, level, cookie.gameProfile(), cookie.clientInformation());
            Connection connection = new Connection(PacketFlow.SERVERBOUND);
            new EmbeddedChannel(connection);
            NetworkRegistry.configureMockConnection(connection);
            server.getPlayerList().placeNewPlayer(connection, player, cookie);
            players.add(player);
            return player;
        }

        /** Takes all calendar messages the server has sent to a stand-in player since the last call. */
        List<CalendarSyncPayload> sentTo(ServerPlayer player) {
            EmbeddedChannel channel = (EmbeddedChannel) player.connection.getConnection().channel();
            channel.flushOutbound();
            List<CalendarSyncPayload> found = new ArrayList<>();
            Object message;
            while ((message = channel.readOutbound()) != null) {
                if (message instanceof ClientboundCustomPayloadPacket packet
                        && packet.payload() instanceof CalendarSyncPayload payload) {
                    found.add(payload);
                }
            }
            return found;
        }

        /** Removes the stand-in players and restores the rules. */
        void cleanUp() {
            for (ServerPlayer player : players) {
                server.getPlayerList().remove(player);
            }
            players.clear();
            level.getGameRules().getRule(GameRules.RULE_DAYLIGHT).set(true, server);
            level.getGameRules().getRule(CalendarGameRules.doCalendarCycle()).set(true, server);
            ClientCalendarImpl.INSTANCE.reset();
            SERVER_EVENTS.clear();
            CLIENT_EVENTS.clear();
        }
    }

    // ==================================================================
    // Part 1: the arithmetic
    // ==================================================================

    /**
     * Dates, the moon, day counting and the smooth curves, for the default
     * 14-day seasons and for unequal seasons. Everything is compared with a
     * slow calculation that simply walks through the days one by one.
     */
    @GameTest(template = "empty", batch = "calendar_math")
    public static void datesMoonsAndCounters(GameTestHelper helper) {
        CalendarRules rules = CalendarRules.DEFAULT;

        // --- Epoch day 0 is Spring 1, Year 1, and the default year has 56 days.
        checkEquals("Spring 1, Year 1", rules.dateOf(0).toString(), "epoch day 0");
        checkEquals(56, rules.yearLength(), "default year length");
        checkEquals("Autumn 1, Year 1", rules.dateOf(28).toString(), "epoch day 28");
        checkEquals("Winter 14, Year 1", rules.dateOf(55).toString(), "epoch day 55");
        checkEquals("Spring 1, Year 2", rules.dateOf(56).toString(), "epoch day 56");
        checkEquals("Winter 14, Year 0", rules.dateOf(-1).toString(), "epoch day -1");
        checkEquals(28L, rules.epochDayOf(1, Season.AUTUMN, 1), "epoch day of Autumn 1, Year 1");

        // --- Walk through 6 years of each rule set, day by day.
        for (CalendarRules r : List.of(rules, UNEQUAL, new CalendarRules(1, 1, 1, 1, true), new CalendarRules(3, 2, 30, 8, false))) {
            int year = -1;
            Season season = Season.SPRING;
            int dayOfSeason = 1;
            int dayOfYear = 1;
            for (long epochDay = -2L * r.yearLength(); epochDay < 4L * r.yearLength(); epochDay++) {
                CalendarDate date = r.dateOf(epochDay);
                String at = r + " day " + epochDay;
                checkEquals(year, date.year(), at + " year");
                checkEquals(season, date.season(), at + " season");
                checkEquals(dayOfSeason, date.dayOfSeason(), at + " day of season");
                checkEquals(dayOfYear, date.dayOfYear(), at + " day of year");
                checkEquals(epochDay, r.epochDayOf(date.year(), date.season(), date.dayOfSeason()), at + " round trip");
                checkEquals(season, r.seasonOn(epochDay), at + " seasonOn");
                checkEquals(r.seasonLength(season) - dayOfSeason, date.daysLeftInSeason(), at + " days left");
                check(date.daysUntilStartOf(season.next()) == date.daysUntilNextSeason(), at + " days until next season");
                checkEquals(r.yearLength(), r.dateOf(r.epochDayOf(date.year(), season, 1)).daysUntilStartOf(season),
                        at + " a season's own start is a year away on its first day");
                // advance the slow calendar by one day
                dayOfYear++;
                if (++dayOfSeason > r.seasonLength(season)) {
                    dayOfSeason = 1;
                    season = season.next();
                    if (season == Season.SPRING) {
                        year++;
                        dayOfYear = 1;
                    }
                }
            }
        }

        // --- Dates compare and add as numbers do.
        CalendarDate autumn3 = rules.dateOf(rules.epochDayOf(1, Season.AUTUMN, 3));
        checkEquals("Winter 1, Year 1", autumn3.plusDays(12).toString(), "Autumn 3 + 12 days");
        checkEquals(12L, autumn3.daysUntil(autumn3.plusDays(12)), "days until");
        check(autumn3.isBefore(autumn3.plusDays(1)) && autumn3.isAfter(autumn3.plusDays(-1)), "before and after");
        check(autumn3.equals(rules.dateOf(30)) && !autumn3.equals(UNEQUAL.dateOf(30)), "equality needs the same rules");
        checkEquals(autumn3.seasonNumber() + 4, autumn3.plusDays(56).seasonNumber(), "a year later is 4 seasons later");

        // --- Thirds of a 14-day season: 5 early, 5 mid, 4 late days.
        checkEquals(SeasonPhase.EARLY, SeasonPhase.of(5, 14), "day 5 of 14");
        checkEquals(SeasonPhase.MID, SeasonPhase.of(6, 14), "day 6 of 14");
        checkEquals(SeasonPhase.MID, SeasonPhase.of(10, 14), "day 10 of 14");
        checkEquals(SeasonPhase.LATE, SeasonPhase.of(11, 14), "day 11 of 14");
        checkEquals(SeasonPhase.EARLY, SeasonPhase.of(1, 1), "day 1 of 1");

        // --- The moon in a 14-day season: new, 2x crescent, 2x quarter,
        //     2x gibbous, full on day 8, then the same shrinking.
        String expectedMoons = "4 5 5 6 6 7 7 0 1 1 2 2 3 3";
        for (Season s : Season.values()) {
            StringBuilder moons = new StringBuilder();
            for (int day = 1; day <= 14; day++) {
                moons.append(day == 1 ? "" : " ").append(rules.moonPhaseOn(rules.epochDayOf(3, s, day)).ordinal());
            }
            checkEquals(expectedMoons, moons.toString(), "moon phases of a 14-day " + s.getSerializedName());
        }
        // --- Any season length: new moon on day 1 only, one full moon in
        //     the middle (none in a 1-day season), growing before it and
        //     shrinking after it.
        for (int length = 1; length <= 40; length++) {
            CalendarRules r = new CalendarRules(length, 3, 3, 3, true);
            int fullMoons = 0;
            boolean afterFull = false;
            int previousBrightnessStep = -1;
            for (int day = 1; day <= length; day++) {
                MoonPhase moon = r.moonPhaseOn(day - 1);
                String at = "season of " + length + " days, day " + day;
                checkEquals(day == 1, moon == MoonPhase.NEW_MOON, at + " new moon only on day 1");
                if (moon == MoonPhase.FULL_MOON) {
                    fullMoons++;
                    afterFull = true;
                    checkEquals(length / 2 + 1, day, at + " full moon day");
                } else if (day > 1) {
                    check(afterFull ? moon.isWaning() : moon.isWaxing(), at + " grows before and shrinks after the full moon, got " + moon);
                    int step = Math.round(moon.brightness() * 4);
                    check(previousBrightnessStep < 0 || (afterFull ? step <= previousBrightnessStep : step >= previousBrightnessStep),
                            at + " brightness must not go the wrong way");
                    previousBrightnessStep = step;
                }
                if (moon == MoonPhase.FULL_MOON || day == 1) {
                    previousBrightnessStep = -1;
                }
            }
            checkEquals(length >= 2 ? 1 : 0, fullMoons, "full moons in a season of " + length + " days");
        }
        // --- The eight-day moon: one phase per day in the game's order.
        CalendarRules plainMoon = new CalendarRules(14, 14, 14, 14, false);
        for (long day = -20; day < 40; day++) {
            checkEquals((int) Math.floorMod(day, 8L), plainMoon.moonPhaseOn(day).ordinal(), "eight-day moon on day " + day);
        }

        // --- Counting days in seasons, against counting them one by one.
        for (CalendarRules r : List.of(rules, UNEQUAL)) {
            for (Set<Season> seasons : List.of(EnumSet.of(Season.SPRING), EnumSet.of(Season.SUMMER, Season.AUTUMN),
                    EnumSet.of(Season.WINTER, Season.SPRING), EnumSet.allOf(Season.class), EnumSet.noneOf(Season.class))) {
                for (long from = -130; from <= 130; from += 13) {
                    long slow = 0;
                    for (long to = from; to <= from + 150; to++) {
                        checkEquals(slow, r.daysInSeasons(from, to, seasons), r + " days in " + seasons + " from " + from + " to " + to);
                        if (seasons.contains(r.seasonOn(to))) {
                            slow++;
                        }
                    }
                    checkEquals(0L, r.daysInSeasons(from, from - 5, seasons), "a backwards span counts nothing");
                }
            }
            checkEquals(r.daysInSeasons(-40, 300, EnumSet.of(Season.WINTER)), r.daysInSeason(-40, 300, Season.WINTER), "single-season shortcut");
        }
        // A span of two thousand years is as easy as two days.
        checkEquals(2000L * 28, rules.daysInSeasons(0, 2000L * 56, EnumSet.of(Season.SPRING, Season.SUMMER)), "2000 years of growing days");

        // --- The yearly wave: +1 mid-summer, -1 mid-winter, 0 mid-spring
        //     and mid-autumn, also with unequal seasons, and no jumps.
        for (CalendarRules r : List.of(rules, UNEQUAL)) {
            checkClose(0.0, r.summerness(middle(r, Season.SPRING)), r + " mid-spring");
            checkClose(1.0, r.summerness(middle(r, Season.SUMMER)), r + " mid-summer");
            checkClose(0.0, r.summerness(middle(r, Season.AUTUMN)), r + " mid-autumn");
            checkClose(-1.0, r.summerness(middle(r, Season.WINTER)), r + " mid-winter");
            checkClose(r.summerness(3.25), r.summerness(3.25 + r.yearLength()), r + " wraps after a year");
            checkClose(r.summerness(3.25), r.summerness(3.25 - 2 * r.yearLength()), r + " wraps backwards");
            double previous = r.summerness(-0.01);
            for (double day = 0; day <= r.yearLength() + 0.01; day += 0.01) {
                double value = r.summerness(day);
                check(value >= -1.0 && value <= 1.0, r + " summerness out of range at " + day);
                check(Math.abs(value - previous) < 0.02, r + " summerness jumps at " + day);
                previous = value;
            }
            // The blend: pure in the middle, an even mix at every border.
            for (Season s : Season.values()) {
                SeasonBlend pure = r.blendAt(middle(r, s));
                checkEquals(s, pure.from(), r + " blend in the middle of " + s);
                checkClose(0.0, pure.progress(), r + " blend progress in the middle of " + s);
                SeasonBlend border = r.blendAt(r.firstDayOfYear(s.next()) - 1 + (s == Season.WINTER ? r.yearLength() : 0));
                checkEquals(s, border.from(), r + " blend at the end of " + s);
                checkEquals(s.next(), border.to(), r + " blend at the end of " + s);
                checkClose(0.5, border.progress(), r + " blend progress at the end of " + s);
                checkClose(0.5, border.weight(s), r + " weight at the border");
                checkClose(0.0, border.weight(s.opposite()), r + " weight of the far season");
            }
            checkClose(2.0, r.blendAt(middle(r, Season.SUMMER)).mix(1, 2, 3, 4), r + " mix in mid-summer");
            checkClose(2.5, r.blendAt(r.firstDayOfYear(Season.AUTUMN) - 1).mix(1, 2, 3, 4), r + " mix at the summer/autumn border");
            checkClose(2.5, r.blendAt(0).mix(1, 2, 3, 4), r + " mix at the winter/spring border");
        }

        // --- Names used in data files.
        checkEquals(Season.AUTUMN, Season.byName("Autumn"), "season by name");
        check(Season.byName("monsoon") == null, "unknown season name");
        checkEquals(Season.WINTER, Season.SPRING.previous(), "previous of spring");
        checkEquals(Season.SPRING, Season.WINTER.next(), "next of winter");
        // The calendar's clock starts at midnight, the game's at 06:00.
        checkEquals(0, CalendarRules.clockTickOf(18_000), "the game's 18000 is midnight");
        checkEquals(6000, CalendarRules.clockTickOf(0), "the game's 0 is 06:00");
        checkEquals(12_000, CalendarRules.clockTickOf(6000 + 77 * DAY), "the game's 6000 is noon, on any day");
        checkEquals(23_999, CalendarRules.clockTickOf(-6001), "also before the world's first day");
        for (MoonPhase moon : MoonPhase.values()) {
            checkClose(DimensionType.MOON_BRIGHTNESS_PER_PHASE[moon.ordinal()], moon.brightness(), "brightness of " + moon);
        }

        // --- Impossible rules are refused.
        try {
            new CalendarRules(14, 0, 14, 14, true);
            throw new GameTestAssertException("a season of 0 days was accepted");
        } catch (IllegalArgumentException expected) {
            // good
        }
        try {
            rules.epochDayOf(1, Season.SUMMER, 15);
            throw new GameTestAssertException("day 15 of a 14-day season was accepted");
        } catch (IllegalArgumentException expected) {
            // good
        }
        helper.succeed();
    }

    /** The middle of a season as a moment of the year in days counted from 0. */
    private static double middle(CalendarRules rules, Season season) {
        return rules.firstDayOfYear(season) - 1 + rules.seasonLength(season) / 2.0;
    }

    /**
     * The clock's rules on their own, with plain numbers: time passing,
     * jumps forward, the time being set back in every way, pausing. The
     * numbers are clock times, whose days begin at midnight.
     */
    @GameTest(template = "empty", batch = "calendar_clock")
    public static void clockRules(GameTestHelper helper) {
        // Start on epoch day 500 at noon (12:00) of the clock's day 100.
        CalendarClock clock = new CalendarClock(BASE + 12_000, 500 - 100);
        checkEquals(500L, clock.epochDay(), "start day");
        checkEquals(12_000, clock.tickOfDay(), "start time of day");
        checkEquals(BASE + 12_000, CalendarClock.toClockTime(BASE + 6000), "the game's noon (6000) is 12:00 on the clock");

        // Ordinary ticks move forward by exactly what passed.
        checkEquals(1L, clock.observe(BASE + 12_001, false), "one tick");
        checkEquals(500L, clock.epochDay(), "still the same day");

        // Across midnight: the next day.
        checkEquals(11_999L, clock.observe(BASE + DAY, false), "to midnight");
        checkEquals(501L, clock.epochDay(), "the day after midnight");
        checkEquals(0, clock.tickOfDay(), "time of day at midnight");

        // A jump forward over ten days (/time add) is followed completely.
        clock.observe(BASE + 11 * DAY + 100, false);
        checkEquals(511L, clock.epochDay(), "ten days later");

        // The time is set back to a LATER time of day (19:00, shortly after
        // midnight): same day, and the clock moved forward to 19:00.
        checkEquals(18_900L, clock.observe(19_000, false), "set to later the same day");
        checkEquals(511L, clock.epochDay(), "setting a later time of day keeps the date");
        checkEquals(19_000, clock.tickOfDay(), "time of day after the set");

        // The time is set back to an EARLIER time of day (07:00 in the
        // evening): that is tomorrow morning.
        clock.observe(5 * DAY + 19_000, false); // let five days pass first: day 516
        checkEquals(516L, clock.epochDay(), "five days on");
        checkEquals(12_000L, clock.observe(7000, false), "set to earlier is the next day");
        checkEquals(517L, clock.epochDay(), "setting an earlier time of day lands on the next day");

        // A small step back within the same day (another mod nudging the
        // clock) is followed as it is and does not touch the date.
        checkEquals(0L, clock.observe(6990, false), "a small step back does not count as moving forward");
        checkEquals(517L, clock.epochDay(), "a small step back within the day keeps the date");
        checkEquals(6990, clock.tickOfDay(), "and the time of day follows");

        // A small step back ACROSS midnight must not bring yesterday back.
        // It counts as a set-back like any other: forward to the next
        // 23:59, which is tonight.
        clock.observe(DAY + 3, false);
        checkEquals(518L, clock.epochDay(), "after midnight");
        checkEquals(DAY - 6, clock.observe(DAY - 3, false), "a step back across midnight counts as going forward to tonight");
        checkEquals(518L, clock.epochDay(), "the date did not go back across midnight");
        checkEquals((int) DAY - 3, clock.tickOfDay(), "time of day after the step back");
        clock.observe(DAY + 3, false);
        checkEquals(519L, clock.epochDay(), "the following midnight counts again");

        // Every kind of set-back, from many starting points: the date
        // stays or moves on by one day. It never goes back.
        long[] starts = {0, 1, 5, 600, 1199, 1200, 1201, 6000, 12_000, 18_000, 23_999};
        long[] steps = {1, 2, 5, 599, 600, 1199, 1200, 1201, 5000, 12_000, 23_999, 24_000, 24_001, 100_000, 5 * DAY};
        for (long startTick : starts) {
            for (long step : steps) {
                for (boolean paused : new boolean[] {false, true}) {
                    long from = 5 * DAY + startTick;
                    long to = from - step;
                    CalendarClock setBack = new CalendarClock(from, 1000);
                    long before = setBack.epochDay();
                    setBack.observe(to, paused);
                    long moved = setBack.epochDay() - before;
                    String what = "set back from " + from + " to " + to + (paused ? " while paused" : "");
                    check(moved == 0 || (moved == 1 && !paused), what + " moved the date by " + moved + " days");
                    checkEquals((int) Math.floorMod(to, DAY), setBack.tickOfDay(), what + ": time of day");
                }
            }
        }

        // Paused: days roll by, the epoch day stays.
        clock.observe(2 * DAY + 10, true);
        checkEquals(519L, clock.epochDay(), "paused across one midnight");
        clock.observe(10 * DAY + 10, true);
        checkEquals(519L, clock.epochDay(), "paused across a jump of eight days");
        clock.observe(500, true); // time set back while paused
        checkEquals(519L, clock.epochDay(), "paused across a set-back");
        clock.observe(DAY + 500, false);
        checkEquals(520L, clock.epochDay(), "running again after the pause");

        // Setting the date changes only the date.
        clock.setEpochDay(7);
        checkEquals(7L, clock.epochDay(), "date after setEpochDay");
        checkEquals(500, clock.tickOfDay(), "time of day untouched by setEpochDay");
        helper.succeed();
    }

    // ==================================================================
    // Part 2: the running calendar
    // ==================================================================

    /**
     * The clock runs by itself across a midnight that is also the end of a
     * season. Expected: the day change, then the season change, then the
     * midnight moment, in that order and exactly once. The moon must not
     * change at midnight with the date, and not at sunrise either: it
     * changes at noon, out of sight, in the calendar and in the game's own
     * sky.
     */
    @GameTest(template = "empty", batch = "calendar_midnight", timeoutTicks = 200)
    public static void midnightByItself(GameTestHelper helper) {
        Scene scene = new Scene(helper, BASE + DAY - 20, true, 1, Season.AUTUMN, 14);
        ServerLevel level = scene.level;
        checkEquals(23, scene.calendar.hour(), "hour shortly before midnight");
        checkEquals(MoonPhase.WANING_CRESCENT, scene.calendar.moonPhase(), "moon in the last night of autumn");
        checkEquals(3, level.getMoonPhase(), "the game's own moon phase in the last night of autumn");

        helper.startSequence()
                .thenWaitUntil(() -> check(level.getDayTime() >= gameTime(BASE + DAY + 5), "waiting for midnight"))
                .thenExecute(() -> {
                    expectEvents(SERVER_EVENTS,
                            "day Autumn 14, Year 1 -> Winter 1, Year 1 (1)",
                            "season autumn -> winter",
                            "midnight of Winter 1, Year 1");
                    scene.expectDate("Winter 1, Year 1");
                    checkEquals(Season.WINTER, scene.calendar.season(), "season");
                    checkEquals(0, scene.calendar.hour(), "hour shortly after midnight");
                    // The date is new, the night and its moon are not.
                    checkEquals(MoonPhase.NEW_MOON, scene.calendar.date().moonPhase(), "the moon that belongs to the first day of winter");
                    checkEquals(MoonPhase.WANING_CRESCENT, scene.calendar.moonPhase(), "the moon in the sky after midnight");
                    checkEquals(3, level.getMoonPhase(), "the game's own moon phase after midnight");

                    // Sunrise: the moon is still setting, and still the old one.
                    scene.setClock(BASE + DAY + 6005);
                    expectEvents(SERVER_EVENTS, "dawn of Winter 1, Year 1");
                    checkEquals(MoonPhase.WANING_CRESCENT, scene.calendar.moonPhase(), "the moon after sunrise");
                    checkEquals(3, level.getMoonPhase(), "the game's own moon phase after sunrise");
                    scene.setClock(BASE + DAY + 11_999);
                    checkEquals(3, level.getMoonPhase(), "the game's own moon phase a tick before noon");

                    // Noon: now the new day's moon takes over, while nobody can see it.
                    scene.setClock(BASE + DAY + 12_000);
                    expectEvents(SERVER_EVENTS, "noon of Winter 1, Year 1");
                    checkEquals(MoonPhase.NEW_MOON, scene.calendar.moonPhase(), "the moon from noon on");
                    // The patch: the game's own moon is the calendar's moon.
                    checkEquals(4, level.getMoonPhase(), "the game's own moon phase from noon on");
                    checkClose(0.0, level.getMoonBrightness(), "the game's own moon brightness");
                    // The game may ask for the moon of another moment.
                    checkEquals(MoonPhase.FULL_MOON.ordinal(), level.dimensionType().moonPhase(level.getDayTime() + 7 * DAY),
                            "the game's moon phase seven days ahead");
                    // Every dimension shows the same calendar.
                    ServerLevel nether = scene.server.getLevel(Level.NETHER);
                    check(nether == null || Calendar.of(nether) == scene.calendar, "the Nether has the same calendar");
                    check(Calendar.of(level) == scene.calendar, "Calendar.of(level) and Calendar.of(server) agree");
                    check(scene.calendar.isSynced() && !scene.calendar.isClientSide() && !scene.calendar.isPaused(), "state flags");
                })
                .thenExecute(scene::cleanUp)
                .thenSucceed();
    }

    /**
     * Sleeping, the vanilla way: the clock jumps from the evening to the
     * next sunrise. Then a jump within a day, a jump over many days, and
     * the end of a year. The events must tell the story in the order of
     * time.
     */
    @GameTest(template = "empty", batch = "calendar_jumps")
    public static void sleepingAndJumps(GameTestHelper helper) {
        Scene scene = new Scene(helper, BASE + 18_500, false, 1, Season.AUTUMN, 3);
        ServerCalendar calendar = scene.calendar;
        long epochTickBefore = calendar.epochTick();
        long dayBefore = calendar.date().epochDay();
        checkEquals(18, calendar.hour(), "hour at 18:30");
        checkEquals(30, calendar.minute(), "minute at 18:30");

        // Sleep: 18:30 -> 06:00. Midnight was skipped but still happened.
        scene.setClock(BASE + DAY + 6000);
        expectEvents(SERVER_EVENTS,
                "day Autumn 3, Year 1 -> Autumn 4, Year 1 (1)",
                "midnight of Autumn 4, Year 1",
                "dawn of Autumn 4, Year 1");
        checkEquals(epochTickBefore + 11_500, calendar.epochTick(), "epoch tick after sleeping");
        checkEquals(6, calendar.hour(), "hour at sunrise");
        checkEquals(0, calendar.minute(), "minute at sunrise");

        // A jump within the day: 06:00 -> 13:00 passes noon only.
        scene.setClock(BASE + DAY + 13_000);
        expectEvents(SERVER_EVENTS, "noon of Autumn 4, Year 1");
        checkClose((3 + 13_000.0 / 24_000) / 14, calendar.seasonProgress(), "season progress");
        checkClose(28 + 3 + 13_000.0 / 24_000, calendar.yearDay(), "year day");
        checkClose(calendar.yearDay() / 56, calendar.yearProgress(), "year progress");
        checkClose(13_000.0 / 24_000, calendar.dayProgress(), "day progress");
        checkClose(calendar.rules().summerness(calendar.yearDay()), calendar.summerness(), "summerness now");
        checkEquals(Season.AUTUMN, calendar.blend().dominant(), "dominant season of the blend");

        // 13:00 -> 19:00 passes dusk.
        scene.setClock(BASE + DAY + 19_000);
        expectEvents(SERVER_EVENTS, "dusk of Autumn 4, Year 1");

        // /time add 10d: one day change that says 10, no replay of the
        // skipped days, and only the moments of the day we land in.
        scene.setClock(BASE + 11 * DAY + 19_000);
        expectEvents(SERVER_EVENTS,
                "day Autumn 4, Year 1 -> Autumn 14, Year 1 (10)",
                "midnight of Autumn 14, Year 1",
                "dawn of Autumn 14, Year 1",
                "noon of Autumn 14, Year 1",
                "dusk of Autumn 14, Year 1");
        // What a crop does to catch up: count the autumn days that ended
        // since it last looked (on Autumn 3). Eleven midnights passed.
        checkEquals(11L, calendar.rules().daysInSeasons(dayBefore, calendar.date().epochDay(), EnumSet.of(Season.AUTUMN)),
                "autumn days that ended since Autumn 3");
        checkEquals(0L, calendar.rules().daysInSeasons(dayBefore, calendar.date().epochDay(), EnumSet.of(Season.SPRING)),
                "spring days that ended since Autumn 3");

        // The end of the year.
        calendar.setDate(1, Season.WINTER, 14);
        SERVER_EVENTS.clear();
        scene.setClock(BASE + 12 * DAY + 10);
        expectEvents(SERVER_EVENTS,
                "day Winter 14, Year 1 -> Spring 1, Year 2 (1)",
                "season winter -> spring",
                "midnight of Spring 1, Year 2");
        checkEquals(1, calendar.date().dayOfYear(), "day of year on new year's day");

        // A jump of exactly one year: the same season again, but a new one.
        scene.setClock(BASE + 12 * DAY + 10 + 56 * DAY);
        expectEvents(SERVER_EVENTS,
                "day Spring 1, Year 2 -> Spring 1, Year 3 (56)",
                "season spring -> spring",
                "midnight of Spring 1, Year 3");
        scene.cleanUp();
        helper.succeed();
    }

    /**
     * The real {@code /time set} command, which resets the game's own day
     * counter to the world's first day. The calendar must never follow
     * that backwards: a later time of day is the same date, an earlier one
     * is the next day, also for tiny set-backs and across midnight.
     */
    @GameTest(template = "empty", batch = "calendar_timeset")
    public static void timeSetNeverMovesTheDateBack(GameTestHelper helper) {
        Scene scene = new Scene(helper, BASE + 13_000, false, 2, Season.SUMMER, 8);
        ServerCalendar calendar = scene.calendar;
        ServerLevel level = scene.level;
        checkEquals(MoonPhase.FULL_MOON, calendar.moonPhase(), "the coming night's moon on the middle day of a season");
        long epochTick = calendar.epochTick();

        // 13:00 -> "/time set 13000" (the game's 13000 is 19:00): later the same day.
        check(scene.command("time set 13000"), "/time set 13000 failed");
        checkEquals(13_000L, level.getDayTime(), "the game's day time was reset to its first day");
        scene.syncCalendarNow();
        expectEvents(SERVER_EVENTS, "dusk of Summer 8, Year 2");
        scene.expectDate("Summer 8, Year 2");
        checkEquals(19, calendar.hour(), "hour after /time set 13000");
        checkEquals(epochTick + 6000, calendar.epochTick(), "the calendar's own time went forward by six hours");
        checkEquals(0, level.getMoonPhase(), "the game's moon is still the full moon after the reset");

        // 19:00 -> "/time set day" (07:00): the next morning.
        check(scene.command("time set day"), "/time set day failed");
        scene.syncCalendarNow();
        expectEvents(SERVER_EVENTS,
                "day Summer 8, Year 2 -> Summer 9, Year 2 (1)",
                "midnight of Summer 9, Year 2",
                "dawn of Summer 9, Year 2");
        checkEquals(epochTick + 6000 + 12_000, calendar.epochTick(), "the calendar's own time went forward to the morning");
        checkEquals(0, level.getMoonPhase(), "in the morning the sky still has last night's full moon");
        checkEquals(MoonPhase.WANING_GIBBOUS, calendar.date().moonPhase(), "the moon of the coming night");

        // "/time set 1000" again at exactly the same time of day: nothing changes.
        check(scene.command("time set 1000"), "/time set 1000 failed");
        scene.syncCalendarNow();
        expectEvents(SERVER_EVENTS);
        scene.expectDate("Summer 9, Year 2");

        // 07:00 -> "/time set midnight": the coming midnight, so the next date.
        check(scene.command("time set midnight"), "/time set midnight failed");
        scene.syncCalendarNow();
        expectEvents(SERVER_EVENTS,
                "noon of Summer 9, Year 2",
                "dusk of Summer 9, Year 2",
                "day Summer 9, Year 2 -> Summer 10, Year 2 (1)",
                "midnight of Summer 10, Year 2");
        checkEquals(0, calendar.tickOfDay(), "the calendar's clock at midnight");

        // A tiny set-back across midnight (00:00 -> 23:59:24). The date
        // must stay, not go back to Summer 9.
        check(scene.command("time set 17990"), "/time set 17990 failed");
        scene.syncCalendarNow();
        scene.expectDate("Summer 10, Year 2");
        expectEvents(SERVER_EVENTS, "dawn of Summer 10, Year 2", "noon of Summer 10, Year 2", "dusk of Summer 10, Year 2");
        // Forward across that midnight: the next date.
        check(scene.command("time set 18005"), "/time set 18005 failed");
        scene.syncCalendarNow();
        expectEvents(SERVER_EVENTS, "day Summer 10, Year 2 -> Summer 11, Year 2 (1)", "midnight of Summer 11, Year 2");
        // A tiny set-back within the day (00:00:18 -> 00:00:00): same date, nothing announced.
        check(scene.command("time set 18000"), "/time set 18000 failed");
        scene.syncCalendarNow();
        expectEvents(SERVER_EVENTS);
        scene.expectDate("Summer 11, Year 2");
        checkEquals(0, calendar.tickOfDay(), "the calendar's clock follows a tiny set-back");

        // "/time add" goes forward and is simply followed.
        check(scene.command("time add 2d"), "/time add 2d failed");
        scene.syncCalendarNow();
        expectEvents(SERVER_EVENTS,
                "day Summer 11, Year 2 -> Summer 13, Year 2 (2)",
                "midnight of Summer 13, Year 2");

        // Now the promise itself, through the real command, from young and
        // old worlds, for every kind of value: after "/time set", the date
        // is the same or the next day. Never an earlier one.
        long[] worldTimes = {0, 1, 500, 1000, 5990, 6000, 12_000, 17_990, 18_000, 18_010, 23_999, 24_000, 24_600, 30_000,
                47_999, BASE + 17_995, BASE + 18_000, BASE + 18_600, 3 * BASE + 123};
        int[] values = {0, 1, 1000, 6000, 12_999, 13_000, 17_000, 17_990, 17_999, 18_000, 18_001, 18_010, 23_999, 24_000, 100_000};
        int tried = 0;
        for (long worldTime : worldTimes) {
            List<Integer> toTry = new ArrayList<>();
            for (int value : values) {
                toTry.add(value);
            }
            // Also values just below the current time: the smallest set-backs.
            for (long back : new long[] {1, 5, 600, 1200, 1201}) {
                if (worldTime - back >= 0 && worldTime - back <= Integer.MAX_VALUE) {
                    toTry.add((int) (worldTime - back));
                }
            }
            for (int value : toTry) {
                level.setDayTime(worldTime);
                scene.syncCalendarNow();
                long before = calendar.date().epochDay();
                check(scene.command("time set " + value), "/time set " + value + " failed");
                scene.syncCalendarNow();
                long moved = calendar.date().epochDay() - before;
                long expectedForward = value >= worldTime ? Math.floorDiv(value + 6000L, DAY) - Math.floorDiv(worldTime + 6000, DAY) : -1;
                String what = "/time set " + value + " at game time " + worldTime;
                if (value >= worldTime) {
                    checkEquals(expectedForward, moved, what + ": days moved by a forward set");
                } else {
                    check(moved == 0 || moved == 1, what + " moved the date by " + moved + " days");
                }
                checkEquals((int) ((value + 6000L) % DAY), calendar.tickOfDay(), what + ": the calendar's clock");
                tried++;
            }
        }
        CalendarMod.LOGGER.info("[Calendar test] /time set never moved the date back in {} combinations.", tried);
        scene.cleanUp();
        helper.succeed();
    }

    /**
     * The {@code /calendar} command: showing, setting and moving the date.
     * Setting the date must not touch the world's clock and must not
     * announce any moments, because the clock did not move.
     */
    @GameTest(template = "empty", batch = "calendar_command")
    public static void calendarCommand(GameTestHelper helper) {
        Scene scene = new Scene(helper, BASE + 15_000, false, 1, Season.AUTUMN, 1);
        ServerLevel level = scene.level;

        check(scene.command("calendar"), "/calendar failed");
        expectEvents(SERVER_EVENTS);

        check(scene.command("calendar set winter 3 5"), "/calendar set winter 3 5 failed");
        scene.expectDate("Winter 3, Year 5");
        expectEvents(SERVER_EVENTS, "day Autumn 1, Year 1 -> Winter 3, Year 5 (240)", "season autumn -> winter");

        check(scene.command("calendar add -2"), "/calendar add -2 failed");
        scene.expectDate("Winter 1, Year 5");
        expectEvents(SERVER_EVENTS, "day Winter 3, Year 5 -> Winter 1, Year 5 (-2)");

        check(scene.command("calendar add 14"), "/calendar add 14 failed");
        scene.expectDate("Spring 1, Year 6");
        expectEvents(SERVER_EVENTS, "day Winter 1, Year 5 -> Spring 1, Year 6 (14)", "season winter -> spring");

        // Season only: its first day, in the current year.
        check(scene.command("calendar set summer"), "/calendar set summer failed");
        scene.expectDate("Summer 1, Year 6");
        // Season and day: the current year.
        check(scene.command("calendar set spring 14"), "/calendar set spring 14 failed");
        scene.expectDate("Spring 14, Year 6");
        SERVER_EVENTS.clear();

        // A day the season does not have is refused and changes nothing.
        check(!scene.command("calendar set summer 15"), "/calendar set summer 15 should fail");
        check(!scene.command("calendar set monsoon"), "/calendar set monsoon should fail");
        scene.expectDate("Spring 14, Year 6");
        expectEvents(SERVER_EVENTS);

        // Setting the same date again does nothing.
        check(scene.command("calendar set spring 14 6"), "/calendar set spring 14 6 failed");
        expectEvents(SERVER_EVENTS);

        checkEquals(gameTime(BASE + 15_000), level.getDayTime(), "the world's clock was not touched");
        checkEquals(15_000, scene.calendar.tickOfDay(), "the calendar's time of day was not touched");

        // The API refuses to be used from another thread.
        AtomicReference<Throwable> thrown = new AtomicReference<>();
        Thread other = new Thread(() -> {
            try {
                scene.calendar.addDays(1);
            } catch (Throwable t) {
                thrown.set(t);
            }
        });
        other.start();
        try {
            other.join();
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
        check(thrown.get() instanceof IllegalStateException, "changing the date from another thread must be refused");
        scene.expectDate("Spring 14, Year 6");
        scene.cleanUp();
        helper.succeed();
    }

    /**
     * A stand-in for a mod that moves the sun: on even epoch days the sun
     * is up from 04:00 to 20:00, on odd days from 08:00 to 16:00. Far more
     * extreme than any real setting, so that every mix-up between two days
     * would show.
     */
    private static final class TestSunTimes implements SunTimes {

        /** Added to every sunrise. Lets the test change the answers while the calendar runs. */
        volatile int shift;

        /** Whether the server's calendar and a client's copy have asked. */
        volatile boolean askedByServer;
        volatile boolean askedByClient;

        @Override
        public int sunriseTick(CalendarRules rules, long epochDay, boolean clientSide) {
            note(clientSide);
            return (Math.floorMod(epochDay, 2L) == 0 ? 4000 : 8000) + shift;
        }

        @Override
        public int sunsetTick(CalendarRules rules, long epochDay, boolean clientSide) {
            note(clientSide);
            return Math.floorMod(epochDay, 2L) == 0 ? 20_000 : 16_000;
        }

        private void note(boolean clientSide) {
            if (clientSide) {
                askedByClient = true;
            } else {
                askedByServer = true;
            }
        }
    }

    /**
     * Sunrise and sunset. Without a mod that moves the sun they are 06:00
     * and 18:00. With one registered, the calendar reports that mod's times,
     * dawn and dusk are announced at them (per day, also across jumps), and
     * a client's copy does the same.
     */
    @GameTest(template = "empty", batch = "calendar_sun")
    public static void sunTimesMoveDawnAndDusk(GameTestHelper helper) {
        // 03:00 on Spring 1, Year 1, which is epoch day 0 (an even day).
        Scene scene = new Scene(helper, BASE + 3000, false, 1, Season.SPRING, 1);
        ServerCalendar calendar = scene.calendar;
        ServerLevel level = scene.level;

        // --- Nobody moves the sun: 06:00 and 18:00.
        checkEquals(6000, calendar.sunriseTick(), "sunrise without a sun mod");
        checkEquals(18_000, calendar.sunsetTick(), "sunset without a sun mod");
        checkEquals(0, calendar.tickOf(DayMoment.MIDNIGHT), "midnight on the clock");
        checkEquals(6000, calendar.tickOf(DayMoment.DAWN), "dawn on the clock without a sun mod");
        checkEquals(12_000, calendar.tickOf(DayMoment.NOON), "noon on the clock");
        checkEquals(18_000, calendar.tickOf(DayMoment.DUSK), "dusk on the clock without a sun mod");
        check(!calendar.isSunUp(), "the sun is not up at 03:00");

        // --- Two helpers for code that has a day time but no level.
        check(Calendar.ofCurrentThread() == calendar, "on the server thread, the calendar of the current thread is the server's");
        checkEquals(0L, calendar.epochDayAt(level.getDayTime()), "the day the current day time falls on");
        checkEquals(1L, calendar.epochDayAt(level.getDayTime() + 21_000), "21 hours after 03:00 is the next day");
        checkEquals(-1L, calendar.epochDayAt(level.getDayTime() - 3001), "a tick before midnight is the day before");

        TestSunTimes sun = new TestSunTimes();
        SunTimes.register(sun);
        try {
            // The calendar asks the new sun times within one tick.
            scene.syncCalendarNow();
            check(sun.askedByServer && !sun.askedByClient, "only the server's calendar should have asked so far");
            checkEquals(4000, calendar.sunriseTick(), "sunrise on an even day");
            checkEquals(20_000, calendar.sunsetTick(), "sunset on an even day");
            checkEquals(4000, calendar.tickOf(DayMoment.DAWN), "dawn on the clock");
            checkEquals(20_000, calendar.tickOf(DayMoment.DUSK), "dusk on the clock");
            checkEquals(8000, calendar.sunriseTickOn(1), "tomorrow's sunrise");
            checkEquals(16_000, calendar.sunsetTickOn(1), "tomorrow's sunset");
            expectEvents(SERVER_EVENTS); // registering alone announces nothing

            // --- An ordinary day: dawn at 04:00 and dusk at 20:00, nothing at 06:00 and 18:00.
            scene.setClock(BASE + 3999);
            expectEvents(SERVER_EVENTS);
            check(!calendar.isSunUp(), "a tick before sunrise");
            scene.setClock(BASE + 4000);
            expectEvents(SERVER_EVENTS, "dawn of Spring 1, Year 1");
            check(calendar.isSunUp(), "at sunrise");
            scene.setClock(BASE + 6500);
            expectEvents(SERVER_EVENTS);
            scene.setClock(BASE + 12_000);
            expectEvents(SERVER_EVENTS, "noon of Spring 1, Year 1");
            scene.setClock(BASE + 18_500);
            expectEvents(SERVER_EVENTS);
            check(calendar.isSunUp(), "still up at 18:30");
            scene.setClock(BASE + 20_000);
            expectEvents(SERVER_EVENTS, "dusk of Spring 1, Year 1");
            check(!calendar.isSunUp(), "at sunset");

            // --- Midnight: the next day's times apply (08:00 and 16:00).
            scene.setClock(BASE + DAY + 10);
            expectEvents(SERVER_EVENTS, "day Spring 1, Year 1 -> Spring 2, Year 1 (1)", "midnight of Spring 2, Year 1");
            checkEquals(8000, calendar.sunriseTick(), "sunrise on an odd day");
            checkEquals(16_000, calendar.sunsetTick(), "sunset on an odd day");
            scene.setClock(BASE + DAY + 7999);
            expectEvents(SERVER_EVENTS);
            scene.setClock(BASE + DAY + 8000);
            expectEvents(SERVER_EVENTS, "dawn of Spring 2, Year 1");
            scene.setClock(BASE + DAY + 16_000);
            expectEvents(SERVER_EVENTS, "noon of Spring 2, Year 1", "dusk of Spring 2, Year 1");

            // --- Jumps use each day's own times.
            // Sleeping from 17:00 to 07:00: the new day's sun rose at 04:00.
            scene.setClock(BASE + DAY + 17_000);
            expectEvents(SERVER_EVENTS);
            scene.setClock(BASE + 2 * DAY + 7000);
            expectEvents(SERVER_EVENTS, "day Spring 2, Year 1 -> Spring 3, Year 1 (1)",
                    "midnight of Spring 3, Year 1", "dawn of Spring 3, Year 1");
            // A whole day forward, 07:00 to 07:00: noon and dusk of the old
            // day (dusk at 20:00), and on the new day the sun is not up yet
            // (it rises at 08:00).
            scene.setClock(BASE + 3 * DAY + 7000);
            expectEvents(SERVER_EVENTS, "noon of Spring 3, Year 1", "dusk of Spring 3, Year 1",
                    "day Spring 3, Year 1 -> Spring 4, Year 1 (1)", "midnight of Spring 4, Year 1");
            check(!calendar.isSunUp(), "07:00 on a day whose sun rises at 08:00");
            // Over several days: only the moments of the day it lands in.
            scene.setClock(BASE + 6 * DAY + 9000);
            expectEvents(SERVER_EVENTS, "day Spring 4, Year 1 -> Spring 7, Year 1 (3)",
                    "midnight of Spring 7, Year 1", "dawn of Spring 7, Year 1");

            // --- The mod's answers change (a setting was changed): picked up within a tick, no events.
            sun.shift = 1500;
            SunTimes.changed();
            scene.syncCalendarNow();
            checkEquals(5500, calendar.sunriseTick(), "sunrise after the sun times changed");
            // Impossible answers are forced into range, so that dawn stays
            // between midnight and noon.
            sun.shift = 20_000;
            SunTimes.changed();
            scene.syncCalendarNow();
            checkEquals(11_999, calendar.sunriseTick(), "a sunrise after noon");
            sun.shift = -20_000;
            SunTimes.changed();
            scene.syncCalendarNow();
            checkEquals(1, calendar.sunriseTick(), "a sunrise before midnight");
            sun.shift = 0;
            SunTimes.changed();
            scene.syncCalendarNow();
            checkEquals(4000, calendar.sunriseTick(), "sunrise after changing back");
            expectEvents(SERVER_EVENTS);

            // --- A client's copy: the same times and the same moments.
            ClientCalendarImpl client = ClientCalendarImpl.INSTANCE;
            client.reset();
            CLIENT_EVENTS.clear();
            long clock = BASE + 6 * DAY + 9000; // 09:00 on Spring 7 (epoch day 6)
            client.accept(message(false, 6 - Math.floorDiv(clock, DAY), 6));
            client.tick(gameTime(clock));
            expectEvents(CLIENT_EVENTS, "loaded Spring 7, Year 1");
            check(sun.askedByClient, "the client's copy should have asked for its own sun times");
            checkEquals(4000, client.sunriseTick(), "the client's sunrise");
            checkEquals(20_000, client.sunsetTick(), "the client's sunset");
            check(client.isSunUp(), "the client's sun at 09:00");
            client.tick(gameTime(clock + 3000));
            expectEvents(CLIENT_EVENTS, "noon of Spring 7, Year 1");
            client.tick(gameTime(clock + 10_999));
            expectEvents(CLIENT_EVENTS);
            client.tick(gameTime(clock + 11_000));
            expectEvents(CLIENT_EVENTS, "dusk of Spring 7, Year 1");
            client.tick(gameTime(clock + 15_010));
            expectEvents(CLIENT_EVENTS, "day Spring 7, Year 1 -> Spring 8, Year 1 (1)", "midnight of Spring 8, Year 1");
            checkEquals(8000, client.sunriseTick(), "the client's sunrise on the next day");
            client.tick(gameTime(clock + 15_000 + 7999));
            expectEvents(CLIENT_EVENTS);
            client.tick(gameTime(clock + 15_000 + 8000));
            expectEvents(CLIENT_EVENTS, "dawn of Spring 8, Year 1");
        } finally {
            // Whatever happened, the other tests get the ordinary sun back.
            SunTimes.register(SunTimes.VANILLA);
            scene.syncCalendarNow();
        }
        checkEquals(6000, calendar.sunriseTick(), "sunrise after the sun mod is gone");
        checkEquals(18_000, calendar.sunsetTick(), "sunset after the sun mod is gone");
        scene.cleanUp();
        helper.succeed();
    }

    /**
     * The game rule {@code doCalendarCycle = false}: the sun keeps cycling,
     * the moments keep coming, but the date and its moon stay.
     */
    @GameTest(template = "empty", batch = "calendar_pause")
    public static void pausedDateStays(GameTestHelper helper) {
        Scene scene = new Scene(helper, BASE + 20_000, false, 1, Season.SUMMER, 8);
        ServerCalendar calendar = scene.calendar;
        ServerLevel level = scene.level;

        check(scene.command("gamerule doCalendarCycle false"), "/gamerule doCalendarCycle false failed");
        scene.syncCalendarNow();
        check(calendar.isPaused(), "the calendar should report being paused");

        scene.setClock(BASE + DAY + 100);
        expectEvents(SERVER_EVENTS, "midnight of Summer 8, Year 1");
        scene.expectDate("Summer 8, Year 1");
        checkEquals(MoonPhase.FULL_MOON, calendar.moonPhase(), "the calendar's moon stays the full moon while paused");
        checkEquals(0, level.getMoonPhase(), "the game's moon stays the full moon while paused");

        scene.setClock(BASE + 4 * DAY + 19_000);
        expectEvents(SERVER_EVENTS, "midnight of Summer 8, Year 1", "dawn of Summer 8, Year 1",
                "noon of Summer 8, Year 1", "dusk of Summer 8, Year 1");
        scene.expectDate("Summer 8, Year 1");
        checkEquals(0, level.getMoonPhase(), "the game's moon stays the full moon after several paused days");

        // /time set while paused keeps the date too.
        check(scene.command("time set day"), "/time set day failed");
        scene.syncCalendarNow();
        scene.expectDate("Summer 8, Year 1");
        scene.setClock(BASE + 4 * DAY + 19_000);
        scene.expectDate("Summer 8, Year 1");

        // Changing the date by hand still works while paused.
        calendar.addDays(1);
        scene.expectDate("Summer 9, Year 1");
        SERVER_EVENTS.clear();

        check(scene.command("gamerule doCalendarCycle true"), "/gamerule doCalendarCycle true failed");
        scene.setClock(BASE + 5 * DAY + 10);
        expectEvents(SERVER_EVENTS,
                "day Summer 9, Year 1 -> Summer 10, Year 1 (1)",
                "midnight of Summer 10, Year 1");
        check(!calendar.isPaused(), "the calendar should run again");
        scene.cleanUp();
        helper.succeed();
    }

    /**
     * The world's own count of days ("Day 45"): it goes up when days pass,
     * however they pass, and stays when the date is only renamed by hand.
     */
    @GameTest(template = "empty", batch = "calendar_daynumber")
    public static void dayNumberCountsDaysThatPassed(GameTestHelper helper) {
        Scene scene = new Scene(helper, BASE + 15_000, false, 1, Season.AUTUMN, 1);
        ServerCalendar calendar = scene.calendar;
        // Earlier tests have moved this world's clock, so the count is
        // whatever it is by now. Everything below is measured from here.
        long start = calendar.dayNumber();

        // A midnight passes: one more day.
        scene.setClock(BASE + DAY + 1000);
        scene.expectDate("Autumn 2, Year 1");
        checkEquals(start + 1, calendar.dayNumber(), "day number after one midnight");

        // Sleeping or /time add over several days: that many more.
        scene.setClock(BASE + 6 * DAY + 1000);
        scene.expectDate("Autumn 7, Year 1");
        checkEquals(start + 6, calendar.dayNumber(), "day number after a jump of five days");

        // Setting the date by hand renames today. The count does not move.
        calendar.setDate(3, Season.WINTER, 2);
        scene.expectDate("Winter 2, Year 3");
        checkEquals(start + 6, calendar.dayNumber(), "day number after setDate");
        check(scene.command("calendar add -40"), "/calendar add -40 failed");
        checkEquals(start + 6, calendar.dayNumber(), "day number after /calendar add -40");
        check(scene.command("calendar set spring 1 1"), "/calendar set spring 1 1 failed");
        scene.expectDate("Spring 1, Year 1");
        checkEquals(start + 6, calendar.dayNumber(), "day number after /calendar set to the calendar's very first day");

        // ... and goes on counting from there.
        scene.setClock(BASE + 7 * DAY + 1000);
        scene.expectDate("Spring 2, Year 1");
        checkEquals(start + 7, calendar.dayNumber(), "day number one day after a /calendar set");

        // The clock set back to an earlier time of day means the next day
        // (see timeSetNeverMovesTheDateBack), so that is one more day too.
        scene.setClock(BASE + 2 * DAY + 500);
        scene.expectDate("Spring 3, Year 1");
        checkEquals(start + 8, calendar.dayNumber(), "day number after the clock was set back");

        // While the date is paused, the count stands still with it.
        check(scene.command("gamerule doCalendarCycle false"), "/gamerule doCalendarCycle false failed");
        scene.syncCalendarNow();
        scene.setClock(BASE + 5 * DAY + 500);
        scene.expectDate("Spring 3, Year 1");
        checkEquals(start + 8, calendar.dayNumber(), "day number after three paused days");
        check(scene.command("gamerule doCalendarCycle true"), "/gamerule doCalendarCycle true failed");
        scene.setClock(BASE + 6 * DAY + 500);
        scene.expectDate("Spring 4, Year 1");
        checkEquals(start + 9, calendar.dayNumber(), "day number one day after the pause");

        // A joining player is told, and their copy shows the same number.
        ServerPlayer player = scene.addPlayer();
        List<CalendarSyncPayload> sent = scene.sentTo(player);
        checkEquals(1, sent.size(), "messages to a joining player");
        checkEquals(calendar.date().epochDay() - (start + 9) + 1, sent.get(0).firstDay(), "the first day in the message");
        ClientCalendarImpl client = ClientCalendarImpl.INSTANCE;
        client.reset();
        checkEquals(1L, client.dayNumber(), "day number of a client that has not heard from a server");
        client.accept(sent.get(0));
        checkEquals(start + 9, client.dayNumber(), "the client's day number");
        // ... also after a later /calendar set, which sends a new message.
        check(scene.command("calendar set summer 3 2"), "/calendar set summer 3 2 failed");
        sent = scene.sentTo(player);
        checkEquals(1, sent.size(), "messages after /calendar set");
        client.accept(sent.get(0));
        checkEquals("Summer 3, Year 2", client.date().toString(), "the client's date after /calendar set");
        checkEquals(start + 9, client.dayNumber(), "the client's day number after /calendar set");

        scene.cleanUp();
        helper.succeed();
    }

    /**
     * What is written to the world's save file comes back unchanged, and a
     * changed config carries the date over to the new season lengths.
     */
    @GameTest(template = "empty", batch = "calendar_saving")
    public static void savingAndChangedRules(GameTestHelper helper) {
        ServerLevel level = helper.getLevel();

        // --- Save and load.
        CalendarSavedData data = new CalendarSavedData();
        check(data.isNew(), "fresh data should be new");
        data.set(UNEQUAL, new CalendarClock(BASE + 4321, -77));
        CompoundTag tag = data.save(new CompoundTag(), level.registryAccess());
        CalendarSavedData loaded = CalendarSavedData.FACTORY.deserializer().apply(tag, level.registryAccess());
        check(!loaded.isNew(), "loaded data should not be new");
        checkEquals(UNEQUAL, loaded.rules(), "saved rules");
        checkEquals(-77L, loaded.clock().dayOffset(), "saved offset");
        checkEquals(BASE + 4321, loaded.clock().dayTime(), "saved clock time");
        checkEquals(data.clock().epochDay(), loaded.clock().epochDay(), "saved date");
        // The file above is what Calendar 0.1.0 wrote: no first day yet.
        check(!loaded.isFirstDayKnown(), "a file without a first day must say so");
        data.setFirstDay(-12_345L);
        loaded = CalendarSavedData.FACTORY.deserializer().apply(data.save(new CompoundTag(), level.registryAccess()), level.registryAccess());
        check(loaded.isFirstDayKnown(), "the first day was not saved");
        checkEquals(-12_345L, loaded.firstDay(), "saved first day");

        // An empty or damaged file means "no calendar yet", not a crash.
        check(CalendarSavedData.FACTORY.deserializer().apply(new CompoundTag(), level.registryAccess()).isNew(), "empty file");
        CompoundTag damaged = tag.copy();
        damaged.putInt("summer_days", 0);
        check(CalendarSavedData.FACTORY.deserializer().apply(damaged, level.registryAccess()).isNew(), "damaged file");

        // The world really has its calendar in its saved data.
        check(level.getDataStorage().get(CalendarSavedData.FACTORY, CalendarSavedData.FILE_NAME) != null,
                "the world's calendar is not registered for saving");

        // --- Changed season lengths keep the date.
        CalendarRules old = CalendarRules.DEFAULT;
        long autumn3Year2 = old.epochDayOf(2, Season.AUTUMN, 3);
        checkEquals("Autumn 3, Year 2", UNEQUAL.dateOf(ServerCalendarImpl.carriedOverEpochDay(old, UNEQUAL, autumn3Year2)).toString(),
                "Autumn 3 under new rules");
        long autumn12Year2 = old.epochDayOf(2, Season.AUTUMN, 12);
        checkEquals("Autumn 5, Year 2", UNEQUAL.dateOf(ServerCalendarImpl.carriedOverEpochDay(old, UNEQUAL, autumn12Year2)).toString(),
                "Autumn 12 when autumn now has 5 days");
        checkEquals(autumn3Year2, ServerCalendarImpl.carriedOverEpochDay(old, old, autumn3Year2), "unchanged rules change nothing");

        // The world's count of days is carried over with the date: day 30 stays day 30.
        CalendarSavedData counted = new CalendarSavedData();
        counted.set(old, new CalendarClock(BASE + 4321, autumn3Year2 - 100));
        counted.setFirstDay(autumn3Year2 - 29);
        checkEquals(autumn3Year2, counted.clock().epochDay(), "test setup: the saved date");
        ServerCalendarImpl.carryOver(counted, UNEQUAL);
        checkEquals("Autumn 3, Year 2", UNEQUAL.dateOf(counted.clock().epochDay()).toString(), "the carried-over date");
        checkEquals(30L, counted.clock().epochDay() - counted.firstDay() + 1, "the day number after new season lengths");
        helper.succeed();
    }

    /**
     * The data-pack condition {@code calendar:date}: read from JSON as a
     * data pack would write it, and used through the real
     * {@code /execute if predicate} command.
     */
    @GameTest(template = "empty", batch = "calendar_loot")
    public static void dateConditionForDataPacks(GameTestHelper helper) {
        Scene scene = new Scene(helper, BASE + 15_000, false, 3, Season.WINTER, 8);
        ServerLevel level = scene.level;
        check(BuiltInRegistries.LOOT_CONDITION_TYPE.get(ResourceLocation.fromNamespaceAndPath("calendar", "date")) == CalendarLoot.DATE.get(),
                "calendar:date is not registered");
        LootContext context = new LootContext.Builder(new LootParams.Builder(level).create(LootContextParamSets.EMPTY))
                .create(Optional.empty());

        // 15:00 on Winter 8, Year 3: mid winter, full moon tonight.
        check(parse("{}").test(context), "an empty condition accepts every date");
        check(parse("{\"season\":\"winter\"}").test(context), "season as one name");
        check(parse("{\"season\":[\"autumn\",\"winter\"]}").test(context), "season as a list");
        check(!parse("{\"season\":[\"spring\",\"summer\"]}").test(context), "wrong seasons");
        check(parse("{\"phase\":\"mid\"}").test(context), "phase");
        check(!parse("{\"phase\":[\"early\",\"late\"]}").test(context), "wrong phases");
        check(parse("{\"moon\":\"full_moon\"}").test(context), "moon");
        check(!parse("{\"moon\":\"new_moon\"}").test(context), "wrong moon");
        check(parse("{\"day\":8}").test(context), "exact day");
        check(parse("{\"day\":{\"min\":3,\"max\":10}}").test(context), "day range");
        check(!parse("{\"day\":{\"min\":9}}").test(context), "day too early");
        check(parse("{\"year\":{\"min\":2}}").test(context), "year range");
        check(!parse("{\"year\":1}").test(context), "wrong year");
        check(parse("{\"season\":\"winter\",\"phase\":\"mid\",\"moon\":\"full_moon\",\"day\":8,\"year\":3}").test(context), "everything at once");
        check(!parse("{\"season\":\"winter\",\"phase\":\"mid\",\"moon\":\"full_moon\",\"day\":8,\"year\":4}").test(context), "one field off");
        check(DateCondition.inSeasons(Season.WINTER).test(context), "built in code");
        check(DateCondition.CODEC.codec().parse(JsonOps.INSTANCE, JsonParser.parseString("{\"season\":\"monsoon\"}")).isError(),
                "an unknown season name must be an error");

        // Through a real command, as a command block or function would use it.
        check(scene.command("execute if predicate {condition:\"calendar:date\",season:\"winter\",moon:\"full_moon\"}"),
                "/execute if predicate should pass in winter under a full moon");
        check(!scene.command("execute if predicate {condition:\"calendar:date\",season:\"summer\"}"),
                "/execute if predicate should not pass for summer");

        // 02:00 the following night: the date is day 9 already, but it is
        // still the night of the full moon.
        scene.setClock(BASE + DAY + 2000);
        check(parse("{\"day\":9,\"moon\":\"full_moon\"}").test(context), "after midnight: new date, same moon");
        // 13:00: past noon, the moon has changed out of sight.
        scene.setClock(BASE + DAY + 13_000);
        check(!parse("{\"moon\":\"full_moon\"}").test(context), "after noon the full moon is over");
        check(parse("{\"day\":9,\"moon\":\"waning_gibbous\"}").test(context), "after noon: the new day's moon");

        scene.calendar.setDate(3, Season.SUMMER, 1);
        check(scene.command("execute if predicate {condition:\"calendar:date\",season:\"summer\"}"),
                "/execute if predicate should pass after the date was set to summer");
        scene.cleanUp();
        helper.succeed();
    }

    private static DateCondition parse(String json) {
        return DateCondition.CODEC.codec().parse(JsonOps.INSTANCE, JsonParser.parseString(json))
                .getOrThrow(message -> new GameTestAssertException("could not read " + json + ": " + message));
    }

    // ==================================================================
    // Part 3: the client's copy
    // ==================================================================

    /**
     * The network message survives being written to bytes and read back.
     */
    @GameTest(template = "empty", batch = "calendar_message")
    public static void messageRoundTrip(GameTestHelper helper) {
        CalendarSyncPayload sent = new CalendarSyncPayload(10, 20, 5, 1000, true, false, -123_456_789_012L, 987_654_321_098L,
                555_444_333_222L);
        ByteBuf buffer = Unpooled.buffer();
        CalendarSyncPayload.STREAM_CODEC.encode(buffer, sent);
        checkEquals(34, buffer.readableBytes(), "message size in bytes");
        CalendarSyncPayload received = CalendarSyncPayload.STREAM_CODEC.decode(buffer);
        checkEquals(sent, received, "message after a round trip");
        checkEquals(0, buffer.readableBytes(), "bytes left over");
        checkEquals(new CalendarRules(10, 20, 5, 1000, true), received.rules(), "rules from the message");
        helper.succeed();
    }

    /** The day that counts as day 1 in the messages made by {@link #message}. */
    private static final long MESSAGE_FIRST_DAY = 20;

    /** A message as the server would send it for the default rules. */
    private static CalendarSyncPayload message(boolean paused, long dayOffset, long epochDay) {
        return new CalendarSyncPayload(14, 14, 14, 14, true, paused, dayOffset, epochDay, MESSAGE_FIRST_DAY);
    }

    /**
     * The client's copy on its own, in the awkward situations it is built
     * for. The client's clock and the server's messages are fed in by hand
     * so that each situation can be produced exactly. Times are clock
     * times (days begin at midnight), turned into the game's day time
     * where they are handed to the copy.
     */
    @GameTest(template = "empty", batch = "calendar_client_unit")
    public static void clientCopyHandlesAwkwardMoments(GameTestHelper helper) {
        ClientCalendarImpl client = ClientCalendarImpl.INSTANCE;
        client.reset();
        CLIENT_EVENTS.clear();
        CalendarRules rules = CalendarRules.DEFAULT;
        long autumn3 = rules.epochDayOf(1, Season.AUTUMN, 3);

        // Before the server has said anything: a stand-in, clearly marked.
        check(!client.isSynced() && client.isClientSide(), "not synced before the first message");
        client.tick(gameTime(BASE + 5));
        expectEvents(CLIENT_EVENTS);

        // The first message: the server's date at once, and "loaded".
        // (The clock's day 100 is Autumn 3.)
        client.accept(message(false, autumn3 - 100, autumn3));
        check(client.isSynced(), "synced after the first message");
        expectEvents(CLIENT_EVENTS, "loaded Autumn 3, Year 1");
        long time = BASE + 23_990;
        client.tick(gameTime(time));

        // An ordinary midnight: believed at once, with the midnight moment.
        for (int i = 0; i < 20; i++) {
            client.tick(gameTime(++time));
        }
        expectEvents(CLIENT_EVENTS, "day Autumn 3, Year 1 -> Autumn 4, Year 1 (1)", "midnight of Autumn 4, Year 1");

        // The game corrects the client's clock back across that midnight
        // (the client was ahead of a slow server). No day back, no second
        // midnight.
        time = BASE + DAY - 3;
        for (int i = 0; i < 20; i++) {
            client.tick(gameTime(time++));
        }
        expectEvents(CLIENT_EVENTS);
        checkEquals("Autumn 4, Year 1", client.date().toString(), "date after a clock correction");

        // The server's clock is set back to 19:00 (same date). The new
        // clock arrives BEFORE the new offset: the formula says "day -96"
        // for a moment. Not shown.
        time = 19_000;
        client.tick(gameTime(time));
        client.tick(gameTime(++time));
        checkEquals("Autumn 4, Year 1", client.date().toString(), "date while only the clock has arrived");
        client.accept(message(false, autumn3 + 1, autumn3 + 1)); // the clock's day 0 is now Autumn 4
        client.tick(gameTime(++time));
        // Like the server, the copy counts the set-back as moving forward
        // from just after midnight to 19:00 and announces what lies between.
        expectEvents(CLIENT_EVENTS, "dawn of Autumn 4, Year 1", "noon of Autumn 4, Year 1", "dusk of Autumn 4, Year 1");
        checkEquals("Autumn 4, Year 1", client.date().toString(), "date after both have arrived");
        checkEquals(19_002, client.tickOfDay(), "time of day follows the client's clock");

        // The other order: the new offset arrives before the new clock.
        // (Pretend the clock has run on for 60 days first.)
        time = 60 * DAY + 19_000;
        client.accept(message(false, autumn3 + 1 - 60, autumn3 + 1));
        client.tick(gameTime(time));
        CLIENT_EVENTS.clear();
        // Server: set back to 07:00, an earlier time of day, so the date
        // moves on to Autumn 5. The offset comes first.
        client.accept(message(false, autumn3 + 2, autumn3 + 2));
        for (int i = 0; i < 25; i++) {
            client.tick(gameTime(++time));
            checkEquals("Autumn 4, Year 1", client.date().toString(), "date while only the offset has arrived");
        }
        time = 7000; // now the clock
        client.tick(gameTime(time));
        expectEvents(CLIENT_EVENTS, "day Autumn 4, Year 1 -> Autumn 5, Year 1 (1)",
                "midnight of Autumn 5, Year 1", "dawn of Autumn 5, Year 1");

        // The trap a real client fell into during development: the offset
        // comes first, and together with the old clock it happens to give
        // exactly "tomorrow", which looks like an ordinary midnight.
        // Server: at 00:01 of the clock's day 1, set back to 19:00. The
        // date stays Autumn 6.
        time = DAY + 60;
        client.tick(gameTime(time));
        expectEvents(CLIENT_EVENTS, "noon of Autumn 5, Year 1", "dusk of Autumn 5, Year 1",
                "day Autumn 5, Year 1 -> Autumn 6, Year 1 (1)", "midnight of Autumn 6, Year 1");
        client.accept(message(false, autumn3 + 3, autumn3 + 3)); // the clock's day 0 is now Autumn 6
        for (int i = 0; i < 25; i++) {
            client.tick(gameTime(++time));
            checkEquals("Autumn 6, Year 1", client.date().toString(), "date while the new offset meets the old clock");
        }
        time = 19_000;
        client.tick(gameTime(time));
        expectEvents(CLIENT_EVENTS, "dawn of Autumn 6, Year 1", "noon of Autumn 6, Year 1", "dusk of Autumn 6, Year 1");
        checkEquals("Autumn 6, Year 1", client.date().toString(), "date after the clock has arrived too");

        // A set-back of a few seconds across midnight. Server: five
        // seconds after the midnight that began Autumn 7, the time is set
        // to a moment shortly before midnight. The date stays Autumn 7 (it
        // must never go back), so the clock's day 0 is now Autumn 7. Clock
        // and message arrive together, as in a real game. The copy must not
        // hold on to the time from before and announce Autumn 8 early: it
        // follows at once and passes midnight on time.
        time = DAY + 100;
        client.tick(gameTime(time));
        expectEvents(CLIENT_EVENTS, "day Autumn 6, Year 1 -> Autumn 7, Year 1 (1)", "midnight of Autumn 7, Year 1");
        time = DAY - 50;
        client.accept(message(false, autumn3 + 4, autumn3 + 4));
        for (int i = 0; i < 49; i++) {
            client.tick(gameTime(++time));
            checkEquals("Autumn 7, Year 1", client.date().toString(), "date after a small set-back across midnight");
        }
        expectEvents(CLIENT_EVENTS);
        client.tick(gameTime(++time));
        expectEvents(CLIENT_EVENTS, "day Autumn 7, Year 1 -> Autumn 8, Year 1 (1)", "midnight of Autumn 8, Year 1");
        // The same once more, but the clock arrives twelve ticks after the
        // message. That does not happen in a real game, but the copy must
        // not show a wrong date then either. (It is a little late with the
        // midnight that follows, because it has to make sure first.)
        time = DAY + 100;
        client.tick(gameTime(time));
        client.accept(message(false, autumn3 + 5, autumn3 + 5)); // the clock's day 0 is now Autumn 8
        for (int i = 0; i < 12; i++) {
            client.tick(gameTime(++time));
        }
        time = DAY - 50;
        for (int i = 0; i < 49; i++) {
            client.tick(gameTime(++time));
            checkEquals("Autumn 8, Year 1", client.date().toString(), "date after a late small set-back across midnight");
        }
        for (int i = 0; i <= ClientCalendarImpl.SETTLE_TICKS + 1; i++) {
            client.tick(gameTime(++time));
        }
        checkEquals("Autumn 9, Year 1", client.date().toString(), "date after the midnight that followed");
        // Back to the middle of the day for what follows (server: time set
        // to 12:30, same date).
        client.accept(message(false, autumn3 + 6, autumn3 + 6)); // the clock's day 0 is now Autumn 9
        time = 12_500;
        client.tick(gameTime(time));
        checkEquals("Autumn 9, Year 1", client.date().toString(), "date before the next part");
        CLIENT_EVENTS.clear();

        // /calendar set on the server: the clock agrees, so the new date
        // shows at once, without any moments.
        long spring2Year4 = rules.epochDayOf(4, Season.SPRING, 2);
        client.accept(message(false, spring2Year4, spring2Year4));
        expectEvents(CLIENT_EVENTS, "day Autumn 9, Year 1 -> Spring 2, Year 4 (133)", "season autumn -> spring");

        // A new dimension: the new level's clock is 0 for a few ticks,
        // then jumps to the real time. Nothing may be shown or announced.
        client.levelChanged();
        for (int i = 0; i < 5; i++) {
            client.tick(0);
        }
        for (int i = 0; i < 40; i++) {
            client.tick(gameTime(++time));
        }
        expectEvents(CLIENT_EVENTS);
        checkEquals("Spring 2, Year 4", client.date().toString(), "date after changing dimension");

        // /time add 10d: the client's own clock jumps forward. Believed at
        // once, as one change, without replaying moments.
        time += 10 * DAY;
        client.tick(gameTime(time));
        expectEvents(CLIENT_EVENTS, "day Spring 2, Year 4 -> Spring 12, Year 4 (10)");

        // A date nothing explains (the clock falls back three days and no
        // message comes): held back for the settling time, then accepted.
        for (int i = 0; i < ClientCalendarImpl.TRUST_TICKS; i++) {
            client.tick(gameTime(++time));
        }
        time -= 3 * DAY;
        for (int i = 0; i <= ClientCalendarImpl.SETTLE_TICKS; i++) {
            checkEquals("Spring 12, Year 4", client.date().toString(), "date while a surprising one settles");
            client.tick(gameTime(++time));
        }
        expectEvents(CLIENT_EVENTS, "day Spring 12, Year 4 -> Spring 9, Year 4 (-3)");

        // Paused on the server: the date stays across the client's
        // midnight, the moments keep coming.
        long paused = client.date().epochDay();
        client.accept(message(true, paused - Math.floorDiv(time, DAY), paused));
        check(client.isPaused(), "the copy should report being paused");
        time = Math.floorDiv(time, DAY) * DAY + DAY - 5;
        client.tick(gameTime(time));
        CLIENT_EVENTS.clear();
        for (int i = 0; i < 10; i++) {
            client.tick(gameTime(++time));
        }
        expectEvents(CLIENT_EVENTS, "midnight of Spring 9, Year 4");

        // A message with impossible rules is ignored.
        client.accept(new CalendarSyncPayload(14, 0, 14, 14, true, false, 0, 0, 0));
        checkEquals("Spring 9, Year 4", client.date().toString(), "date after a bad message");

        // Leaving the world.
        client.reset();
        check(!client.isSynced(), "not synced after leaving");
        CLIENT_EVENTS.clear();
        helper.succeed();
    }

    /**
     * The whole chain in a real server: a stand-in player joins, and the
     * messages the server really sends to them are handed to the client's
     * copy, which is also shown the world's clock, but twelve ticks late
     * (more than half a second: worse than a real client, which gets the
     * clock together with the message). Then the world goes through
     * everything: midnights, a sleep jump, /time set in both directions,
     * /calendar set, pausing.
     *
     * <p>Two things must hold. The copy must never show a date the server
     * never had (no flicker). And whenever things have been calm for a
     * moment, the copy must show the server's date and moon.</p>
     */
    @GameTest(template = "empty", batch = "calendar_client_mirror", timeoutTicks = 2400)
    public static void clientCopyMirrorsTheServer(GameTestHelper helper) {
        Scene scene = new Scene(helper, BASE + DAY - 60, true, 1, Season.AUTUMN, 14);
        ServerLevel level = scene.level;
        ClientCalendarImpl client = ClientCalendarImpl.INSTANCE;
        client.reset();
        CLIENT_EVENTS.clear();

        ServerPlayer player = scene.addPlayer();

        // The world's clock as the client sees it: twelve ticks late.
        ArrayDeque<Long> delayedClock = new ArrayDeque<>();
        // Every date the server has shown, in order, and the same for the copy.
        List<String> serverDates = new ArrayList<>();
        List<String> clientDates = new ArrayList<>();
        int[] messages = {0};
        int[] calmTicks = {0};
        long[] lastServerClock = {level.getDayTime()};

        helper.onEachTick(() -> {
            String serverDate = scene.calendar.date().toString();
            if (serverDates.isEmpty() || !serverDates.get(serverDates.size() - 1).equals(serverDate)) {
                serverDates.add(serverDate);
                calmTicks[0] = 0;
            }
            // A jump of the clock (sleeping, /time) is not calm either, even
            // when the date stays: the copy sees it twelve ticks later.
            if (level.getDayTime() != lastServerClock[0] + 1) {
                calmTicks[0] = 0;
            }
            lastServerClock[0] = level.getDayTime();
            for (CalendarSyncPayload payload : scene.sentTo(player)) {
                messages[0]++;
                calmTicks[0] = 0;
                client.accept(payload);
            }
            delayedClock.add(level.getDayTime());
            if (delayedClock.size() > 12) {
                client.tick(delayedClock.poll());
            }
            if (client.isSynced()) {
                String clientDate = client.date().toString();
                if (clientDates.isEmpty() || !clientDates.get(clientDates.size() - 1).equals(clientDate)) {
                    clientDates.add(clientDate);
                }
                // No flicker: the copy only ever shows dates the server had.
                check(serverDates.contains(clientDate), "the client showed " + clientDate + ", which the server never had: " + serverDates);
                // Calm for two seconds: the copy must be right.
                if (++calmTicks[0] > 40) {
                    checkEquals(serverDate, clientDate, "the client's date after a calm moment");
                    checkEquals(scene.calendar.isPaused(), client.isPaused(), "the client's pause after a calm moment");
                    checkEquals(scene.calendar.dayNumber(), client.dayNumber(), "the client's day number after a calm moment");
                }
                // Calmer still (the copy's clock has caught up as well): the same moon.
                // Not in the first ticks after noon, though: there the server
                // already has the new moon and the late copy rightly does not.
                boolean sameSideOfNoon = (scene.calendar.tickOfDay() < CalendarRules.NOON_TICK)
                        == (client.tickOfDay() < CalendarRules.NOON_TICK);
                if (calmTicks[0] > 60 && sameSideOfNoon) {
                    checkEquals(scene.calendar.moonPhase(), client.moonPhase(), "the client's moon after a calm moment");
                }
            }
        });

        helper.startSequence()
                // Joining: exactly one message, then an ordinary midnight into winter with none.
                .thenIdle(40)
                .thenExecute(() -> checkEquals(1, messages[0], "messages after joining"))
                .thenWaitUntil(() -> check(client.date().season() == Season.WINTER, "the client did not reach winter"))
                .thenIdle(80)
                .thenExecute(() -> checkEquals(1, messages[0], "messages after an ordinary midnight"))
                // Evening, then sleeping vanilla style: jump to the next sunrise. Still no message needed.
                .thenExecute(() -> level.setDayTime(gameTime(BASE + DAY + 20_000)))
                .thenIdle(80)
                .thenExecute(() -> level.setDayTime(gameTime(BASE + 2 * DAY + 6000)))
                .thenIdle(80)
                .thenExecute(() -> {
                    scene.expectDate("Winter 2, Year 1");
                    checkEquals(1, messages[0], "messages after sleeping");
                })
                // /time set to a later time of day: same date, one message (new offset).
                .thenExecute(() -> check(scene.command("time set 13000"), "/time set 13000 failed"))
                .thenIdle(80)
                .thenExecute(() -> {
                    scene.expectDate("Winter 2, Year 1");
                    checkEquals(2, messages[0], "messages after /time set");
                })
                // /time set to an earlier time of day: the next morning.
                .thenExecute(() -> check(scene.command("time set day"), "/time set day failed"))
                .thenIdle(80)
                .thenExecute(() -> scene.expectDate("Winter 3, Year 1"))
                // /calendar set: a new date far away.
                .thenExecute(() -> check(scene.command("calendar set summer 8 7"), "/calendar set failed"))
                .thenIdle(80)
                .thenExecute(() -> scene.expectDate("Summer 8, Year 7"))
                // /time add: forward by five days.
                .thenExecute(() -> check(scene.command("time add 5d"), "/time add failed"))
                .thenIdle(80)
                .thenExecute(() -> scene.expectDate("Summer 13, Year 7"))
                // Pause, then let a midnight pass: the date stays on both sides.
                .thenExecute(() -> {
                    check(scene.command("gamerule doCalendarCycle false"), "/gamerule failed");
                    level.setDayTime(gameTime(shortlyBeforeMidnight(level)));
                })
                .thenIdle(100)
                .thenExecute(() -> {
                    scene.expectDate("Summer 13, Year 7");
                    check(client.isPaused(), "the client should know the date is paused");
                })
                // Run again and pass another midnight.
                .thenExecute(() -> {
                    check(scene.command("gamerule doCalendarCycle true"), "/gamerule failed");
                    level.setDayTime(gameTime(shortlyBeforeMidnight(level)));
                })
                .thenIdle(100)
                .thenExecute(() -> {
                    scene.expectDate("Summer 14, Year 7");
                    checkEquals("Summer 14, Year 7", client.date().toString(), "the client's final date");
                    // The copy went through the same dates as the server, in the same order.
                    checkEquals(serverDates, clientDates, "the dates the client showed, in order");
                    CalendarMod.LOGGER.info("[Calendar test] The client's copy followed {} dates with {} messages from the server: {}",
                            clientDates.size(), messages[0], clientDates);
                })
                .thenExecute(scene::cleanUp)
                .thenSucceed();
    }

    /** The clock time 15 ticks before the next midnight of the level's clock. */
    private static long shortlyBeforeMidnight(ServerLevel level) {
        long clock = CalendarClock.toClockTime(level.getDayTime());
        return clock - Math.floorMod(clock, DAY) + DAY - 15;
    }
}
