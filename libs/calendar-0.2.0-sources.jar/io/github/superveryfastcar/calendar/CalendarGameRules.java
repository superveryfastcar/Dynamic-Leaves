package io.github.superveryfastcar.calendar;

import javax.annotation.Nullable;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.GameRules;

/**
 * Calendar's one game rule: {@code doCalendarCycle}.
 *
 * <p>{@code /gamerule doCalendarCycle false} pauses the date. The sun and
 * the moon keep moving and the world keeps running, but every midnight starts
 * the same date again, so the season never changes. Useful for building
 * servers, for taking screenshots in one season and for testing.</p>
 *
 * <p>It sits next to the game's own {@code doDaylightCycle} (which stops the
 * sun) and {@code doWeatherCycle}, and is named to match them.</p>
 */
public final class CalendarGameRules {

    /** The rule's name as typed in {@code /gamerule}. */
    public static final String DO_CALENDAR_CYCLE_NAME = "doCalendarCycle";

    /** The rule's handle. Null until {@link #register()} has run during game start. */
    @Nullable
    private static GameRules.Key<GameRules.BooleanValue> doCalendarCycle;

    private CalendarGameRules() {
    }

    /**
     * Adds the rule to the game. Must run on the main thread during game
     * start, before any world exists. See {@link CalendarMod}.
     */
    static void register() {
        doCalendarCycle = GameRules.register(DO_CALENDAR_CYCLE_NAME, GameRules.Category.UPDATES,
                GameRules.BooleanValue.create(true));
    }

    /**
     * The rule's handle, for code that wants to read or set it directly.
     *
     * @throws IllegalStateException if the game has not finished starting
     */
    public static GameRules.Key<GameRules.BooleanValue> doCalendarCycle() {
        GameRules.Key<GameRules.BooleanValue> key = doCalendarCycle;
        if (key == null) {
            throw new IllegalStateException("The game rule is not registered yet");
        }
        return key;
    }

    /** True if the date is paused in the world this level belongs to. */
    public static boolean isPaused(ServerLevel level) {
        GameRules.Key<GameRules.BooleanValue> key = doCalendarCycle;
        return key != null && !level.getGameRules().getBoolean(key);
    }
}
